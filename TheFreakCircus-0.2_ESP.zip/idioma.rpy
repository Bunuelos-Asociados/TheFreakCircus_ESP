init python:
    
    def actualizar_genero():
        
        global letra, arti, arti_2

        if persistent.p_genero == "feminino":

            letra  = "a"
            arti   = "la"
            arti_2 = "una"

        elif persistent.p_genero == "masculino":

            letra  = "o"
            arti   = "el"
            arti_2 = "un"

        else:

            letra  = "e"
            arti   = "le"
            arti_2 = "une"

init 1000 python:
    renpy.game.preferences.language = "Spanish"
    
label before_main_menu:
    $ actualizar_genero()
    return    

label after_load:
    $ actualizar_genero()
    return