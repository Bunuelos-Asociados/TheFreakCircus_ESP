# TODO: Translation updated at 2026-10-03 14:34

# game/script.rpy:35
translate Spanish start_150fa5bd:

    # narrator "Text in this color represents the protagonist’s narration and observations."
    narrator "El texto en este color representa la narración y las observaciones del protagonista."

# game/script.rpy:37
translate Spanish start_d2c08ce8:

    # narrator "{color=#a0b0c0}(Text in parentheses shows their thoughts and appears in this color.)"
    narrator "{color=#a0b0c0}(El texto entre paréntesis muestra sus pensamientos y aparece en este color.)"

# game/script.rpy:131
translate Spanish nomes_f97c33e1:

    # mc "Another chilly day to head to work. The weather's been so all over the place lately..."
    mc "Otro día frío para ir a trabajar. El clima ha estado tan alterado últimamente..."

# game/script.rpy:137
translate Spanish nomes_cb842e6d:

    # mc "Ugh, this again. They've been talking for a while about some traveling circus coming to town."
    mc "Uf, esto de nuevo. Llevan un tiempo hablando de la llegada de un circo ambulante a la ciudad."

# game/script.rpy:138
translate Spanish nomes_3fcf6a12:

    # mc "They’ve been around for three days, spamming the town with flyers and random stunts."
    mc "Llevan tres días por aquí, saturando la ciudad de folletos y haciendo todo tipo de cosas para llamar la atención."

# game/script.rpy:139
translate Spanish nomes_1fef6ab4:

    # mc "Their style is pretty eccentric, but honestly way better than those typical clowns with the colorful outfits."
    mc "Su estilo es bastante excéntrico, pero sinceramente, mucho mejor que el de los típicos payasos con trajes coloridos."

# game/script.rpy:140
translate Spanish nomes_1f90c709:

    # mc "Those ones give me the creeps with their red noses and tacky rainbow wigs."
    mc "Esos me dan escalofríos con sus narices rojas y sus pelucas de arcoíris de mal gusto."

# game/script.rpy:148
translate Spanish nomes_5a9be666:

    # mc "The freak circus of horrors."
    mc "El extraño circo de los horrores."

# game/script.rpy:150
translate Spanish nomes_69123b4f:

    # d "Hey!! Get out of here weirdo!!"
    d "¡¡Ey!! ¡¡Fuera de aquí bicho raro!!"

# game/script.rpy:159
translate Spanish nomes_72c42f63:

    # d "Ever since you guys showed up, people have been disappearing! Go back to whatever hellhole you crawled out of!"
    d "¡Desde que ustedes aparecieron, la gente ha estado desapareciendo! ¡Vuelvan al infierno del que salieron!"

# game/script.rpy:161
translate Spanish nomes_55fac95c:

    # mc "{color=#a0b0c0}(People have been treating them harshly, but just because someone ran off with a lover doesn’t mean it’s the circus’s fault, right?)"
    mc "{color=#a0b0c0}(La gente los ha estado tratando con dureza, pero sólo porque alguien se haya escapado con un amante no significa que sea culpa del circo, ¿verdad?)"

# game/script.rpy:162
translate Spanish nomes_499ca24a:

    # mc "{color=#a0b0c0}(I mean, I didn’t really pay much attention to the news to get the full story anyway.)"
    mc "{color=#a0b0c0}(Además, tampoco presté mucha atención a las noticias como para conocer toda la historia)."

# game/script.rpy:163
translate Spanish nomes_3bedd0cb:

    # mc "{color=#a0b0c0}(But apparently on their first day here, someone went missing, although there are rumors they ran off with a lover.)"
    mc "{color=#a0b0c0}(Pero aparentemente en su primer día aquí, alguien desapareció, aunque hay rumores de que se fugó con un amante.)"

# game/script.rpy:165
translate Spanish nomes_a2c05c64:

    # d "I’m talking to you, you freak! Get out of our town!!"
    d "¡Te estoy hablando a ti, monstruo! ¡¡Fuera de nuestro pueblo!!"

# game/script.rpy:167
translate Spanish nomes_7f1882d4:

    # mc "{color=#a0b0c0}(Okay, that guy’s really crossing the line now!!)"
    mc "{color=#a0b0c0}(¡¡Vale, ese tipo ya se está pasando de la raya!!)"

# game/script.rpy:172
translate Spanish nomes_66334b1c:

    # narrator "{color=#8faa7f}You put yourself in front of the man."
    narrator "{color=#8faa7f}Te pones delante del hombre."

# game/script.rpy:173
translate Spanish nomes_dde1674c:

    # mc "That’s enough! There’s no need to get violent! He’s just doing his job!"
    mc "¡Ya basta! ¡No hay necesidad de ponerse violento! ¡Él solo está haciendo su trabajo!"

# game/script.rpy:174
translate Spanish nomes_cebe62a5:

    # d "Working for the devil, maybe."
    d "Quizás trabajando para el diablo."

# game/script.rpy:175
translate Spanish nomes_cb2aba81:

    # mc "I’m calling the police if you keep this up."
    mc "Llamaré a la policía si sigues así."

# game/script.rpy:176
translate Spanish nomes_7a7d3111:

    # d "Screw that! Open your eyes. I hope they take you too!"
    d "¡Al diablo con eso! Abre los ojos. ¡Espero que te lleven a ti también!"

# game/script.rpy:177
translate Spanish nomes_1eb65334:

    # narrator "{color=#8faa7f}The man walks away."
    narrator "{color=#8faa7f}El hombre se aleja."

# game/script.rpy:181
translate Spanish nomes_625a9830:

    # mc "What do you think you’re doing? You can’t just attack someone like that! I’m calling the police!"
    mc "¿Qué crees que estás haciendo? ¡No puedes simplemente atacar a alguien así! ¡Estoy llamando a la policía!"

# game/script.rpy:182
translate Spanish nomes_5a01b236:

    # estranho "Yes, that's right. You’re going way too far."
    estranho "Sí, así es. Te estás pasando de la raya."

# game/script.rpy:183
translate Spanish nomes_cfa7cbd8:

    # d "Wake up, you idiots!! They’re the ones kidnapping people!"
    d "¡¡Despierten idiotas!! ¡Ellos son los que secuestran a la gente!"

# game/script.rpy:184
translate Spanish nomes_d7161645:

    # estranho "Stop with the paranoid nonsense. People go missing all the time."
    estranho "Basta ya de tonterías paranoicas. La gente desaparece todo el tiempo."

# game/script.rpy:185
translate Spanish nomes_f95f3ef7:

    # d "To hell with all of you!!"
    d "¡¡Al diablo con todos ustedes!!"

# game/script.rpy:186
translate Spanish nomes_1eb65334_1:

    # narrator "{color=#8faa7f}The man walks away."
    narrator "{color=#8faa7f}El hombre se aleja."

# game/script.rpy:190
translate Spanish nomes_3d685c82:

    # narrator "You watch the scene as the guy yells and kicks the clown. When a crowd starts to gather and watch, the man walks away."
    narrator "Ves cómo el tipo le grita al payaso y le da patadas. Cuando la gente empieza a reunirse para observar lo que ocurre, el hombre se aleja."

# game/script.rpy:191
translate Spanish nomes_e02e3cf1:

    # mc "{color=#a0b0c0}(Poor guy... I hope someone does something.)"
    mc "{color=#a0b0c0}(Pobre chico... Espero que alguien haga algo.)"

# game/script.rpy:196
translate Spanish ajudar_12aa87ac:

    # mc "Are you ok? I'll help you get up."
    mc "¿Estás bien? Te ayudaré a levantarte."

# game/script.rpy:203
translate Spanish ajudar_3b466448:

    # mc "{color=#a0b0c0}(Damn, he’s really tall!!)"
    mc "{color=#a0b0c0}(¡¡Maldita sea, es muy alto!!)"

# game/script.rpy:204
translate Spanish ajudar_1f62ed6e:

    # mc "Some people are kind of hot-headed... better not get too close, you know?"
    mc "Algunas personas son un poco impulsivas... mejor no acercarse demasiado, ¿sabes?"

# game/script.rpy:206
translate Spanish ajudar_b89421bc:

    # narrator "{color=#8faa7f}He nods."
    narrator "{color=#8faa7f}Él asiente."

# game/script.rpy:210
translate Spanish ajudar_938ebf10:

    # mc "Not everyone flips out like that guy. You’ll be fine, okay?"
    mc "No todo el mundo se vuelve loco como ese tipo. Estarás bien, ¿vale?"

# game/script.rpy:215
translate Spanish ajudar_f8752b09:

    # narrator "{color=#8faa7f}He walks up and slowly tilting his head, watching you."
    narrator "{color=#8faa7f}Se acerca, inclina lentamente la cabeza y te observa."

# game/script.rpy:228
translate Spanish ajudar_279b596b:

    # mc "Here, I’ve got a bandage take it."
    mc "Toma, tengo una venda. Aquí tienes."

# game/script.rpy:229
translate Spanish ajudar_e4301065:

    # mc "But if it still feels bad, you should see a doctor."
    mc "Pero si todavía te sientes mal, deberías ver a un médico."

# game/script.rpy:236
translate Spanish ajudar_222b0757:

    # narrator "{color=#8faa7f}He walks up and takes the bandage while slowly tilts his head, watching you."
    narrator "{color=#8faa7f}Se acerca y toma la venda mientras lentamente inclina la cabeza, mirándote."

# game/script.rpy:238
translate Spanish ajudar_714241a2:

    # mc "{color=#a0b0c0}(He seems excited about it)"
    mc "{color=#a0b0c0}(Parece emocionado por eso)"

# game/script.rpy:246
translate Spanish ajudar_8080eebd:

    # mc "{color=#a0b0c0}(So silent.)"
    mc "{color=#a0b0c0}(Muy silencioso.)"

# game/script.rpy:247
translate Spanish ajudar_ab69e26e:

    # mc "Well, I gotta go or I’ll be late. Take care, okay?"
    mc "Bueno, tengo que irme o llegaré tarde. Cuídate, ¿vale?"

# game/script.rpy:249
translate Spanish ajudar_262d0a09:

    # narrator "{color=#8faa7f}You step back and give a small wave before heading on your way."
    narrator "{color=#8faa7f}Das un paso atrás y saludas con la mano antes de seguir tu camino."

# game/script.rpy:262
translate Spanish trabalho_9b60e088:

    # c "You got here just in time. It’s busier than usual with the cold."
    c "Llegaste justo a tiempo. Está más lleno de lo habitual por el frío."

# game/script.rpy:263
translate Spanish trabalho_090dd181:

    # c "Start as soon as you can, Carol’s running late and I’ve been covering for her."
    c "Empieza tan pronto como puedas, Carol llega tarde y yo la he estado cubriendo."

# game/script.rpy:264
translate Spanish trabalho_062473d8:

    # c "The orders are already on the counter, please take them to the tables."
    c "Los pedidos ya están en el mostrador, por favor llévalos a las mesas."

# game/script.rpy:266
translate Spanish trabalho_ce44676d:

    # mc "You covered her whole shift? Is she okay?"
    mc "¿Cubriste todo su turno? ¿Está ella bien?"

# game/script.rpy:268
translate Spanish trabalho_e86a4bf3:

    # c "I couldn’t reach her. Maybe she’s not feeling well."
    c "No pude comunicarme con ella. Quizás no se sienta bien."

# game/script.rpy:270
translate Spanish trabalho_db693672:

    # mc "Got it, I’ll get started."
    mc "Entendido, empezaré."

# game/script.rpy:272
translate Spanish trabalho_6840457f:

    # c "Sure, thanks."
    c "Claro, gracias."

# game/script.rpy:300
translate Spanish mesa1_f682f33e:

    # mc "Good afternoon! Here’s your espresso and macchiato. Can I get you anything else?"
    mc "¡Buenas tardes! Aquí tienes tu espresso y macchiato. ¿Puedo traerte algo más?"

# game/script.rpy:302
translate Spanish mesa1_1a8ef3d3:

    # c1 "Thanks, I was dying for some coffee."
    c1 "Gracias, me moría por un poco de café."

# game/script.rpy:303
translate Spanish mesa1_04f88e48:

    # c2 "Did you see those flyers for the circus?"
    c2 "¿Viste esos folletos del circo?"

# game/script.rpy:304
translate Spanish mesa1_2a5426b6:

    # c1 "Yeah, weird, right? It’s been ages since a traveling circus came to town."
    c1 "Sí, raro, ¿verdad? Han pasado años desde que un circo ambulante llegó a la ciudad."

# game/script.rpy:305
translate Spanish mesa1_9e344f01:

    # c2 "And the clowns are so creepy..."
    c2 "Y los payasos son tan espeluznantes..."

# game/script.rpy:306
translate Spanish mesa1_66efd040:

    # c1 "Probably good for their marketing though..."
    c1 "Aunque probablemente sea bueno para su marketing..."

# game/script.rpy:307
translate Spanish mesa1_3f0f6936:

    # c1 "Oh, sorry! Yeah, we’re all set, we don’t need anything else right now."
    c1 "¡Ay, lo siento! Sí, ya estamos listos, no necesitamos nada más ahora."

# game/script.rpy:309
translate Spanish mesa1_1481d6de:

    # mc "No problem! Just call me if you need anything."
    mc "¡Ningún problema! Llámame si necesitas algo."

# game/script.rpy:318
translate Spanish mesa1_0bc49c68:

    # narrator "{color=#8faa7f}You arrange the trays neatly before making your way to the next table."
    narrator "{color=#8faa7f}Organizas las bandejas cuidadosamente antes de dirigirte a la siguiente mesa."

# game/script.rpy:327
translate Spanish mesa2_755e048d:

    # mc "Here you go, your hot chocolate."
    mc "Aquí tienes, tu chocolate caliente."

# game/script.rpy:329
translate Spanish mesa2_9bd4f608:

    # c3 "Thanks! I’ve really been craving something warm with this chilly weather."
    c3 "¡Gracias! Realmente se me antojaba algo calentito con este clima tan frío."

# game/script.rpy:331
translate Spanish mesa2_1a0df0cd:

    # mc "It got cold all of a sudden, didn’t it?"
    mc "De repente hizo frío, ¿no?"

# game/script.rpy:333
translate Spanish mesa2_464c25ad:

    # c3 "Yeah, the weather’s all over the place. You leave the house with a jacket and an umbrella, and you still end up sweating by the end of the day, haha."
    c3 "Sí, el clima está loquísimo. Sales de casa con una chaqueta y un paraguas, y aun así terminas sudando al final del día, jaja."

# game/script.rpy:335
translate Spanish mesa2_db445094:

    # mc "For real. If you need anything else, just let me know, okay?"
    mc "Totalmente. Si necesitas algo más, avísame, ¿sí?"

# game/script.rpy:337
translate Spanish mesa2_89f54c00:

    # c3 "Perfect!"
    c3 "¡Perfecto!"

# game/script.rpy:346
translate Spanish mesa2_4dabb003:

    # mc "Ouch! This coffee’s hot, I better get it to them quick."
    mc "¡Ay! Este café está caliente, será mejor llevárselo rápido."

# game/script.rpy:355
translate Spanish mesa3_e6842132:

    # mc "A coffee with cheese bread, and a cappuccino with a brownie, right?"
    mc "Un café con pan de queso y un capuchino con brownie, ¿no?"

# game/script.rpy:357
translate Spanish mesa3_9745d465:

    # c4 "That’s right, thanks!"
    c4 "Así es, ¡gracias!"

# game/script.rpy:358
translate Spanish mesa3_32456a1a:

    # c5 "Hey barista, did you see the news?"
    c5 "Oye, barista, ¿viste las noticias?"

# game/script.rpy:360
translate Spanish mesa3_823e0243:

    # mc "Hm? Not yet today, did something happen?"
    mc "¿Mmm? Todavía no. ¿Pasó algo?"

# game/script.rpy:362
translate Spanish mesa3_0ba26307:

    # c5 "They're still talking about the one who disappeared."
    c5 "Todavía hablan del que desapareció."

# game/script.rpy:364
translate Spanish mesa3_0f52442e:

    # mc "Oh, wasn’t that the one who ran off with a lover or something?"
    mc "Ah, ¿no era esa la persona que se había fugado con su pareja o algo así?"

# game/script.rpy:366
translate Spanish mesa3_c285e23c:

    # c4 "No one really knows for sure."
    c4 "Nadie lo sabe con certeza."

# game/script.rpy:367
translate Spanish mesa3_79a1f162:

    # c5 "I just wanted to say... Be careful if you're leaving late, okay?"
    c5 "Sólo quería decir... Ten cuidado si te vas tarde, ¿vale?"

# game/script.rpy:368
translate Spanish mesa3_66ea77ee:

    # c5 "This place closes quite late, so... stay alert, alright?"
    c5 "Este lugar cierra bastante tarde, así que... mantente alerta, ¿de acuerdo?"

# game/script.rpy:370
translate Spanish mesa3_74fee2ef:

    # mc "Will do. Thanks for the heads-up! And enjoy your coffee!"
    mc "Lo haré. ¡Gracias por el aviso! ¡Y disfruta de tu café!"

# game/script.rpy:379
translate Spanish mesa3_f83bfce6:

    # mc "It’s really sweet of them to care. Maybe I should start keeping an eye on the news sometimes."
    mc "Qué amables al preocuparse por mí. Quizás debería empezar a estar atent[letra] a las noticias de vez en cuando."

# game/script.rpy:386
translate Spanish posturno_e2aba339:

    # c "Tsk. I’m sick of ripping those flyers off my window, don’t let anyone hand them out in here."
    c "Tsk. Estoy harto de arrancar esos folletos de mi ventana..., no dejes que nadie los reparta aquí."

# game/script.rpy:387
translate Spanish posturno_4c9adb2d:

    # c "And when you have a minute, go around and pick up the ones scattered around."
    c "Y cuando tengas un minuto, date una vuelta por el local y recoge los que están esparcidos por ahí."

# game/script.rpy:389
translate Spanish posturno_3ab180c4:

    # mc "Got it!"
    mc "¡Entendido!"

# game/script.rpy:390
translate Spanish posturno_da6981b9:

    # mc "Hmn.. Some people are being kinda rude to the circus folks, don’t you think?"
    mc "Hmn... Algunas personas están siendo un poco groseras con la gente del circo, ¿no crees?"

# game/script.rpy:392
translate Spanish posturno_cac19c3b:

    # c "The way they act freaks people out. Best to keep them away, bad for business."
    c "Su forma de actuar asusta a la gente. Lo mejor es mantenerlos alejados; no le convienen al negocio."

# game/script.rpy:394
translate Spanish posturno_61b0aa61:

    # mc "Understood boss."
    mc "Entendido, jefe."

# game/script.rpy:402
translate Spanish cliente_suspeito_f1627925:

    # mc "The customers just keep leaving these on the tables…"
    mc "Los clientes siguen dejándolos en las mesas..."

# game/script.rpy:406
translate Spanish cliente_suspeito_383901c2:

    # mc "Welcome!"
    mc "¡Bienvenido!"

# game/script.rpy:408
translate Spanish cliente_suspeito_255606fd:

    # d "Thanks! I’d like a strong, hot coffee."
    d "¡Gracias! Me gustaría un café fuerte y caliente."

# game/script.rpy:410
translate Spanish cliente_suspeito_3d05a158:

    # mc "I’ll bring it right away."
    mc "Lo traeré enseguida."

# game/script.rpy:426
translate Spanish cliente_suspeito_49af21be:

    # mc "Here’s your coffee."
    mc "Aquí está tu café."

# game/script.rpy:428
translate Spanish cliente_suspeito_8cdb9fe4:

    # d "Thanks. It’s really cold outside."
    d "Gracias. Hace mucho frío afuera."

# game/script.rpy:429
translate Spanish cliente_suspeito_eb67562a:

    # d "What’s with those flyers?"
    d "¿Qué pasa con esos folletos?"

# game/script.rpy:431
translate Spanish cliente_suspeito_a0bc581c:

    # mc "Oh, someone was handing them out. I had to pick them all up."
    mc "Oh, alguien los estaba repartiendo. Tuve que recogerlos todos."

# game/script.rpy:433
translate Spanish cliente_suspeito_cfd65712:

    # d "How rude to do that in a place of business, right?"
    d "Qué grosería hacer eso en un establecimiento, ¿verdad?"

# game/script.rpy:435
translate Spanish cliente_suspeito_0c6874b4:

    # mc "Yeah, it just creates more work for everyone else."
    mc "Sí, simplemente crea más trabajo para todos los demás."

# game/script.rpy:437
translate Spanish cliente_suspeito_c9bfd80b:

    # d "If you want, I can take them for you. I’ll toss them out when I leave no big deal."
    d "Si quieres, puedo llevármelos. Los tiraré cuando me vaya, no pasa nada."

# game/script.rpy:438
translate Spanish cliente_suspeito_ab764953:

    # d "I was gathering some paper for recycling anyway."
    d "De todos modos estaba juntando papel para reciclar."

# game/script.rpy:440
translate Spanish cliente_suspeito_6170af08:

    # mc "Really? In that case, that’s better than just throwing them away, thanks."
    mc "¿De verdad? En ese caso, es mejor que acaben en el reciclaje a que los tiremos a la basura. Gracias."

# game/script.rpy:443
translate Spanish cliente_suspeito_02e65b1a:

    # d "No problems dear."
    d "No hay de qué, cariño."

# game/script.rpy:445
translate Spanish cliente_suspeito_db79838f:

    # mc "{cps=40}Do you need anyth--{nw}"
    mc "{cps=40}¿Necesitas alg--{nw}"

# game/script.rpy:446
translate Spanish cliente_suspeito_b3a8bbc9:

    # d "Do you like the circus?"
    d "¿Te gusta el circo?"

# game/script.rpy:448
translate Spanish cliente_suspeito_2234a2bf:

    # mc "Huh? Uh, I think I might be a little too old for that now."
    mc "¿Eh? Eh..., creo que quizá ya estoy un poco grandecit[letra] para esas cosas."

# game/script.rpy:450
translate Spanish cliente_suspeito_b2410030:

    # d "Nonsense. This circus isn’t for kids, they’ve got some pretty creepy stuff."
    d "Disparates. Este circo no es para niños, tienen cosas bastante espeluznantes."

# game/script.rpy:452
translate Spanish cliente_suspeito_47959375:

    # mc "So you’ve been to the circus?"
    mc "¿Entonces ya has ido al circo?"

# game/script.rpy:453
translate Spanish cliente_suspeito_a45c33d4:

    # mc "{color=#a0b0c0}(Even though I don’t really like chatting with people, it’s part of my job to be polite. Still, it’s always a little uncomfortable when customers try to keep me talking.)"
    mc "{color=#a0b0c0}(Aunque no me gusta mucho conversar con la gente, ser amable es parte de mi trabajo. Aun así, siempre me resulta un poco incómodo cuando los clientes intentan alargar la conversación.)"

# game/script.rpy:455
translate Spanish cliente_suspeito_652cde7f:

    # d "Are you even listening?"
    d "¿Estás siquiera escuchando?"

# game/script.rpy:457
translate Spanish cliente_suspeito_51d4ee8d:

    # mc "Sorry?"
    mc "¿Perdón?"

# game/script.rpy:459
translate Spanish cliente_suspeito_d091e6aa:

    # d "Haha, thought so. Anyway, here take this."
    d "Jaja, eso pensé. De todos modos, toma esto."

# game/script.rpy:460
translate Spanish cliente_suspeito_598b92ad:

    # d "Go on, check it out, and then try telling me it didn’t give you chills."
    d "Anda, échale un vistazo y después dime que no te puso la piel de gallina."

# game/script.rpy:465
translate Spanish cliente_suspeito_cbed5c84:

    # mc "N-no! I can’t accept something like that."
    mc "¡N-no! No puedo aceptar algo así."

# game/script.rpy:467
translate Spanish cliente_suspeito_4592432d:

    # d "Don’t worry, I already went. I was thinking of going again, but I’ll be leaving town soon."
    d "No te preocupes, ya fui. Estaba pensando en volver, pero pronto me iré de la ciudad."

# game/script.rpy:471
translate Spanish cliente_suspeito_7acf7ffc:

    # d "Come on, just take it. They’re for tonight."
    d "Vamos, acéptalos. Son para esta noche."

# game/script.rpy:473
translate Spanish cliente_suspeito_2f738c0a:

    # mc "W-well... I guess it’s okay."
    mc "B-bueno... supongo que está bien."

# game/script.rpy:477
translate Spanish cliente_suspeito_cb3946f6:

    # d "Keep it, or sell it if you want."
    d "Guárdalo o véndelo si quieres."

# game/script.rpy:479
translate Spanish cliente_suspeito_c14c584c:

    # mc "Well..."
    mc "Bueno..."

# game/script.rpy:488
translate Spanish cliente_suspeito_327b34b1:

    # mc "Thank you, I might try to go one day."
    mc "Gracias, tal vez intente ir algún día."

# game/script.rpy:489
translate Spanish cliente_suspeito_c20e5289:

    # d "I’ll be glad to know someone used my ticket."
    d "Me alegrará saber que alguien usó mi boleto."

# game/script.rpy:494
translate Spanish cliente_suspeito_cee5c2a1:

    # mc "That’s really kind, but I’m honestly not interested in the circus."
    mc "Es muy amable, pero sinceramente no me interesa el circo."

# game/script.rpy:495
translate Spanish cliente_suspeito_bee55946:

    # mc "{color=#a0b0c0}(Or in accepting gifts from strangers…)"
    mc "{color=#a0b0c0}(Ni en aceptar regalos de extraños…)"

# game/script.rpy:496
translate Spanish cliente_suspeito_fdb40ef5:

    # d "That’s a shame. I’ll try giving it to someone else, then."
    d "Es una pena. Entonces intentaré dárselo a otra persona."

# game/script.rpy:502
translate Spanish possivel_final_rosa_1e68928a:

    # d "Thanks for your time. I’ll let you get back to work."
    d "Gracias por tu tiempo. Te dejaré volver a trabajar."

# game/script.rpy:504
translate Spanish possivel_final_rosa_a89b9a1d:

    # mc "Let me know if you need anything else!"
    mc "¡Avísame si necesitas algo más!"

# game/script.rpy:510
translate Spanish possivel_final_rosa_db68d695:

    # c "As soon as the last customers leave, close everything up and clean the place. We’re closing early today."
    c "En cuanto se vayan los últimos clientes, cierra todo y limpia el lugar. Hoy cerraremos temprano."

# game/script.rpy:512
translate Spanish possivel_final_rosa_e3c4889f:

    # mc "Did something happen?"
    mc "¿Pasó algo?"

# game/script.rpy:517
translate Spanish possivel_final_rosa_327ca6fb:

    # c "I have an unexpected appointment. And since you’re working alone today, I’d rather you didn’t leave too late."
    c "Tengo una cita inesperada. Y como hoy estás trabajando sol[letra], preferiría que no te fueras demasiado tarde."

# game/script.rpy:518
translate Spanish possivel_final_rosa_b3aabca6:

    # c "I’ve gotta go now, can you take care of everything?"
    c "Me tengo que ir ahora, ¿puedes encargarte de todo?"

# game/script.rpy:520
translate Spanish possivel_final_rosa_d0d8b402:

    # mc "Yes! No problem, leave it to me!"
    mc "¡Sí! ¡No hay problema, déjamelo a mí!"

# game/script.rpy:522
translate Spanish possivel_final_rosa_d038c690:

    # c "Call me if anything comes up."
    c "Llámame si surge algo."

# game/script.rpy:524
translate Spanish possivel_final_rosa_c184e7f1:

    # mc "Will do. See you!"
    mc "Lo haré. ¡Nos vemos!"

# game/script.rpy:527
translate Spanish possivel_final_rosa_feffd4b6:

    # mc "{color=#a0b0c0}(Nice! Shorter work hours. But I hope Carol’s okay…)"
    mc "{color=#a0b0c0}(¡Bien! Horarios de trabajo más cortos. Pero espero que Carol esté bien...)"

# game/script.rpy:529
translate Spanish possivel_final_rosa_f14459eb:

    # d "Hey there, here’s the payment, I’m heading out."
    d "Hola, aquí está el pago, me voy."

# game/script.rpy:530
translate Spanish possivel_final_rosa_76742efa:

    # d "Have a good night!"
    d "¡Que tengas buenas noches!"

# game/script.rpy:532
translate Spanish possivel_final_rosa_17908b77:

    # mc "Good night, sir!"
    mc "¡Buenas noches, señor!"

# game/script.rpy:536
translate Spanish possivel_final_rosa_c59ff456:

    # mc "{color=#a0b0c0}(Perfect! Now I just need to clean the tables and I’m out of here.)"
    mc "{color=#a0b0c0}(¡Perfecto! Ahora solo necesito limpiar las mesas y me voy de aquí.)"

# game/script.rpy:545
translate Spanish possivel_final_rosa_dfae646d:

    # mc "Perfect! All clean, now I can go have a little fun."
    mc "¡Perfecto! Todo limpio, ahora puedo ir a divertirme un poco."

# game/script.rpy:553
translate Spanish apagao_e7bc9639:

    # mc "Sorry, we’re...{w=0.5} closed."
    mc "Lo sentimos, estamos...{w=0.5} cerrados."

# game/script.rpy:554
translate Spanish apagao_ab8ca15e:

    # mc "Huh? But I heard the bell{cps=10}... Hello?"
    mc "¿Eh? Pero escuché el timbre{cps=10}... ¿Hola?"

# game/script.rpy:560
translate Spanish apagao_9cdad7fc:

    # mc "{color=#a0b0c0}(I’m not imagining things… Someone could be in here… and they turned off the lights? But I can see the switches from here…)"
    mc "{color=#a0b0c0}(No me estoy imaginando cosas... Alguien podría estar aquí... ¿y apagaron las luces? Pero puedo ver los interruptores desde aquí...)"

# game/script.rpy:561
translate Spanish apagao_8bd59abd:

    # mc "Boss? Is that you?"
    mc "¿Jefe? ¿Eres tú?"

# game/script.rpy:562
translate Spanish apagao_b220e361:

    # narrator "{size=50}{cps=2}..."
    narrator "{size=50}{cps=2}..."

# game/script.rpy:565
translate Spanish apagao_1aa57148:

    # mc "{color=#a0b0c0}(Right… calm down, I’m overthinking this. I’ll just go around the counter and turn them back on.)"
    mc "{color=#a0b0c0}(Bien... cálmate, estoy pensando demasiado en esto. Simplemente rodearé el mostrador y los volveré a encender)."

# game/script.rpy:566
translate Spanish apagao_ad50187e:

    # mc "{color=#a0b0c0}(I can’t shake this feeling that I’m being watched…)"
    mc "{color=#a0b0c0}(No puedo quitarme la sensación de que me están observando…)"

# game/script.rpy:569
translate Spanish apagao_2a903cc3:

    # mc "{color=#a0b0c0}(Ok! Ok.... First, I’ll... )"
    mc "{color=#a0b0c0}(¡Ok! Ok... Primero, yo... )"

# game/script.rpy:578
translate Spanish apagao_a256354f:

    # narrator "{color=#8faa7f}You take a small kitchen knife."
    narrator "{color=#8faa7f}Coges un pequeño cuchillo de cocina."

# game/script.rpy:580
translate Spanish apagao_f1da31ea:

    # mc "This makes me feel a bit safer. Now…"
    mc "Esto me hace sentir un poco más segur[letra]. Ahora…"

# game/script.rpy:584
translate Spanish apagao_1db37f32:

    # narrator "{color=#8faa7f}You carefully scan the store in silence, gripping a small knife in your hand."
    narrator "{color=#8faa7f}Exploras cuidadosamente el local en silencio, sosteniendo un pequeño cuchillo en la mano."

# game/script.rpy:585
translate Spanish apagao_936a371d:

    # narrator "{color=#8faa7f}You check under the tables and move toward the counter, but see no one."
    narrator "{color=#8faa7f}Miras debajo de las mesas y te mueves hacia el mostrador, pero no ves a nadie."

# game/script.rpy:587
translate Spanish apagao_d311cdad:

    # mc "{color=#a0b0c0}(Whew… I think I’m just being paranoid.)"
    mc "{color=#a0b0c0}(Uf… creo que estoy siendo paranoic[letra].)"

# game/script.rpy:588
translate Spanish apagao_4429d27f:

    # mc "{color=#a0b0c0}(Now that I think about it… I heard the bell, but I never heard the door open.)"
    mc "{color=#a0b0c0}(Ahora que lo pienso… escuché el timbre, pero nunca escuché la puerta abrirse.)"

# game/script.rpy:593
translate Spanish luzes_1f34366d:

    # narrator "{color=#8faa7f}You run to the counter and try turning the lights back on."
    narrator "{color=#8faa7f}Corres hacia el mostrador e intentas volver a encender las luces."

# game/script.rpy:596
translate Spanish luzes_a42fab2b:

    # mc "Damn, it’s the breaker. Okay, stay calm... this is normal. It’s happened before."
    mc "Maldita sea, es el disyuntor. Está bien, mantén la calma... esto es normal. Ha sucedido antes."

# game/script.rpy:601
translate Spanish luzes_624dabe1:

    # narrator "{color=#8faa7f}You open the panel and reset the breaker."
    narrator "{color=#8faa7f}Abres el panel y reinicias el disyuntor."

# game/script.rpy:605
translate Spanish luzes_ab8bf187:

    # mc "{color=#a0b0c0}(Phew, it was all in my head.)"
    mc "{color=#a0b0c0}(Uf, todo estaba en mi cabeza.)"

# game/script.rpy:609
translate Spanish luzes_450c0c5a:

    # mc "{color=#a0b0c0}(Damn it, I should’ve locked the door.)"
    mc "{color=#a0b0c0}(Maldita sea, debería haber cerrado la puerta)."

# game/script.rpy:611
translate Spanish luzes_04bffb2a:

    # narrator "{color=#8faa7f}On high alert, you swiftly turn around as you speak once again."
    narrator "{color=#8faa7f}En alerta máxima, te das la vuelta rápidamente y vuelves a hablar."

# game/script.rpy:612
translate Spanish luzes_aae890ff:

    # mc "Sorry, we’re closed!{w=0.2} Ah!! You’re the guy from earlier..."
    mc "¡Lo sentimos, estamos cerrados!{w=0.2} ¡¡Ah!! Eres el chico de antes..."

# game/script.rpy:620
translate Spanish luzes_710198f7:

    # mc "Oh my, you’re bleeding! A-are you okay?"
    mc "¡Dios mío, estás sangrando! ¿E-estás bien?"

# game/script.rpy:621
translate Spanish luzes_eef7b0a2:

    # mc "{color=#a0b0c0}(Should I be worried about this guy? He kinda seems harmless… maybe 'cause he's always hurt.)"
    mc "{color=#a0b0c0}(¿Debería preocuparme por este tipo? Parece bastante inofensivo... tal vez porque siempre está herido.)"

# game/script.rpy:628
translate Spanish luzes_23f67361:

    # narrator "{color=#8faa7f}He stares, curious, at the small knife in your hands."
    narrator "{color=#8faa7f}Él mira, curioso, el pequeño cuchillo en tus manos."

# game/script.rpy:629
translate Spanish luzes_fbd3c473:

    # narrator "{color=#8faa7f}You smile awkwardly and put the knife away."
    narrator "{color=#8faa7f}Sonríes torpemente y guardas el cuchillo."

# game/script.rpy:630
translate Spanish luzes_6b46f9ef:

    # mc "Ah! Hahaha.... Sorry."
    mc "¡Oh! Jajaja.... Lo siento."

# game/script.rpy:636
translate Spanish luzes_23f67361_1:

    # narrator "{color=#8faa7f}He stares, curious, at the small knife in your hands."
    narrator "{color=#8faa7f}Él mira, curioso, el pequeño cuchillo en tus manos."

# game/script.rpy:637
translate Spanish luzes_983608f3:

    # narrator "{color=#8faa7f}You smile awkwardly and put the knife away"
    narrator "{color=#8faa7f}Sonríes torpemente y guardas el cuchillo."

# game/script.rpy:638
translate Spanish luzes_6b46f9ef_1:

    # mc "Ah! Hahaha.... Sorry."
    mc "¡Oh! Jajaja.... Lo siento."

# game/script.rpy:643
translate Spanish luzes_797611d5:

    # mc "Awwn Thanks!"
    mc "¡Awww, gracias!"

# game/script.rpy:644
translate Spanish luzes_fadd6717:

    # mc "Because of the bandage?"
    mc "¿Por el vendaje?"

# game/script.rpy:645
translate Spanish luzes_b89421bc:

    # narrator "{color=#8faa7f}He nods."
    narrator "{color=#8faa7f}Él asiente."

# game/script.rpy:646
translate Spanish luzes_64ef4dfc:

    # mc "{color=#a0b0c0}(It’s a really well-made paper flower, recently painted red. The paint’s still a little wet.)"
    mc "{color=#a0b0c0}(Es una flor de papel muy bien hecha, recientemente pintada de rojo. La pintura todavía está un poco húmeda)."

# game/script.rpy:647
translate Spanish luzes_a35f72d2:

    # mc "Still quiet..."
    mc "Sigue en silencio..."

# game/script.rpy:652
translate Spanish luzes_c14c584c:

    # mc "Well..."
    mc "Bueno..."

# game/script.rpy:656
translate Spanish luzes_94bd0bc8:

    # mc "I… uhn... I don’t want to be rude, but you can’t stay here. I need to close up, and you might get me in trouble."
    mc "Yo... uhn... no quiero ser groser[letra], pero no puedes quedarte aquí. Necesito cerrar y podrías meterme en problemas."

# game/script.rpy:670
translate Spanish luzes_6547a07d:

    # narrator "{color=#8faa7f}He gives a sad look and nods before heading out."
    narrator "{color=#8faa7f}Él da una mirada triste y asiente antes de salir."

# game/script.rpy:673
translate Spanish luzes_05b1717a:

    # mc "{color=#a0b0c0}(Did someone hurt him again? He’s so tall… it’s strange how people aren’t afraid to mess with a guy like that.)"
    mc "{color=#a0b0c0}(¿Alguien lo lastimó otra vez? Es tan alto… es extraño cómo la gente no tiene miedo de meterse con un tipo así.)"

# game/script.rpy:679
translate Spanish luzes_dbd9755a:

    # mc "Ugh, I hope I don’t regret this… Sit at the counter, I’ll help you with that."
    mc "Uf, espero no arrepentirme de esto… Siéntate en el mostrador, te ayudaré con eso."

# game/script.rpy:699
translate Spanish luzes_55c17bb7:

    # mc "{color=#a0b0c0}(What a weird mask… actually, I’m not sure if it’s a mask or just a ton of makeup…)"
    mc "{color=#a0b0c0}(Qué máscara más rara... en realidad, no estoy segur[letra] de si es una máscara o simplemente una tonelada de maquillaje...)"

# game/script.rpy:702
translate Spanish luzes_8e11eb1c:

    # narrator "{color=#8faa7f}You grab a paper napkin from the counter and gently wipe his face."
    narrator "{color=#8faa7f}Coges una servilleta de papel del mostrador y le limpias la cara suavemente."

# game/script.rpy:711
translate Spanish luzes_f1eac3a8:

    # mc "You don’t talk… or is that part of the act?"
    mc "No hablas… ¿o eso es parte del acto?"

# game/script.rpy:712
translate Spanish luzes_8c2d81d2:

    # narrator "{color=#8faa7f}He seems to glance around before stepping a little closer."
    narrator "{color=#8faa7f}Parece mirar a su alrededor antes de acercarse un poco más."

# game/script.rpy:732
translate Spanish luzes_a9d15034:

    # d "I can’t be seen talking."
    d "No se me puede ver hablando."

# game/script.rpy:733
translate Spanish luzes_100a6e7e:

    # mc "Ah, so it’s part of the act!"
    mc "¡Ah, entonces es parte del acto!"

# game/script.rpy:735
translate Spanish luzes_73176771:

    # d "Yes [titulo_pierrot]. I sincerely appreciate all your help."
    d "Sí, [titulo_pierrot!t]. Agradezco sinceramente toda tu ayuda."

# game/script.rpy:736
translate Spanish luzes_d6411bab:

    # p "I’m the Pierrot nice to meet you!"
    p "¡Soy el Pierrot, un placer conocerte!"

# game/script.rpy:737
translate Spanish luzes_d305754f:

    # mc "Nice to meet you! I'm [mc_nome]."
    mc "¡Encantad[letra] de conocerte! Soy [mc_nome]."

# game/script.rpy:738
translate Spanish luzes_c0b4c2c8:

    # p "{size=20}I know {nw=0.3}"
    p "{size=20}Lo sé {nw=0.3}"

# game/script.rpy:739
translate Spanish luzes_a0240a21:

    # mc "But, hm.. A Pierrot? You don’t really look like one."
    mc "Pero... ¿Un Pierrot? Realmente no lo pareces."

# game/script.rpy:740
translate Spanish luzes_cff3cb54:

    # mc "Wait what?{nw=0.5}"
    mc "Espera, ¿qué?{nw=0.5}"

# game/script.rpy:742
translate Spanish luzes_e4c8fdc9:

    # p "{b}Indeed, you are right [titulo_pierrot]!"
    p "{b}¡En efecto, tienes razón, [titulo_pierrot!t]!"

# game/script.rpy:743
translate Spanish luzes_41c21826:

    # p "We were required to… modernize my attire. But my role, remains unchanged."
    p "Se nos pidió que… modernizáramos mi vestimenta. Pero mi papel sigue siendo el mismo."

# game/script.rpy:745
translate Spanish luzes_d7e16ce6:

    # mc "People have been pretty rough with you guys."
    mc "La gente ha sido bastante dura con ustedes."

# game/script.rpy:764
translate Spanish luzes_8dc57f28:

    # p "I suppose we may appear a touch… uncanny. That tends to unsettle people."
    p "Supongo que podemos parecer un poco... extraños. Eso tiende a inquietar a la gente."

# game/script.rpy:766
translate Spanish luzes_abd1dfe8:

    # mc "Do the Pierrots out on the street with the flyers perform too?"
    mc "¿Los Pierrots que salen a la calle con los volantes también actúan?"

# game/script.rpy:783
translate Spanish luzes_e6f57954:

    # p "Indeed. The circus has but a small cast, we both perform and hand out flyers."
    p "En efecto. El circo tiene un elenco pequeño, actuamos y repartimos folletos."

# game/script.rpy:800
translate Spanish luzes_fb055bca:

    # p "Though I must say, I am the only Pierrot, [titulo_pierrot]. The others are Jesters and... {w=0.3}{cps=20}Harlequins..."
    p "Aunque debo decir que soy el único Pierrot, [titulo_pierrot!t]. Los demás son Bufones y... {w=0.3}{cps=20}Arlequines..."

# game/script.rpy:801
translate Spanish luzes_b5b7064b:

    # narrator "{color=#8faa7f}He pauses at the last part, rolling his eyes slightly."
    narrator "{color=#8faa7f}Hace una pausa en la última parte y pone los ojos en blanco ligeramente."

# game/script.rpy:803
translate Spanish luzes_d0283a12:

    # mc "{color=#a0b0c0}(Looks like he doesn’t get along with everyone.)"
    mc "{color=#a0b0c0}(Parece que no se lleva bien con todos.)"

# game/script.rpy:804
translate Spanish luzes_afdfaf8d:

    # mc "That’s actually kinda cool! So, are the others quiet like you too?"
    mc "¡Eso es realmente genial! Entonces, ¿los demás también son callados como tú?"

# game/script.rpy:821
translate Spanish luzes_c8b79ec3:

    # p "I am the only one who remains silent."
    p "Soy el único que permanece en silencio."

# game/script.rpy:822
translate Spanish luzes_90d239ab:

    # p "{i}Though I do make an exception when it’s just the two of us."
    p "{i}Aunque hago una excepción cuando estamos solos nosotros dos."

# game/script.rpy:823
translate Spanish luzes_710709cb:

    # mc "Got it. Your secret’s safe with me ♪"
    mc "Entiendo. Tu secreto está a salvo conmigo ♪"

# game/script.rpy:827
translate Spanish luzes_8c2fb5cd:

    # mc "Hey, your bandage’s coming off. Let me take it off for you."
    mc "Oye, se te está cayendo el vendaje. Déjame quitártelo."

# game/script.rpy:828
translate Spanish luzes_39c67a78:

    # mc "There we go!"
    mc "¡Listo!"

# game/script.rpy:840
translate Spanish luzes_a2fd119d:

    # p "Thank you [titulo_pierrot]."
    p "Gracias, [titulo_pierrot!t]."

# game/script.rpy:843
translate Spanish luzes_52dfdec4:

    # p "And I’ve brought you another small token of appreciation."
    p "Y te he traído otra pequeña muestra de agradecimiento."

# game/script.rpy:848
translate Spanish luzes_58641473:

    # mc "A ticket!"
    mc "¡Un boleto!"

# game/script.rpy:854
translate Spanish luzes_236f934d:

    # mc "Don’t worry, I just got one."
    mc "No te preocupes, acabo de conseguir uno."

# game/script.rpy:863
translate Spanish luzes_55fc60cc:

    # p "You... Obtained a ticket? May I see it, [titulo_pierrot]?"
    p "¿Tú... conseguiste un boleto? ¿Puedo verlo, [titulo_pierrot!t]?"

# game/script.rpy:864
translate Spanish luzes_8b4402ba:

    # mc "Sure, here you go."
    mc "Claro, aquí tienes."

# game/script.rpy:874
translate Spanish luzes_509af306:

    # mc "{color=#a0b0c0}(Hmn?)"
    mc "{color=#a0b0c0}(¿Mmm?)"

# game/script.rpy:875
translate Spanish luzes_445fdbdb:

    # narrator "{color=#8faa7f}He takes the ticket from your hands and holds it up in front of you."
    narrator "{color=#8faa7f}Él toma el boleto de tus manos y lo sostiene frente a ti."

# game/script.rpy:894
translate Spanish luzes_5bcb3c33:

    # mc "Whoa, cool trick! But why?"
    mc "¡Vaya, buen truco! ¿Pero por qué?"

# game/script.rpy:895
translate Spanish luzes_87138a0f:

    # narrator "{color=#8faa7f}He places the ticket into your hands."
    narrator "{color=#8faa7f}Pone el boleto en tus manos."

# game/script.rpy:904
translate Spanish luzes_605af5cb:

    # p "This ticket is incorrect. You wouldn’t be allowed in with it. Please, take mine instead."
    p "Este boleto no es válido. No te permitirían entrar con él. Por favor, toma el mío en su lugar."

# game/script.rpy:906
translate Spanish luzes_79908db6:

    # mc "Incorrect?... You mean it was fake?"
    mc "¿Incorrecto?... ¿Quieres decir que era falso?"

# game/script.rpy:908
translate Spanish luzes_a63d4541:

    # p "Indeed, counterfeit. Do not accept tickets from strangers, [titulo_pierrot]. I would not want you to encounter trouble at the entrance."
    p "En efecto, falso. No aceptes boletos de desconocidos, [titulo_pierrot!t]. No quisiera que tuvieras problemas en la entrada."

# game/script.rpy:910
translate Spanish luzes_d35d5f8f:

    # mc "Uh... right, thanks."
    mc "Eh... cierto, gracias."

# game/script.rpy:911
translate Spanish luzes_485a4a42:

    # mc "{color=#a0b0c0}(Why would that guy give me a fake one?)"
    mc "{color=#a0b0c0}(¿Por qué ese tipo me daría uno falso?)"

# game/script.rpy:914
translate Spanish luzes_d021101a:

    # mc "Are you sure? Won’t this get you in trouble?"
    mc "¿Estás seguro? ¿No te meterá esto en problemas?"

# game/script.rpy:916
translate Spanish luzes_242b8cff:

    # p "Not at all. We have a few special ones to hand out."
    p "Para nada. Tenemos algunos especiales para repartir."

# game/script.rpy:917
translate Spanish luzes_551c5197:

    # p "I’d be most delighted if you came to watch me, [titulo_pierrot]."
    p "Me alegraría muchísimo que vinieras a verme, [titulo_pierrot!t]."

# game/script.rpy:919
translate Spanish luzes_43c3dd84:

    # mc "Hmm… alright, I’ll take it. Sounds fun, after all."
    mc "Hmm… está bien, lo aceptaré. Suena divertido, después de todo."

# game/script.rpy:921
translate Spanish luzes_e44ea1dd:

    # p "I assure you, I’ll make you smile during my performance."
    p "Te lo aseguro, te haré sonreír durante mi actuación."

# game/script.rpy:923
translate Spanish luzes_3c0f6863:

    # mc "Can’t wait to see it! And sorry to say this, but..."
    mc "¡No puedo esperar a verlo! Y lamento decir esto, pero..."

# game/script.rpy:924
translate Spanish luzes_147af388:

    # mc "My boss told me to close up, we can’t stay too long here."
    mc "Mi jefe me dijo que cerrara, no podemos quedarnos mucho tiempo aquí."

# game/script.rpy:936
translate Spanish luzes_25dcb281:

    # p "I completely understand. I had hoped to arrive earlier but, I did not wish to cause you any distress, [titulo_pierrot]."
    p "Lo entiendo perfectamente. Esperaba llegar antes, pero no quería incomodarte, [titulo_pierrot!t]."

# game/script.rpy:938
translate Spanish luzes_aacca344:

    # mc "{color=#a0b0c0}(Honestly, I can see why some folks would feel uneasy.)"
    mc "{color=#a0b0c0}(Honestamente, puedo ver por qué algunas personas se sentirían incómodas)."

# game/script.rpy:939
translate Spanish luzes_1e3a6f6c:

    # mc "It’s alright. This way we got to talk a bit. Now I know you wouldn’t have been able to answer me in public."
    mc "Está bien. Así pudimos hablar un poco. Ahora sé que no habrías podido responderme en público."

# game/script.rpy:950
translate Spanish luzes_e913347b:

    # p "That’s true ♪"
    p "Eso es verdad ♪"

# game/script.rpy:951
translate Spanish luzes_7dade72d:

    # p "Have a good night, [titulo_pierrot]."
    p "Que tengas buenas noches, [titulo_pierrot!t]."

# game/script.rpy:953
translate Spanish luzes_8cc9d5f4:

    # mc "Good night!"
    mc "¡Buenas noches!"

# game/script.rpy:956
translate Spanish luzes_c0dd68f7:

    # mc "Well, time to go home."
    mc "Bueno, es hora de volver a casa."

# game/script.rpy:996
translate Spanish mandar_prafora_56b6b74e:

    # mc "{b}Ahh!!"
    mc "{b}¡¡Ah!!"

# game/script.rpy:997
translate Spanish mandar_prafora_d3efa08f:

    # mc "You... you scared me!"
    mc "¡Tú... me asustaste!"

# game/script.rpy:1000
translate Spanish mandar_prafora_f9264174:

    # narrator "He jumps in surprise too, accidentally hitting himself as he raises his hands, sending his bandage flying."
    narrator "Él también salta sorprendido, golpeándose accidentalmente mientras levanta las manos, haciendo volar su vendaje."

# game/script.rpy:1001
translate Spanish mandar_prafora_3491dd02:

    # narrator "His eyes follow it for a moment before he gestures again, trying to calm you down."
    narrator "Sus ojos lo siguen por un momento antes de volver a gesticular, tratando de calmarte."

# game/script.rpy:1004
translate Spanish mandar_prafora_a8a121f0:

    # narrator "He jumps in surprise too, raising his hands as if trying to calm you down."
    narrator "Él también salta sorprendido, levantando las manos como si intentara calmarte."

# game/script.rpy:1006
translate Spanish mandar_prafora_32276a7d:

    # mc "B-be careful, I could’ve hurt you."
    mc "T-ten cuidado, podría haberte lastimado."

# game/script.rpy:1012
translate Spanish mandar_prafora_a1088117:

    # narrator "He nods quickly and raises a finger, asking for a moment, then pulls a ticket from his clothes."
    narrator "Él asiente rápidamente y levanta un dedo, pidiendo un momento, luego saca un boleto de su ropa."

# game/script.rpy:1017
translate Spanish mandar_prafora_58641473:

    # mc "A ticket!"
    mc "¡Un boleto!"

# game/script.rpy:1021
translate Spanish mandar_prafora_236f934d:

    # mc "Don’t worry, I just got one."
    mc "No te preocupes, acabo de conseguir uno."

# game/script.rpy:1025
translate Spanish mandar_prafora_d4cd93fd:

    # mc "See?"
    mc "¿Ves?"

# game/script.rpy:1033
translate Spanish mandar_prafora_509af306:

    # mc "{color=#a0b0c0}(Hmn?)"
    mc "{color=#a0b0c0}(¿Mmm?)"

# game/script.rpy:1034
translate Spanish mandar_prafora_af4ab462:

    # narrator "He takes the ticket from your hands and holds it up in front of you."
    narrator "Toma el boleto de tus manos y lo sostiene frente a ti."

# game/script.rpy:1052
translate Spanish mandar_prafora_5bcb3c33:

    # mc "Whoa, cool trick! But why?"
    mc "¡Vaya, buen truco! ¿Pero por qué?"

# game/script.rpy:1053
translate Spanish mandar_prafora_3faece39:

    # narrator "He hands the ticket into your hands"
    narrator "Él te entrega el boleto en tus manos."

# game/script.rpy:1055
translate Spanish mandar_prafora_d07504a8:

    # mc "Ah, well... I guess that’s alright."
    mc "Ah, bueno... supongo que está bien."

# game/script.rpy:1060
translate Spanish mandar_prafora_6b845a18:

    # mc "Is this for me?"
    mc "¿Esto es para mí?"

# game/script.rpy:1062
translate Spanish mandar_prafora_3faece39_1:

    # narrator "He hands the ticket into your hands"
    narrator "Él te entrega el boleto en tus manos."

# game/script.rpy:1067
translate Spanish mandar_prafora_324943cc:

    # mc "{color=#a0b0c0}(Well, I guess there’s no harm in accepting. He’s with the circus, so he must have a few extras.)"
    mc "{color=#a0b0c0}(Bueno, supongo que no hay nada de malo en aceptar. Él está en el circo, por lo que debe tener algunos extras)."

# game/script.rpy:1068
translate Spanish mandar_prafora_503467bf:

    # mc "Thanks! But won’t this get you in trouble?"
    mc "¡Gracias! ¿Pero esto no te meterá en problemas?"

# game/script.rpy:1070
translate Spanish mandar_prafora_7a6a9af4:

    # narrator "He leans in slightly and gives a small shake of his head."
    narrator "Se inclina ligeramente y sacude ligeramente la cabeza."

# game/script.rpy:1072
translate Spanish mandar_prafora_b6468969:

    # mc "Well, alright. I guess I can stop by tomorrow."
    mc "Bueno, está bien. Supongo que puedo pasar mañana."

# game/script.rpy:1078
translate Spanish mandar_prafora_031fd72c:

    # mc "{color=#a0b0c0}(He looks excited.)"
    mc "{color=#a0b0c0}(Parece emocionado.)"

# game/script.rpy:1080
translate Spanish mandar_prafora_0e61bdb5:

    # mc "There's 'Pierrot' written by hand on the ticket. Is that your name?"
    mc "Hay \"Pierrot\" escrito a mano en el boleto. ¿Ese es tu nombre?"

# game/script.rpy:1082
translate Spanish mandar_prafora_2fb1ebd2:

    # narrator "He nods his head frantically."
    narrator "Asiente frenéticamente con la cabeza."

# game/script.rpy:1084
translate Spanish mandar_prafora_22c3e858:

    # mc "Oh! Right, got it."
    mc "¡Ah! Claro, entendido."

# game/script.rpy:1086
translate Spanish mandar_prafora_fc0519d4:

    # mc "I should get going before it gets too late. Good night!"
    mc "Debería irme antes de que sea demasiado tarde. ¡Buenas noches!"

# game/script.rpy:1088
translate Spanish mandar_prafora_0bb45730:

    # narrator "He bows again and gives [persistent.p_objeto] a warm smile as he waves."
    narrator "Hace otra reverencia y le dedica una cálida sonrisa mientras se despide con la mano."

# game/script.rpy:1092
translate Spanish mandar_prafora_c0dd68f7:

    # mc "Well, time to go home."
    mc "Bueno, es hora de volver a casa."

# game/script.rpy:1098
translate Spanish casa_a8285dc9:

    # mc "I got back earlier, but I still feel just as tired as on a normal day. At least my shift starts later tomorrow."
    mc "Regresé más temprano, pero todavía me siento tan cansad[letra] como en un día normal. Al menos mi turno comienza más tarde mañana."

# game/script.rpy:1099
translate Spanish casa_cd6ae80b:

    # mc "I'll take a quick shower and crash in bed."
    mc "Me daré una ducha rápida y caeré rendid[letra] en la cama."

# game/script.rpy:1104
translate Spanish casa_91fcbe5a:

    # mc "I was unsure about the circus, but it might be fun. They have this kind of gothic and eccentric style, and the ticket was pretty expensive."
    mc "No estaba segur[letra] de lo del circo, pero podría ser divertido. Tienen un estilo gótico y excéntrico, y el boleto era bastante caro."

# game/script.rpy:1105
translate Spanish casa_f9b7db2c:

    # mc "I hope it’s okay that I agreed to go."
    mc "Espero que esté bien que haya aceptado ir."

# game/script.rpy:1111
translate Spanish casa_dceb6f9e:

    # mc "What a cold wind…"
    mc "¡Qué viento tan frío…!"

# game/script.rpy:1117
translate Spanish casa_be67c463:

    # mc "Much better!"
    mc "¡Mucho mejor!"

# game/script.rpy:1118
translate Spanish casa_60bb3063:

    # mc "So sleepy… I’ll just watch a bit of TV until I fall asleep…"
    mc "Tengo mucho sueño… Solo miraré un poco de televisión hasta quedarme dormid[letra]…"

# game/script.rpy:1131
translate Spanish casa_bc2f4c68:

    # mc "Zzz"
    mc "zzz"

# game/script.rpy:1141
translate Spanish casa_4782bbfa:

    # p "{cps=50}Ah [titulo_pierrot],{w=0.5} You…"
    p "{cps=50}Ah, [titulo_pierrot!t],{w=0.5} tú…"

# game/script.rpy:1141
translate Spanish casa_7296d880:

    # p "{cps=50}You are even more beautiful in your sleep."
    p "{cps=50}Eres aún más hermos[letra] mientras duermes."

# game/script.rpy:1141
translate Spanish casa_3e4b6688:

    # p "{cps=50}So fragile… so defenseless..."
    p "{cps=50}Tan frágil… tan indefens[letra]…"

# game/script.rpy:1141
translate Spanish casa_733605e8:

    # p "{cps=50}You do not even know me… But I know everything about you."
    p "{cps=50}Ni siquiera me conoces… Pero yo sé todo sobre ti."

# game/script.rpy:1141
translate Spanish casa_46d56e87:

    # p "{cps=50}Every step you take, your routines, your preferences..."
    p "{cps=50}Cada paso que das, tus rutinas, tus preferencias..."

# game/script.rpy:1141
translate Spanish casa_3d9936ca:

    # p "{cps=50}Even the way your brow furrows when you are confused... or afraid."
    p "{cps=50}Incluso la forma en que frunces el ceño cuando estás confundid[letra]... o asustad[letra]."

# game/script.rpy:1141
translate Spanish casa_787d3053:

    # p "Ah... utterly adorable."
    p "Ah... absolutamente adorable."

# game/script.rpy:1162
translate Spanish casa_4f543145:

    # p "I knew the moment I saw you… today."
    p "Lo supe en el momento en que te vi... hoy."

# game/script.rpy:1162
translate Spanish casa_b5e4f8a8:

    # p "{b}It was just a glance… but something inside me ignited, and now…"
    p "{b}Fue solo una mirada… pero algo dentro de mí se encendió, y ahora…"

# game/script.rpy:1162
translate Spanish casa_a839ea2a:

    # p "{b}There is no turning back."
    p "{b}No hay vuelta atrás."

# game/script.rpy:1162
translate Spanish casa_ee824d6b:

    # p "{b}There is nowhere left to run."
    p "{b}No queda ningún lugar al que huir."

# game/script.rpy:1162
translate Spanish casa_8d1d9139:

    # p "I needed to see you with my own eyes…"
    p "Necesitaba verte con mis propios ojos..."

# game/script.rpy:1162
translate Spanish casa_87d8d5eb:

    # p "To be certain that you were real."
    p "Para estar seguro de que eras real."

# game/script.rpy:1162
translate Spanish casa_acee81af:

    # p "{b}And you are."
    p "{b}Y lo eres."

# game/script.rpy:1162
translate Spanish casa_d52bcedd:

    # p "{sc=1}{color=#ffaf54}You must be mine."
    p "{sc=1}{color=#ffaf54}Debes ser mí[letra]."

# game/script.rpy:1162
translate Spanish casa_a5609af9:

    # p "{sc=1}{color=#ffaf54}You will be mine."
    p "{sc=1}{color=#ffaf54}Serás mí[letra]."

# game/script.rpy:1194
translate Spanish diaseguinte_e232d0b3:

    # mc "!!!"
    mc "!!!"

# game/script.rpy:1195
translate Spanish diaseguinte_dae8fa71:

    # mc "A nightmare? Wow… what a scare. I guess I was overthinking things yesterday."
    mc "¿Una pesadilla? Vaya... qué susto. Supongo que ayer estuve pensando demasiado."

# game/script.rpy:1196
translate Spanish diaseguinte_6074cd3e:

    # mc "Weird, I don’t remember turning off the TV last night. Was I that tired?"
    mc "Qué raro, no recuerdo haber apagado la televisión anoche. ¿Estaba tan cansad[letra]?"

# game/script.rpy:1197
translate Spanish diaseguinte_c056146f:

    # mc "{cps=10}..."
    mc "{cps=10}..."

# game/script.rpy:1198
translate Spanish diaseguinte_0b332e9e:

    # mc "No, I definitely didn’t turn it off… And I have a strange taste in my mouth..."
    mc "No, definitivamente no lo apagué… Y tengo un sabor extraño en la boca…"

# game/script.rpy:1199
translate Spanish diaseguinte_3a01dc83:

    # mc "Damn, I overslept!!" with vpunch
    mc "¡¡Maldición, me quedé dormid[letra]!!" with vpunch

# game/script.rpy:1200
translate Spanish diaseguinte_9f862ba2:

    # mc "I’ll just leave something on the TV while I have breakfast and get ready for work."
    mc "Dejaré algo puesto en la televisión mientras desayuno y me preparo para ir a trabajar."

# game/script.rpy:1204
translate Spanish diaseguinte_d58b53ee:

    # w "The circus's popularity has been rising it's become the main event of the season!"
    w "¡La popularidad del circo ha ido aumentando y se ha convertido en el evento principal de la temporada!"

# game/script.rpy:1205
translate Spanish diaseguinte_6c453614:

    # f "Have you seen the show, William?"
    f "¿Has visto el espectáculo, William?"

# game/script.rpy:1206
translate Spanish diaseguinte_89b1313f:

    # w "Absolutely! But it's really not for the whole family. It's unlike anything I've ever seen. People are weirded out by the clowns’ design, but they’re incredibly talented."
    w "¡Absolutamente! Pero en realidad no es para toda la familia. No se parece a nada que haya visto jamás. A la gente le resulta inquietante el diseño de los payasos, pero son increíblemente talentosos."

# game/script.rpy:1207
translate Spanish diaseguinte_08f21826:

    # f "I actually find them quite adorable. It's worth watching the performance."
    f "De hecho, me parecen bastante adorables. Vale la pena ver la actuación."

# game/script.rpy:1208
translate Spanish diaseguinte_592041e7:

    # f "But be careful with the food at the stalls some have been shut down. Apparently, a few people were selling food illegally near the circus."
    f "Pero cuidado con la comida de los puestos: algunos han sido clausurados. Al parecer, algunas personas vendían comida ilegalmente cerca del circo."

# game/script.rpy:1209
translate Spanish diaseguinte_e7c73cca:

    # w "Oh, that always ends up happening."
    w "Oh, eso siempre termina pasando."

# game/script.rpy:1211
translate Spanish diaseguinte_8a9fe9c9:

    # mc "Time to go. I just need to find my bag."
    mc "Es hora de irse. Sólo necesito encontrar mi bolso."

# game/script.rpy:1213
translate Spanish diaseguinte_5ba8e596:

    # w "Now for a not-so-warm piece of news another girl went missing yesterday morning. She had family issues and never returned home. The family suspects she may have run away after an argument…"
    w "Ahora, una noticia no tan buena: otra joven desapareció ayer por la mañana. Tuvo problemas familiares y nunca regresó a casa. La familia sospecha que ella pudo haberse escapado después de una discusión..."

# game/script.rpy:1215
translate Spanish diaseguinte_3f6c195a:

    # mc "Where is it, where is it?? I could’ve sworn I tossed my bag around here…"
    mc "¿Dónde está, dónde está? Podría jurar que dejé mi bolso por aquí..."

# game/script.rpy:1219
translate Spanish diaseguinte_becc01b2:

    # w "However, a bag with her belongings was found near the city bus station. Police are investigating the area."
    w "Sin embargo, cerca de la estación de autobuses de la ciudad se encontró una bolsa con sus pertenencias. La policía está investigando la zona."

# game/script.rpy:1221
translate Spanish diaseguinte_52a500d3:

    # mc "Found it!!"
    mc "¡¡Lo encontré!!"

# game/script.rpy:1226
translate Spanish diaseguinte_d2b4df8b:

    # mc "Time to go."
    mc "Es hora de irse."

# game/script.rpy:1232
translate Spanish rua_c20ecebe:

    # mc "Ugh, flyers everywhere again, are they polluting the whole city with these things?"
    mc "Uf, volantes por todas partes otra vez, ¿están contaminando toda la ciudad con estas cosas?"

# game/script.rpy:1235
translate Spanish rua_4642162d:

    # d "Care to visit the circus? I bet you’ll be surprised ♪ {w=0.2} Here, take a flyer!"
    d "¿Te gustaría visitar el circo? Apuesto a que te sorprenderás ♪ {w=0.2} ¡Toma un volante!"

# game/script.rpy:1237
translate Spanish rua_c407b5ab:

    # mc "No thanks, I already got a ticket."
    mc "No gracias, ya tengo un boleto."

# game/script.rpy:1239
translate Spanish rua_1a2ef075:

    # d "Oh! Wonderful!! You got one? {w=0.3}Was it{cps=10} a pink one,{w=0.5} then?"
    d "¡Oh! ¡¡Maravilloso!! ¿Tienes uno? {w=0.3}¿Era{cps=10} uno rosa,{w=0.5} entonces?"

# game/script.rpy:1241
translate Spanish rua_f89b4e92:

    # mc "{color=#a0b0c0}(He started following me... I should’ve just stayed quiet...)"
    mc "{color=#a0b0c0}(Él comenzó a seguirme... debería haberme quedado callad[letra]...)"

# game/script.rpy:1242
translate Spanish rua_39b58590:

    # mc "It was red, actually."
    mc "En realidad, era rojo."

# game/script.rpy:1247
translate Spanish rua_d118d153:

    # narrator "He stops in front of you, blocking your way."
    narrator "Se detiene frente a ti, cortándote el paso."

# game/script.rpy:1256
translate Spanish rua_1abbdc0c:

    # d "A red one??"
    d "¿Uno rojo?"

# game/script.rpy:1262
translate Spanish rua_023bcb91:

    # mc "Excuse me, I don’t want to be late."
    mc "Disculpe, no quiero llegar tarde."

# game/script.rpy:1272
translate Spanish rua_4b97ca35:

    # narrator "He lets you through, but keeps following you."
    narrator "Te deja pasar, pero te sigue."

# game/script.rpy:1274
translate Spanish rua_c08e8703:

    # narrator "You walk past him, but he keeps following you."
    narrator "Pasas junto a él, pero sigue siguiéndote."

# game/script.rpy:1287
translate Spanish rua_01a1afe7:

    # d "A red one, huh? So that Pierrot gave it to you? Interesting ♪"
    d "Uno rojo, ¿eh? ¿Entonces Pierrot te lo dio? Interesante ♪"

# game/script.rpy:1294
translate Spanish rua_e342242b:

    # a "I'm the Harlequin, [titulo_arlequim]."
    a "Soy el Arlequín, [titulo_arlequim!t]."

# game/script.rpy:1295
translate Spanish rua_61d9053f:

    # a "Ah! I’ve got an idea!"
    a "¡Oh! ¡Tengo una idea!"

# game/script.rpy:1296
translate Spanish rua_a273b882:

    # a "How about we trade? I give you mine and… you give me that red one."
    a "¿Qué tal si hacemos un intercambio? Yo te doy el mío y… tú me das ese rojo."

# game/script.rpy:1301
translate Spanish rua_6af0b349:

    # mc "What difference does it make? Why are there different colors?"
    mc "¿Qué importa? ¿Por qué hay diferentes colores?"

# game/script.rpy:1311
translate Spanish rua_b0bcfa86:

    # a "Oh my..."
    a "Oh, vaya..."

# game/script.rpy:1318
translate Spanish rua_4ce6f7e3:

    # a "Speak of the {i}devil."
    a "Hablando del {i}diablo."

# game/script.rpy:1323
translate Spanish rua_8e2365b3:

    # narrator "The Pierrot snatches the green ticket from Harlequin’s hand."
    narrator "El Pierrot arrebata el boleto verde de la mano del Arlequín."

# game/script.rpy:1325
translate Spanish rua_db1ec8be:

    # a " {i}Sigh..."
    a " {i}Suspiro..."

# game/script.rpy:1327
translate Spanish rua_8bf59ace:

    # mc "{color=#a0b0c0}(Did I just walk into some kind of act? I better slip away quietly.)"
    mc "{color=#a0b0c0}(¿Acabo de entrar en algún tipo de acto? Será mejor que me aleje en silencio.)"

# game/script.rpy:1329
translate Spanish rua_f7a78788:

    # a "Such a shame you don’t have a voice, huh, Pierrot?"
    a "Qué pena que no tengas voz, ¿eh, Pierrot?"

# game/script.rpy:1348
translate Spanish rua_b1518ddd:

    # a "Guess you can’t say all those nasty things you’re thinking~"
    a "Supongo que no puedes decir todas esas cosas desagradables que estás pensando~"

# game/script.rpy:1368
translate Spanish rua_608ff670:

    # a "Just wait 'til the Jester hears about this, heh!"
    a "Ya verás cuando el Bufón se entere de esto, ¡je!"

# game/script.rpy:1370
translate Spanish rua_555df71d:

    # narrator "You take small steps, slowly backing away. Once you’re a safe distance from their argument, you pick up the pace and head to work."
    narrator "Das pequeños pasos y retrocedes lentamente. Una vez que estás lo suficientemente lejos de su discusión, aceleras el paso y te diriges al trabajo."

# game/script.rpy:1379
translate Spanish trabalho_dia2_90b70b4b:

    # mc "{i}Sigh..."
    mc "{i}Suspiro..."

# game/script.rpy:1380
translate Spanish trabalho_dia2_326835f4:

    # mc "Made it on time, phew… Boss, I brought the… keys."
    mc "Llegué a tiempo, uf… Jefe, traje las… llaves."

# game/script.rpy:1381
translate Spanish trabalho_dia2_94a58088:

    # mc "{color=#a0b0c0}(Is he talking to a cop?)"
    mc "{color=#a0b0c0}(¿Está hablando con un policía?)"

# game/script.rpy:1383
translate Spanish trabalho_dia2_b97d5ceb:

    # c "Just leave the keys on the counter, I’ll talk to you in a sec."
    c "Deja las llaves en el mostrador, te hablaré en un segundo."

# game/script.rpy:1385
translate Spanish trabalho_dia2_bf629b2e:

    # mc "{color=#a0b0c0}(What happened this time? The store looks fine, doesn’t seem like it was broken into… did something happen to Carol?)"
    mc "{color=#a0b0c0}(¿Qué pasó esta vez? El local se ve bien, no parece que hayan entrado por la fuerza… ¿le pasó algo a Carol?)"

# game/script.rpy:1389
translate Spanish trabalho_dia2_2150b895:

    # c "Alright, was it a hassle closing the store last night?"
    c "Bueno, ¿fue complicado cerrar el local anoche?"

# game/script.rpy:1391
translate Spanish trabalho_dia2_872a56bc:

    # mc "N-no, it was fine… what happened?"
    mc "N-no, estuvo bien… ¿qué pasó?"

# game/script.rpy:1396
translate Spanish trabalho_dia2_1c25027e:

    # c "Well... Carol didn’t come home last night. Looks like she ran away."
    c "Bueno... Carol no volvió a casa anoche. Parece que ella se escapó."

# game/script.rpy:1398
translate Spanish trabalho_dia2_149aa4eb:

    # mc "She ran away?? She had issues with her family, yeah, but running away like that… that’s weird."
    mc "¿Ella se escapó? Tenía problemas con su familia, sí, pero huir así… eso es raro."

# game/script.rpy:1399
translate Spanish trabalho_dia2_dd4491ca:

    # mc "She didn’t show any signs she’d do something like this."
    mc "Ella no mostró ninguna señal de que fuera a hacer algo como esto."

# game/script.rpy:1401
translate Spanish trabalho_dia2_5a6aeefd:

    # c "She must have her reasons. If she shows up here, we’re supposed to notify the police."
    c "Ella debe tener sus razones. Si aparece aquí, se supone que debemos notificar a la policía."

# game/script.rpy:1402
translate Spanish trabalho_dia2_5541666e:

    # c "Carol’s probably not in a good state of mind."
    c "Probablemente Carol no esté bien mentalmente."

# game/script.rpy:1407
translate Spanish trabalho_dia2_c001d2b6:

    # c "I’m going to start looking for a new employee, so I’ll be in the back doing interviews."
    c "Voy a empezar a buscar un nuevo empleado, así que estaré atrás haciendo entrevistas."

# game/script.rpy:1408
translate Spanish trabalho_dia2_1d795f11:

    # c "Once your shift’s over, you can head home. I’ve got the store covered."
    c "Cuando termine tu turno, puedes volver a casa. Yo me encargo del local."

# game/script.rpy:1410
translate Spanish trabalho_dia2_599093e2:

    # mc "Oh, sure."
    mc "Ah, claro."

# game/script.rpy:1411
translate Spanish trabalho_dia2_0226e756:

    # mc "{color=#a0b0c0}(I never thought she’d do something like that. Then again, I guess we were just coworkers…)"
    mc "{color=#a0b0c0}(Nunca pensé que ella haría algo así. Por otra parte, supongo que solo éramos compañeros de trabajo…)"

# game/script.rpy:1412
translate Spanish trabalho_dia2_b8c978ea:

    # mc "{color=#a0b0c0}(She never told me anything. But she was always so responsible… and said she really needed this job.)"
    mc "{color=#a0b0c0}(Ella nunca me dijo nada. Pero siempre fue muy responsable... y dijo que realmente necesitaba este trabajo.)"

# game/script.rpy:1415
translate Spanish trabalho_dia2_3af6b616:

    # mc "{color=#a0b0c0}(Maybe she was under a lot of stress at home.)"
    mc "{color=#a0b0c0}(Tal vez estaba bajo mucho estrés en casa)."

# game/script.rpy:1416
translate Spanish trabalho_dia2_90b70b4b_1:

    # mc "{i}Sigh..."
    mc "{i}Suspiro..."

# game/script.rpy:1421
translate Spanish trabalho_dia2_940d7423:

    # mc "Good morning!{w=0.3} Ah!"
    mc "¡Buenos días!{w=0.3}¡Oh!"

# game/script.rpy:1425
translate Spanish trabalho_dia2_c1a8a78e:

    # mc "It's you again! Want something to drink, Pierrot?"
    mc "¡Eres tú otra vez! ¿Quieres algo de beber, Pierrot?"

# game/script.rpy:1431
translate Spanish trabalho_dia2_2e6c9a38:

    # narrator "He nods, and points at a milkshake."
    narrator "Él asiente y señala un batido."

# game/script.rpy:1433
translate Spanish trabalho_dia2_96953de9:

    # mc "A milkshake? Isn’t it a bit cold for that? Haha."
    mc "¿Un batido? ¿No hace un poco de frío para eso? Ja, ja."

# game/script.rpy:1434
translate Spanish trabalho_dia2_67d1b077:

    # mc "Alright, have a seat and I’ll bring it to your table."
    mc "Muy bien, toma asiento y te lo llevaré a tu mesa."

# game/script.rpy:1436
translate Spanish trabalho_dia2_0bb44312:

    # narrator "He nods again and walks away from the counter."
    narrator "Él asiente de nuevo y se aleja del mostrador."

# game/script.rpy:1447
translate Spanish trabalho_dia2_71999359:

    # c "[mc_nome], did he buy anything?"
    c "[mc_nome], ¿compró algo?"

# game/script.rpy:1449
translate Spanish trabalho_dia2_db42d726:

    # mc "Yeah, a milkshake."
    mc "Sí, un batido."

# game/script.rpy:1451
translate Spanish trabalho_dia2_f29e1059:

    # c "Good. I don’t want those guys hanging around here without buying anything. Let him know we don’t allow flyering inside."
    c "Bien. No quiero que esos tipos se queden por aquí sin comprar nada. Hazle saber que no permitimos repartir volantes aquí dentro."

# game/script.rpy:1453
translate Spanish trabalho_dia2_3ab180c4:

    # mc "Got it!"
    mc "¡Entendido!"

# game/script.rpy:1468
translate Spanish trabalho_dia2_d4463f1d:

    # mc "{color=#a0b0c0}(Damn it, this again!?)"
    mc "{color=#a0b0c0}(Maldita sea, ¿¡esto otra vez!?)"

# game/script.rpy:1469
translate Spanish trabalho_dia2_cc66ed27:

    # mc "W-whoa, you scared me! I thought you sat on the table or something…"
    mc "¡Vaya, me asustaste! Pensé que te habías sentado en una mesa o algo así..."

# game/script.rpy:1470
translate Spanish trabalho_dia2_e18b6a6d:

    # mc "{color=#a0b0c0}(He’s really close.)"
    mc "{color=#a0b0c0}(Está muy cerca.)"

# game/script.rpy:1472
translate Spanish trabalho_dia2_7f180330:

    # narrator "He grabs your arm firmly, locking eyes with you, then makes a gesture, calling you closer."
    narrator "Te agarra el brazo con firmeza, te mira a los ojos y luego hace un gesto para llamarte más cerca."

# game/script.rpy:1474
translate Spanish trabalho_dia2_61aecca1:

    # mc "What is it…?"
    mc "¿Qué pasa…?"

# game/script.rpy:1476
translate Spanish trabalho_dia2_7742b6c3:

    # narrator "He whispers."
    narrator "Él susurra."

# game/script.rpy:1483
translate Spanish trabalho_dia2_3f880e35:

    # p "{size=25}{cps=10}Is he…{w=0.2} being mean to you,{w=0.2} [titulo_pierrot]?"
    p "{size=25}{cps=10}¿Él…{w=0.2} está siendo malo contigo,{w=0.2} [titulo_pierrot!t]?"

# game/script.rpy:1485
translate Spanish trabalho_dia2_c09c8a97:

    # mc "Huh? M-my boss? Haha, no, no!"
    mc "¿Eh? ¿M-mi jefe? ¡Jaja, no, no!"

# game/script.rpy:1486
translate Spanish trabalho_dia2_c58af806:

    # mc "He was just giving me some reminders. He’s actually pretty nice."
    mc "Solo me estaba recordando algunas cosas. En realidad es bastante amable."

# game/script.rpy:1487
translate Spanish trabalho_dia2_114dfd76:

    # mc "{color=#a0b0c0}(I’d forgotten he can’t speak in front of others. But this is still really weird, especially with him crouching down and whispering like this…)"
    mc "{color=#a0b0c0}(Había olvidado que no puede hablar delante de los demás. Pero esto sigue siendo muy extraño, especialmente con él agachado y susurrando así...)"

# game/script.rpy:1489
translate Spanish trabalho_dia2_46000b16:

    # p "{size=25}Will you… come tonight?"
    p "{size=25}¿Vendrás… esta noche?"

# game/script.rpy:1491
translate Spanish trabalho_dia2_2f961509:

    # mc "To the circus? Sure, I’ll be there to watch."
    mc "¿Al circo? Claro, estaré allí para verlo."

# game/script.rpy:1493
translate Spanish trabalho_dia2_382e1f28:

    # p "{size=25}That makes me happy, [mc_nome]."
    p "{size=25}Eso me hace feliz, [mc_nome]."

# game/script.rpy:1494
translate Spanish trabalho_dia2_a8c1b7a3:

    # p "{size=25}Will you promise to use my ticket tonight, [titulo_pierrot]?"
    p "{size=25}¿Prometes usar mi boleto esta noche, [titulo_pierrot!t]?"

# game/script.rpy:1501
translate Spanish promessa_797d3a32:

    # mc "Sure, I promise."
    mc "Claro, lo prometo."

# game/script.rpy:1503
translate Spanish promessa_f19d77a7:

    # mc "{color=#a0b0c0}(He’s still holding my arm… Why are the claws on that glove so sharp?)"
    mc "{color=#a0b0c0}(Todavía está sosteniendo mi brazo... ¿Por qué las garras de ese guante son tan afiladas?)"

# game/script.rpy:1512
translate Spanish promessa_cb4aac5e:

    # narrator "He noticed you staring at the claws on his glove, let go of your arm, and made a silly face."
    narrator "Se dio cuenta de que mirabas las garras de su guante, te soltó el brazo e hizo una mueca tonta."

# game/script.rpy:1514
translate Spanish promessa_797b912a:

    # mc "What’s with the tickets, anyway?"
    mc "¿Qué pasa con los boletos, por cierto?"

# game/script.rpy:1525
translate Spanish promessa_9c766f20:

    # c1 "Mommy, look! A clown!"
    c1 "¡Mami, mira! ¡Un payaso!"

# game/script.rpy:1527
translate Spanish promessa_e157fc56:

    # mc "Lucky you, huh."
    mc "Qué suerte tienes, eh."

# game/script.rpy:1533
translate Spanish promessa_bae6ab62:

    # c2 "It's true, darling. He's quite big, isn't he? But this circus isn't for children, it'll give you nightmares."
    c2 "Es verdad, cariño. Es bastante grande, ¿no? Pero este circo no es para niños, te dará pesadillas."

# game/script.rpy:1534
translate Spanish promessa_e39be219:

    # c1 "Noo!"
    c1 "¡Nooo!"

# game/script.rpy:1543
translate Spanish promessa_23fd9015:

    # m "Excuse me, I don't have all day! Can't you see me standing at the counter? Bring me my coffee, no sugar. Lazy one."
    m "¡Disculpe, no tengo todo el día! ¿Acaso no me ve parada en el mostrador? Tráigame mi café, sin azúcar. Qué perezos[letra]."

# game/script.rpy:1545
translate Spanish promessa_5a6737b5:

    # mc "Well, I need to get back to work. Just a second, ma'am."
    mc "Bueno, necesito volver al trabajo. Un segundo, señora."

# game/script.rpy:1547
translate Spanish promessa_2779002d:

    # mc "{color=#a0b0c0}(Looks like it's gonna be a long day.)"
    mc "{color=#a0b0c0}(Parece que va a ser un día largo.)"

# game/script.rpy:1555
translate Spanish promessa_ef85d9d1:

    # mc "Uh, here you go... sir? Your milkshake."
    mc "Eh, aquí tiene... ¿señor? Su batido."

# game/script.rpy:1556
translate Spanish promessa_21358482:

    # mc "{color=#a0b0c0}(What a weird combo haha, strawberry, chocolate, and coffee.)"
    mc "{color=#a0b0c0}(Qué combinación más rara jaja, fresa, chocolate y café.)"

# game/script.rpy:1558
translate Spanish promessa_1adca970:

    # narrator "The impatient woman next to you sighs loudly and checks her watch."
    narrator "La impaciente mujer que está a tu lado suspira ruidosamente y consulta su reloj."

# game/script.rpy:1564
translate Spanish promessa_1c191d65:

    # mc "Yours is coming right up, ma'am."
    mc "El suyo está por llegar, señora."

# game/script.rpy:1566
translate Spanish promessa_dcf94f19:

    # narrator "Pierrot carefully places the money in your hand along with a small chocolate bar."
    narrator "Pierrot coloca con cuidado el dinero en tu mano junto con una pequeña barra de chocolate."

# game/script.rpy:1568
translate Spanish promessa_87be23dd:

    # mc "Oh, is this a 'tip' for me? Thanks!"
    mc "Oh, ¿esto es una 'propina' para mí? ¡Gracias!"

# game/script.rpy:1576
translate Spanish promessa_98631e2a:

    # narrator "He quickly nods and waves goodbye. As he turns around, you notice him staring at the grumpy woman before walking away."
    narrator "Él rápidamente asiente y se despide con la mano. Cuando se da vuelta, lo notas mirando a la mujer gruñona antes de alejarse."

# game/script.rpy:1582
translate Spanish promessa_14c79a77:

    # mc "{color=#a0b0c0}(Aw, too bad... I was curious to see if he'd take off the mask to drink that...)"
    mc "{color=#a0b0c0}(Aw, qué lástima... Tenía curiosidad por ver si se quitaría la máscara para beber eso...)"

# game/script.rpy:1583
translate Spanish promessa_be7fbb5e:

    # mc "{color=#a0b0c0}(This guy... I’ve been running into him a lot since yesterday.)"
    mc "{color=#a0b0c0}(Este tipo... Me lo he encontrado varias veces desde ayer.)"

# game/script.rpy:1584
translate Spanish promessa_e9f991ed:

    # mc "{color=#a0b0c0}(I think he’s kinda...)"
    mc "{color=#a0b0c0}(Creo que es un poco...)"

# game/script.rpy:1589
translate Spanish promessa_75463506:

    # mc "{color=#a0b0c0}(Honestly? It's weird. He always seems to be around, though he doesn't feel threatening.)"
    mc "{color=#a0b0c0}(¿Sinceramente? Es extraño. Siempre parece estar cerca, aunque no parece amenazador.)"

# game/script.rpy:1592
translate Spanish promessa_7608026a:

    # mc "{color=#a0b0c0}(Yeah, I guess that’s a good way to put it. It’s kind of cute how he always shows up and brings me little gifts.)"
    mc "{color=#a0b0c0}(Sí, supongo que es una buena manera de decirlo. Es lindo cómo siempre aparece y me trae pequeños obsequios.)"

# game/script.rpy:1594
translate Spanish promessa_57e453a7:

    # mc "{color=#a0b0c0}(He’s as tall as the door, that strange mask of his almost always has a smile on it… )"
    mc "{color=#a0b0c0}(Es tan alto como la puerta, esa extraña máscara suya casi siempre tiene una sonrisa…)"

# game/script.rpy:1595
translate Spanish promessa_a68258ba:

    # mc "{color=#a0b0c0}(And yeah, he does some pretty strange things sometimes.)"
    mc "{color=#a0b0c0}(Y sí, a veces hace cosas bastante extrañas)."

# game/script.rpy:1596
translate Spanish promessa_184724af:

    # mc "{color=#a0b0c0}(I mean… it is a little creepy. Though I’m still not sure if I like that…)"
    mc "{color=#a0b0c0}(Quiero decir... es un poco espeluznante. Aunque todavía no estoy segur[letra] de si eso me gusta...)"

# game/script.rpy:1598
translate Spanish promessa_bb758136:

    # mc "Sorry for the wait."
    mc "Perdón por la espera."

# game/script.rpy:1605
translate Spanish promessa_2d46a273:

    # m "Uuuhg..."
    m "Ugh..."

# game/script.rpy:1606
translate Spanish promessa_b6e7fa84:

    # m "This coffee’s as awful as the service. I’m never coming back to this dump."
    m "Este café es tan horrible como el servicio. Nunca volveré a este basurero."

# game/script.rpy:1608
translate Spanish promessa_9ecc90b4:

    # mc "{color=#a0b0c0}(Is that a promise?){/color} I’m so sorry…"
    mc "{color=#a0b0c0}(¿Es eso una promesa?){/color} Lo siento mucho..."

# game/script.rpy:1610
translate Spanish promessa_ad34630c:

    # mc "{color=#a0b0c0}(Sometimes rude customers just show up… what can you do.)"
    mc "{color=#a0b0c0}(A veces los clientes groseros simplemente aparecen... ¿qué puedes hacer?)"

# game/script.rpy:1611
translate Spanish promessa_be7c9199:

    # mc "{color=#a0b0c0}(At least I got a chocolate to cheer me up.)"
    mc "{color=#a0b0c0}(Al menos tengo un chocolate para animarme.)"

# game/script.rpy:1618
translate Spanish Arlequim_cafe_830f3cf5:

    # a "Oh! So this is where you work, [titulo_arlequim]?"
    a "¡Oh! ¿Así que aquí trabajas, [titulo_arlequim!t]?"

# game/script.rpy:1622
translate Spanish Arlequim_cafe_ef38c0d3:

    # mc "{color=#a0b0c0}(He followed me too… great.)"
    mc "{color=#a0b0c0}(Él también me siguió... genial.)"

# game/script.rpy:1623
translate Spanish Arlequim_cafe_07e7fa57:

    # mc "Good afternoon. Want something to drink?"
    mc "Buenas tardes. ¿Quieres algo de beber?"

# game/script.rpy:1625
translate Spanish Arlequim_cafe_d1c06d0c:

    # a "Of course! I’ll take an iced coffee."
    a "¡Por supuesto! Tomaré un café helado."

# game/script.rpy:1627
translate Spanish Arlequim_cafe_835c20b1:

    # mc "I’ll get it ready."
    mc "Lo prepararé."

# game/script.rpy:1629
translate Spanish Arlequim_cafe_c38f357d:

    # narrator "He leans over the counter, watching you as you make the coffee."
    narrator "Se inclina sobre el mostrador y te observa mientras preparas el café."

# game/script.rpy:1630
translate Spanish Arlequim_cafe_e94717e7:

    # a "Soooo.... Are you finally gonna accept my ticket?"
    a "Así que... ¿Finalmente aceptarás mi boleto?"

# game/script.rpy:1632
translate Spanish Arlequim_cafe_fc51562f:

    # mc "No. I already have one, and I promised I’d use it."
    mc "No. Ya tengo uno y prometí que lo usaría."

# game/script.rpy:1637
translate Spanish Arlequim_cafe_9262902e:

    # a "You sure? It’d be so much more fun if you used mine ♪"
    a "¿Segur[letra]? Sería mucho más divertido si usaras el mío ♪"

# game/script.rpy:1639
translate Spanish Arlequim_cafe_2876efd9:

    # mc "Why?"
    mc "¿Por qué?"

# game/script.rpy:1644
translate Spanish Arlequim_cafe_2149b80a:

    # a "{i}That’s a secret."
    a "{i}Eso es un secreto."

# game/script.rpy:1646
translate Spanish Arlequim_cafe_c4508226:

    # mc "{color=#a0b0c0}(Ugh, these two…)"
    mc "{color=#a0b0c0}(Uf, estos dos…)"

# game/script.rpy:1650
translate Spanish Arlequim_cafe_70bf1ec7:

    # mc "Here’s your iced coffee."
    mc "Aquí tienes tu café helado."

# game/script.rpy:1652
translate Spanish Arlequim_cafe_03d854a9:

    # a "Alright, alright. In that case…"
    a "Está bien, está bien. En ese caso..."

# game/script.rpy:1653
translate Spanish Arlequim_cafe_c2e83648:

    # a "A little something for you. I’d love for you to wear it."
    a "Algo pequeño para ti. Me encantaría que lo usaras."

# game/script.rpy:1654
translate Spanish Arlequim_cafe_3ba76e65:

    # a "Here, let me put it on."
    a "Toma, déjame ponértelo."

# game/script.rpy:1656
translate Spanish Arlequim_cafe_f694a86c:

    # narrator "He steps closer and gently pins the pin to your shirt collar. He’s not as tall as Pierrot, but still has to lean in quite a bit to reach."
    narrator "Se acerca y fija suavemente el alfiler en el cuello de tu camisa. No es tan alto como Pierrot, pero aún así tiene que inclinarse un poco para alcanzarlo."

# game/script.rpy:1660
translate Spanish Arlequim_cafe_70b42f99:

    # mc "Hmn?"
    mc "¿Mmm?"

# game/script.rpy:1662
translate Spanish Arlequim_cafe_431355cf:

    # narrator "You hear the claw of his glove click softly against the metal of the pin as he gives it a tap, chuckling under his breath in a low tone."
    narrator "Escuchas la garra de su guante hacer clic suavemente contra el metal del alfiler mientras le da un golpe, riéndose entre dientes en voz baja."

# game/script.rpy:1664
translate Spanish Arlequim_cafe_7115f269:

    # a "{bt=2}{b}{color=#41d623}I’m going to take you from him."
    a "{bt=2}{b}{color=#41d623}Voy a arrebatarte de su lado."

# game/script.rpy:1666
translate Spanish Arlequim_cafe_c27042a1:

    # mc "...Excuse me?"
    mc "...¿Cómo dices?"

# game/script.rpy:1676
translate Spanish Arlequim_cafe_4744726e:

    # a "You’ll see ♪"
    a "Ya verás ♪"

# game/script.rpy:1681
translate Spanish Arlequim_cafe_ee1c0e31:

    # a "Anyway, here’s the payment."
    a "De todos modos, aquí está el pago."

# game/script.rpy:1687
translate Spanish Arlequim_cafe_b382e231:

    # a "See you tonight, [titulo_arlequim]."
    a "Nos vemos esta noche, [titulo_arlequim!t]."

# game/script.rpy:1688
translate Spanish Arlequim_cafe_0a9f0cdb:

    # a "Make sure you don’t miss my show, alright?"
    a "Asegúrate de no perderte mi espectáculo, ¿de acuerdo?"

# game/script.rpy:1690
translate Spanish Arlequim_cafe_a9a0ae07:

    # mc "H-Hey!"
    mc "¡Oye!"

# game/script.rpy:1694
translate Spanish Arlequim_cafe_2e57ed76:

    # mc "{color=#a0b0c0}(Take me from him? What is this? Are they playing some kind of game with me?)"
    mc "{color=#a0b0c0}(¿Apartarme de él? ¿Qué es esto? ¿Están jugando algún tipo de juego conmigo?)"

# game/script.rpy:1695
translate Spanish Arlequim_cafe_96144d3d:

    # mc "Tch..."
    mc "Tch..."

# game/script.rpy:1696
translate Spanish Arlequim_cafe_e50a3a08:

    # mc "{color=#a0b0c0}(I really can’t tell if they’re teasing me or trying to pull me into something else)"
    mc "{color=#a0b0c0}(Realmente no puedo decir si se están burlando de mí o tratando de atraerme a otra cosa)"

# game/script.rpy:1704
translate Spanish fimdo_turno_11626006:

    # c "Your shift’s just about over. I’ll keep the shop open for another hour."
    c "Tu turno casi ha terminado. Mantendré el local abierto una hora más."

# game/script.rpy:1705
translate Spanish fimdo_turno_bfad37d1:

    # c "Until we hire someone new, I’ll have to cut back the hours a bit."
    c "Hasta que contratemos a alguien nuevo, tendré que reducir un poco las horas."

# game/script.rpy:1707
translate Spanish fimdo_turno_579be968:

    # mc "Got it! What happened to your arm?"
    mc "¡Entendido! ¿Qué pasó con tu brazo?"

# game/script.rpy:1709
translate Spanish fimdo_turno_9d317eed:

    # c "This? Oh, something scratched me out back. Pretty sure it was a huge cat or something."
    c "¿Esto? Ah, algo me arañó en la parte de atrás. Estoy bastante seguro de que era un gato enorme o algo así."

# game/script.rpy:1711
translate Spanish fimdo_turno_c4726889:

    # mc "Hm. Be careful."
    mc "Mmm. Ten cuidado."

# game/script.rpy:1715
translate Spanish fimdo_turno_64677e8e:

    # mc "Here, I’ve got a bandage."
    mc "Toma, tengo una venda."

# game/script.rpy:1716
translate Spanish fimdo_turno_85b28626:

    # c "Thanks! Good thing you carry this kind of stuff around."
    c "¡Gracias! Qué bueno que llevas este tipo de cosas contigo."

# game/script.rpy:1717
translate Spanish fimdo_turno_d2320571:

    # mc "I’m kind of clumsy, to be honest. So I always keep one with me."
    mc "Soy un poco torpe, para ser sincer[letra]. Por eso siempre llevo una conmigo."

# game/script.rpy:1718
translate Spanish fimdo_turno_059672f1:

    # c "That makes sense, haha!"
    c "¡Eso tiene sentido, jaja!"

# game/script.rpy:1720
translate Spanish fimdo_turno_7787934a:

    # mc "Did you clean it already?"
    mc "¿Ya lo limpiaste?"

# game/script.rpy:1721
translate Spanish fimdo_turno_843ef412:

    # c "Yeah, it’s nothing serious."
    c "Sí, no es nada grave."

# game/script.rpy:1722
translate Spanish fimdo_turno_08c236bf:

    # mc "Still, those are some big claws for a stray cat huh?"
    mc "Aun así, esas son unas garras grandes para un gato callejero, ¿eh?"

# game/script.rpy:1723
translate Spanish fimdo_turno_a1dc6094:

    # c "If you’d seen the size of that thing, you wouldn’t think it’s weird."
    c "Si hubieras visto el tamaño de esa cosa, no pensarías que es extraño."

# game/script.rpy:1725
translate Spanish fimdo_turno_fc6069f4:

    # mc "Anyway, I gotta go, don’t wanna be late. I’m heading to the circus tonight."
    mc "De todos modos, tengo que irme, no quiero llegar tarde. Esta noche voy al circo."

# game/script.rpy:1727
translate Spanish fimdo_turno_7e704dc0:

    # c "Sounds fun. Tell me how it was later, maybe I’ll check it out sometime."
    c "Suena divertido. Cuéntame cómo te fue después, tal vez vaya a verlo algún día."

# game/script.rpy:1729
translate Spanish fimdo_turno_6af8332a:

    # mc "Sure! See you later!"
    mc "¡Claro! ¡Hasta luego!"

# game/script.rpy:1737
translate Spanish circo_b3ae8984:

    # mc "Uhm..."
    mc "Mmm..."

# game/script.rpy:1738
translate Spanish circo_48d1190b:

    # mc "{color=#a0b0c0}(I’m not really into crowded places... but things are pretty lively here. There’s a food fair right at the entrance of the big top.)"
    mc "{color=#a0b0c0}(No me gustan mucho los lugares concurridos... pero hay bastante animación aquí. Hay una feria de comida justo en la entrada de la gran carpa.)"

# game/script.rpy:1742
translate Spanish circo_a6262e97:

    # b "Hello there, visitor! May I punch your ticket?"
    b "¡Hola, visitante! ¿Puedo perforar tu boleto?"

# game/script.rpy:1744
translate Spanish circo_e202d3fe:

    # mc "Sure, here it is!"
    mc "¡Claro, aquí está!"

# game/script.rpy:1751
translate Spanish circo_d129bd06:

    # b "Oh, a special ticket! Be sure to keep it safe, alright? You’ll need to show it at the attractions."
    b "¡Ah, un boleto especial! Asegúrate de guardarlo bien, ¿de acuerdo? Tendrás que mostrarlo en las atracciones."

# game/script.rpy:1753
translate Spanish circo_932a9d45:

    # mc "Okay, but what’s a special ticket?"
    mc "Vale, pero ¿qué es un boleto especial?"

# game/script.rpy:1755
translate Spanish circo_ef44f659:

    # b "Hm? You’ve got front row seats."
    b "¿Mmm? Tienes asientos en primera fila."

# game/script.rpy:1757
translate Spanish circo_1915c493:

    # mc "Nice! Thanks."
    mc "¡Genial! Gracias."

# game/script.rpy:1759
translate Spanish circo_bd2692b1:

    # b "Enjoy the show!"
    b "¡Disfruta del espectáculo!"

# game/script.rpy:1765
translate Spanish circo_1385c941:

    # mc "{color=#a0b0c0}(So that’s how it works? The box office tickets are all yellow. I can see a few black ones too, but no pink, green, or even red ones like mine.)"
    mc "{color=#a0b0c0}(¿Así es como funciona? Los boletos de taquilla son todos amarillos. También puedo ver algunos negros, pero no rosados, verdes o incluso rojos como el mío)."

# game/script.rpy:1768
translate Spanish circo_4f4068cf:

    # mc "{color=#a0b0c0}(Alright, let’s see what we’ve got here.)"
    mc "{color=#a0b0c0}(Muy bien, veamos qué tenemos aquí.)"

# game/script.rpy:1769
translate Spanish circo_a644c3ae:

    # mc "{color=#a0b0c0}(There’s a pink and black tent over that way, a green one, a purple one, and Pierrot’s red tent.)"
    mc "{color=#a0b0c0}(Hay una carpa rosa y negra en ese camino, una verde, una morada y la carpa roja de Pierrot.)"

# game/script.rpy:1770
translate Spanish circo_a625d143:

    # mc "{color=#a0b0c0}(Looks like his show isn’t on yet. I can visit another one in the meantime.)"
    mc "{color=#a0b0c0}(Parece que su espectáculo aún no ha comenzado. Puedo visitar otro mientras tanto.)"

# game/script.rpy:1776
translate Spanish tendas_d4abe500:

    # b "Oh! So sorry, you don’t have access to this area, my dear."
    b "¡Ah! Lo siento mucho, no tienes acceso a esta área, querid[letra]."

# game/script.rpy:1778
translate Spanish tendas_33ed3b1c:

    # mc "Ok, sorry."
    mc "Vale, lo siento."

# game/script.rpy:1783
translate Spanish tendas_783604d9:

    # mc "The Jester. Looks like his show already happened. Maybe there’ll be another one later."
    mc "El Bufón. Parece que su espectáculo ya terminó. Quizás haya otro más adelante."

# game/script.rpy:1787
translate Spanish tendas_37615faf:

    # mc "{color=#a0b0c0}(Oh, it’s already started!)"
    mc "{color=#a0b0c0}(¡Oh, ya comenzó!)"

# game/script.rpy:1800
translate Spanish tenda_verde_bff73084:

    # a "Good evening, my dear monsters. Enjoy my show!"
    a "Buenas noches, mis queridos monstruos. ¡Disfruten de mi espectáculo!"

# game/script.rpy:1806
translate Spanish tenda_verde_22400843:

    # a "{i}Far from everything, where God’s eyes cannot reach, the monsters lived."
    a "{i}Lejos de todo, donde los ojos de Dios no pueden llegar, vivían los monstruos."

# game/script.rpy:1807
translate Spanish tenda_verde_3b4c0437:

    # a "{cps=10}{i}Forgotten. Hungry. Silent."
    a "{cps=10}{i}Olvidados. Hambrientos. Silenciosos."

# game/script.rpy:1814
translate Spanish tenda_verde_3c300b05:

    # a "Until the man appeared. He raised a tent upon the dead earth and made a deal:"
    a "Hasta que apareció el hombre. Levantó una carpa sobre la tierra muerta e hizo un trato:"

# game/script.rpy:1828
translate Spanish tenda_verde_1a01f3b4:

    # a "{color=#ff0000}Work for me, you hideous little creatures, and I will feed you."
    a "{color=#ff0000}Trabajen para mí, pequeñas criaturas horribles, y yo los alimentaré."

# game/script.rpy:1837
translate Spanish tenda_verde_5a2787a7:

    # a "{color=#ffffff}How wonderful!"
    a "{color=#ffffff}¡Qué maravilloso!"

# game/script.rpy:1838
translate Spanish tenda_verde_6f8217ef:

    # a "Thought the monsters. And so{cps=20} they obeyed."
    a "Pensaron los monstruos. Y así{cps=20} obedecieron."

# game/script.rpy:1844
translate Spanish tenda_verde_43087a59:

    # a "But the man brought more men. And more..."
    a "Pero el hombre trajo más hombres. Y más..."

# game/script.rpy:1845
translate Spanish tenda_verde_854932be:

    # a "They laughed at the monsters."
    a "Se rieron de los monstruos."

# game/script.rpy:1846
translate Spanish tenda_verde_d3a78b2d:

    # a "They applauded their pain."
    a "Aplaudieron su dolor."

# game/script.rpy:1854
translate Spanish tenda_verde_abd2a764:

    # a "{color=#ff0000}What if I charged others to watch?"
    a "{color=#ff0000}¿Y si les cobrara a otros por mirar?"

# game/script.rpy:1855
translate Spanish tenda_verde_f55b4033:

    # a "The crowd loved it."
    a "A la multitud le encantó."

# game/script.rpy:1857
translate Spanish tenda_verde_e9452beb:

    # a "But the man wanted more, always more. So he began to feed them less."
    a "Pero el hombre quería más, siempre más. Entonces empezó a alimentarlos menos."

# game/script.rpy:1865
translate Spanish tenda_verde_ffb17d17:

    # a "{color=#ff0000}This way they’ll be weak. Harmless."
    a "{color=#ff0000}De esta manera serán débiles. Inofensivos."

# game/script.rpy:1874
translate Spanish tenda_verde_68f7ffca:

    # a "He laughed, while the monsters rotted in their cages, swallowed by the dark."
    a "Se rió, mientras los monstruos se pudrían en sus jaulas, devorados por la oscuridad."

# game/script.rpy:1875
translate Spanish tenda_verde_6b03015f:

    # a "And then they thought:"
    a "Y entonces pensaron:"

# game/script.rpy:1883
translate Spanish tenda_verde_9ccf3af3:

    # a "{color=#961ee6}What if we became human?"
    a "{color=#961ee6}¿Qué pasaría si nos volviéramos humanos?"

# game/script.rpy:1892
translate Spanish tenda_verde_23e402c8:

    # a "We could eat as much as we want."
    a "Podríamos comer todo lo que queramos."

# game/script.rpy:1900
translate Spanish tenda_verde_7f81031d:

    # a "{color=#ffaf54}No one would hurt us ever again."
    a "{color=#ffaf54}Nadie nos volvería a hacer daño nunca más."

# game/script.rpy:1910
translate Spanish tenda_verde_47a02929:

    # a "And on a moonless night, when the sky seemed dead,"
    a "Y en una noche sin luna, cuando el cielo parecía muerto,"

# game/script.rpy:1924
translate Spanish glitch1_columbina_5fd232d4:

    # a "The monsters realized there was an angel among them!"
    a "¡Los monstruos se dieron cuenta de que había un ángel entre ellos!"

# game/script.rpy:1941
translate Spanish glitch1_columbina_7d2248db:

    # a "{cps=100}The monsters realized there was an angel among them!"
    a "{cps=100}¡Los monstruos se dieron cuenta de que había un ángel entre ellos!"

# game/script.rpy:1951
translate Spanish glitch2_columbina_33da63f3:

    # a "{color=#e61ed5}I can feed you, grow strong, become human and build a home for us."
    a "{color=#e61ed5}Puedo alimentarlos para que se hagan fuertes, se vuelvan humanos y construyan un hogar para nosotros."

# game/script.rpy:1964
translate Spanish glitch2_columbina_ba272100:

    # a "The angel said."
    a "Dijo el ángel."

# game/script.rpy:1991
translate Spanish glitch3_columbina_2090a9e9:

    # a "And then, as if she had never existed, she vanished with the wind."
    a "Y luego, como si nunca hubiera existido, desapareció con el viento."

# game/script.rpy:1992
translate Spanish glitch3_columbina_69a6ab2b:

    # a "Our little miracle…"
    a "Nuestro pequeño milagro..."

# game/script.rpy:2002
translate Spanish final_historia_7cfb479e:

    # a "The next morning, the man returned to laugh."
    a "A la mañana siguiente, el hombre volvió a reír."

# game/script.rpy:2015
translate Spanish final_historia_551fe50e:

    # a "But the monsters’ eyes had changed."
    a "Pero los ojos de los monstruos habían cambiado."

# game/script.rpy:2016
translate Spanish final_historia_596fec2a:

    # a "They were free."
    a "Eran libres."

# game/script.rpy:2017
translate Spanish final_historia_662269e1:

    # a "They were hungry."
    a "Tenían hambre."

# game/script.rpy:2020
translate Spanish final_historia_d6b0370a:

    # a "And that’s how the monsters became human!"
    a "¡Y así fue como los monstruos se volvieron humanos!"

# game/script.rpy:2027
translate Spanish final_historia_676366ba:

    # a "Oh, and what happens next, you ask?"
    a "Ah, ¿y qué pasa después, preguntas?"

# game/script.rpy:2028
translate Spanish final_historia_1e7bba96:

    # a "After that, the new humans took their home and began to travel together."
    a "Después de eso, los nuevos humanos tomaron su hogar y comenzaron a viajar juntos."

# game/script.rpy:2029
translate Spanish final_historia_c008d3e6:

    # a "Searching for a place to build it again and live happily, just as the angel wished."
    a "Buscando un lugar para construirlo nuevamente y vivir felices, tal como el ángel deseaba."

# game/script.rpy:2031
translate Spanish final_historia_69862302:

    # a "Thank you! Thank you little monsters!"
    a "¡Gracias! ¡Gracias pequeños monstruos!"

# game/script.rpy:2038
translate Spanish fimda_historia_9d86df7d:

    # mc "{color=#a0b0c0}(People actually seemed to enjoy that.)"
    mc "{color=#a0b0c0}(La gente realmente parecía disfrutar de eso.)"

# game/script.rpy:2039
translate Spanish fimda_historia_7a394ed5:

    # mc "{color=#a0b0c0}(That story felt pretty macabre, though...)"
    mc "{color=#a0b0c0}(Aunque esa historia parecía bastante macabra...)"

# game/script.rpy:2042
translate Spanish fimda_historia_143bb015:

    # a "I'm glad you came to see my show... I was hoping you’d be watching."
    a "Me alegra que hayas venido a ver mi espectáculo... Esperaba que estuvieras entre el público."

# game/script.rpy:2044
translate Spanish fimda_historia_0afdb4ff:

    # mc "Ah... hello! Your story was... peculiar."
    mc "¡Ah... hola! Tu historia fue... peculiar."

# game/script.rpy:2048
translate Spanish fimda_historia_f905e625:

    # a "Yeah, it’s a pretty old story from the circus. It's a tradition to tell it on certain nights."
    a "Sí, es una historia bastante antigua del circo. Es una tradición contarla en determinadas noches."

# game/script.rpy:2053
translate Spanish fimda_historia_a7949293:

    # a "Oh!{w} I see you're wearing my gift! That makes me so excited!"
    a "¡Oh!{w} ¡Veo que llevas puesto mi regalo! ¡Eso me emociona mucho!"

# game/script.rpy:2062
translate Spanish fimda_historia_8c38e20b:

    # mc "{color=#a0b0c0}(Oh, right... I forgot about that.)"
    mc "{color=#a0b0c0}(Oh, claro... Me olvidé de eso.)"

# game/script.rpy:2070
translate Spanish fimda_historia_102aa7ae:

    # mc "W-What?"
    mc "¿Q-qué?"

# game/script.rpy:2072
translate Spanish fimda_historia_7ac18062:

    # a "{i}It looks good on you. {cps=10}Almost...{w=0.2} too intimate."
    a "{i}Te queda bien. {cps=10}Casi...{w=0.2} demasiado íntimo."

# game/script.rpy:2081
translate Spanish fimda_historia_e60a2418:

    # a "Did you like it?{w=0.2} Or are you trying to tease me?"
    a "¿Te gustó?{w=0.2} ¿O estás intentando provocarme?"

# game/script.rpy:2083
translate Spanish fimda_historia_e68a6fbe:

    # narrator "You frown in protest, but his words caught you off guard. You don’t even know how to respond." with vpunch
    narrator "Frunces el ceño en señal de protesta, pero sus palabras te tomaron por sorpresa. Ni siquiera sabes cómo responder." with vpunch

# game/script.rpy:2092
translate Spanish fimda_historia_c9f99f8b:

    # narrator "He smiles, clearly amused by your confusion."
    narrator "Él sonríe, claramente divertido por tu confusión."

# game/script.rpy:2094
translate Spanish fimda_historia_5049b4c5:

    # a "Mmh… I love that!"
    a "Mmm... ¡me encanta eso!"

# game/script.rpy:2095
translate Spanish fimda_historia_4164ff28:

    # a "I love seeing my green mark so close to your skin."
    a "Me encanta ver mi marca verde tan cerca de tu piel."

# game/script.rpy:2096
translate Spanish fimda_historia_1d91a7fd:

    # a "Like a quiet, forbidden kiss."
    a "Como un beso silencioso y prohibido."

# game/script.rpy:2098
translate Spanish fimda_historia_d219c385:

    # mc "{color=#a0b0c0}(He's way too close... I should-)"
    mc "{color=#a0b0c0}(Está demasiado cerca... debería-)"

# game/script.rpy:2101
translate Spanish fimda_historia_30b76e9b:

    # narrator "You take a step back, bumping into the circus tent’s cold wall."
    narrator "Das un paso atrás y chocas contra la fría pared de la carpa del circo."

# game/script.rpy:2103
translate Spanish fimda_historia_a8420a5e:

    # mc "{color=#a0b0c0}(What is wrong with this guy??)"
    mc "{color=#a0b0c0}(¿Qué le pasa a este tipo??)"

# game/script.rpy:2112
translate Spanish fimda_historia_b5c83c01:

    # narrator "He leans in, bracing his arms around you."
    narrator "Se inclina y te acorrala, apoyando los brazos contra la pared a ambos lados de ti."

# game/script.rpy:2114
translate Spanish fimda_historia_1f6d6f3a:

    # a "Running away?"
    a "¿Huyendo?"

# game/script.rpy:2115
translate Spanish fimda_historia_fef34a8c:

    # a "Scared? Or..."
    a "¿Asustad[letra]? O..."

# game/script.rpy:2116
translate Spanish fimda_historia_50399ef8:

    # a "{cps=10}...Secretly enjoying it?"
    a "{cps=10}... ¿Disfrutándolo en secreto?"

# game/script.rpy:2118
translate Spanish fimda_historia_55731a04:

    # mc "{color=#a0b0c0}(Enjoying it? No way I... Do I?)"
    mc "{color=#a0b0c0}(¿Disfrutándolo? De ninguna manera yo... ¿Yo?)"

# game/script.rpy:2122
translate Spanish fimda_historia_889bbc79:

    # narrator "He smiles wider at your hesitation."
    narrator "Sonríe aún más al notar tu vacilación."

# game/script.rpy:2130
translate Spanish fimda_historia_a3e56b48:

    # a "No need to say a word. I can read you."
    a "No es necesario decir una palabra. Puedo leerte."

# game/script.rpy:2131
translate Spanish fimda_historia_1a11f3cf:

    # a "Your silent screams."
    a "Tus gritos silenciosos."

# game/script.rpy:2132
translate Spanish fimda_historia_056d6e39:

    # a "Red doesn’t suit you, darling."
    a "El rojo no te sienta bien, cariño."

# game/script.rpy:2133
translate Spanish fimda_historia_9d9dfa26:

    # a "That intoxicating green... fits better ♪"
    a "Ese verde embriagador... te queda mejor ♪"

# game/script.rpy:2135
translate Spanish fimda_historia_8486e58b:

    # mc "{color=#a0b0c0}(His scent... it’s good. And that voice... it's too intense.)"
    mc "{color=#a0b0c0}(Su olor... es agradable. Y esa voz... es demasiado intensa.)"

# game/script.rpy:2136
translate Spanish fimda_historia_038a3589:

    # narrator "He smiles again, like he knows his poisonous words have burrowed into your mind, then slowly steps back."
    narrator "Sonríe de nuevo, como si supiera que sus palabras venenosas se han clavado en tu mente, y luego da lentamente un paso atrás."

# game/script.rpy:2144
translate Spanish fimda_historia_47343692:

    # a "I want to give you another gift."
    a "Quiero hacerte otro regalo."

# game/script.rpy:2146
translate Spanish fimda_historia_0ee2c6a0:

    # narrator "He catches the subtle shift in your eyes, then backs away with a slow, almost wicked smile."
    narrator "Capta el sutil cambio en tu mirada y luego se aleja con una sonrisa lenta, casi maliciosa."

# game/script.rpy:2150
translate Spanish fimda_historia_e572fd15:

    # a "Oh, don’t take me so seriously, darling..."
    a "Oh, no me tomes tan en serio, cariño..."

# game/script.rpy:2151
translate Spanish fimda_historia_cfbc22d9:

    # a "I was only... performing~"
    a "Yo sólo estaba... actuando~"

# game/script.rpy:2152
translate Spanish fimda_historia_3543a561:

    # mc "{color=#a0b0c0}(Performing...? Yeah, sure.)"
    mc "{color=#a0b0c0}(¿Actuando...? Sí, claro.)"

# game/script.rpy:2153
translate Spanish fimda_historia_52bb331a:

    # a "How about… a tiny apology?"
    a "¿Qué tal… una pequeña disculpa?"

# game/script.rpy:2158
translate Spanish fimda_historia_18c951cd:

    # a "What do you say?"
    a "¿Qué dices?"

# game/script.rpy:2160
translate Spanish fimda_historia_ef78d5b3:

    # mc " A candy apple?"
    mc " ¿Una manzana de caramelo?"

# game/script.rpy:2162
translate Spanish fimda_historia_6671f1c4:

    # a "Yeah, we call it a 'Love Apple' or 'Maçã do amor', but don’t get the wrong idea, it’s still just an apple."
    a "Sí, la llamamos 'Manzana del amor' o 'Maçã do amor', pero no te hagas una idea equivocada, sigue siendo solo una manzana."

# game/script.rpy:2164
translate Spanish fimda_historia_c14c584c:

    # mc "Well..."
    mc "Bueno..."

# game/script.rpy:2199
translate Spanish fimda_historia_48753c66:

    # mc "What--{nw=0.5}"
    mc "¿Qué--{nw=0.5}"

# game/script.rpy:2200
translate Spanish fimda_historia_2d972db4:

    # mc "What was that??"
    mc "¿Qué fue eso?"

# game/script.rpy:2201
translate Spanish fimda_historia_9987cd8a:

    # mc "Where... did that come from?"
    mc "¿De dónde... vino eso?"

# game/script.rpy:2208
translate Spanish fimda_historia_ae98a7ab:

    # a "{size=25}Hah... always so dramatic."
    a "{size=25}Ja... siempre tan dramático."

# game/script.rpy:2209
translate Spanish fimda_historia_9ff10400:

    # a "I guess someone around here really {i}hates{/i} apples."
    a "Supongo que alguien por aquí realmente {i}odia{/i} las manzanas."

# game/script.rpy:2211
translate Spanish fimda_historia_b92a4679:

    # mc "Does this kind of thing happen a lot around here?"
    mc "¿Este tipo de cosas pasan mucho por aquí?"

# game/script.rpy:2213
translate Spanish fimda_historia_378bcfe1:

    # narrator "You try to look at the knife sticking out of the candy apple, but the Harlequin in front of you quickly snatches it away and tosses the apple aside."
    narrator "Intentas mirar el cuchillo que sobresale de la manzana de caramelo, pero el Arlequín frente a ti rápidamente lo arrebata y tira la manzana a un lado."

# game/script.rpy:2220
translate Spanish fimda_historia_adc702b6:

    # a "No need to worry, [titulo_arlequim]. I'm sure it was just a little joke."
    a "No hay de qué preocuparse, [titulo_arlequim!t]. Seguro fue solo una pequeña broma."

# game/script.rpy:2221
translate Spanish fimda_historia_447bde5c:

    # a "Looks like I’ll have to delay giving it to you."
    a "Parece que tendré que esperar para dártela."

# game/script.rpy:2223
translate Spanish fimda_historia_f6c31340:

    # mc "{color=#a0b0c0}(A pretty dangerous joke... Are these guys actually insane?)"
    mc "{color=#a0b0c0}(Una broma bastante peligrosa... ¿Están realmente locos estos tipos?)"

# game/script.rpy:2225
translate Spanish fimda_historia_cb1d2622:

    # mc "Alright...{w=0.3} I should get going, the next show’s about to start."
    mc "Muy bien... {w=0.3} Debería irme, el próximo espectáculo está a punto de comenzar."

# game/script.rpy:2226
translate Spanish fimda_historia_aa8b1488:

    # a "Have fun, [titulo_arlequim]. Who knows, maybe I’ll see you around."
    a "Que te diviertas, [titulo_arlequim!t]. Quién sabe, quizás nos veamos por ahí."

# game/script.rpy:2231
translate Spanish barracas_b2edea88:

    # mc "{color=#a0b0c0}(Well, weirdness aside... I’m actually getting kinda hungry. Maybe I should grab something to eat before heading to Pierrot’s tent?)"
    mc "{color=#a0b0c0}(Bueno, aparte de las rarezas... en realidad me está entrando un poco de hambre. ¿Quizás debería comer algo antes de dirigirme a la carpa de Pierrot?)"

# game/script.rpy:2235
translate Spanish barracas_fc06a938:

    # mc "Well, why not?"
    mc "Bueno, ¿por qué no?"

# game/script.rpy:2239
translate Spanish barracas_6a4f1bb3:

    # mc "Mmm! This smells so good."
    mc "¡Mmm! Esto huele tan bien."

# game/script.rpy:2240
translate Spanish barracas_74d1750a:

    # narrator "You scarf down your snack and quickly feel full."
    narrator "Te devoras el refrigerio y rápidamente te sientes llen[letra]."

# game/script.rpy:2242
translate Spanish barracas_6a4f1bb3_1:

    # mc "Mmm! This smells so good."
    mc "¡Mmm! Esto huele tan bien."

# game/script.rpy:2243
translate Spanish barracas_74d1750a_1:

    # narrator "You scarf down your snack and quickly feel full."
    narrator "Te devoras el refrigerio y rápidamente te sientes llen[letra]."

# game/script.rpy:2247
translate Spanish barracas_8a2828f4:

    # narrator "Before the vendor can hand you the food, someone snatches it from him, and a familiar face leans in, offering the candy apple to you."
    narrator "Antes de que el vendedor pueda entregártela, alguien se la arrebata y un rostro familiar se inclina y te ofrece la manzana acaramelada."

# game/script.rpy:2253
translate Spanish barracas_1e4d69cd:

    # mc "Funny guy. How’d you even find me in a crowd like this?"
    mc "Chico gracioso. ¿Cómo pudiste encontrarme entre una multitud como esta?"

# game/script.rpy:2258
translate Spanish barracas_4f47cce0:

    # p "{cps=10}{size=35}..."
    p "{cps=10}{size=35}..."

# game/script.rpy:2259
translate Spanish barracas_25d819ca:

    # mc "Okay, okay, not really the best place for small talk, huh? I’m heading in before the show starts."
    mc "Vale, vale, no es realmente el mejor lugar para una pequeña charla, ¿eh? Voy a entrar antes de que empiece el espectáculo."

# game/script.rpy:2261
translate Spanish barracas_07c07bfa:

    # narrator "He smiles brightly and waves before walking away."
    narrator "Él sonríe alegremente y saluda antes de alejarse."

# game/script.rpy:2265
translate Spanish barracas_6a4f1bb3_2:

    # mc "Mmm! This smells so good."
    mc "¡Mmm! Esto huele tan bien."

# game/script.rpy:2266
translate Spanish barracas_74d1750a_2:

    # narrator "You scarf down your snack and quickly feel full."
    narrator "Te devoras el refrigerio y rápidamente te sientes llen[letra]."

# game/script.rpy:2269
translate Spanish barracas_e47834b0:

    # mc "Nah, I guess I'm not that hungry, I can eat something better at home and cheaper too."
    mc "No, supongo que no tengo tanta hambre, puedo comer algo mejor en casa y además más barato."

# game/script.rpy:2273
translate Spanish barraca_pierrot_3ff5ae03:

    # mc "{color=#a0b0c0}(I better hurry before the show starts.)"
    mc "{color=#a0b0c0}(Será mejor que me apure antes de que comience el espectáculo.)"

# game/script.rpy:2282
translate Spanish barraca_pierrot_17842aa9:

    # mc "{color=#a0b0c0}(Oh! A theatrical performance? I was wondering what a show without speaking would be like.)"
    mc "{color=#a0b0c0}(¡Oh! ¿Una representación teatral? Me preguntaba cómo sería un espectáculo sin diálogos.)"

# game/script.rpy:2288
translate Spanish barraca_pierrot_e8ee6ea4:

    # narrator "He shifts into a more menacing posture, his smile turning sinister. He moves in a strange, hypnotic dance as the lights change around him."
    narrator "Cambia a una postura más amenazadora y su sonrisa se vuelve siniestra. Se mueve en una danza extraña e hipnótica mientras las luces cambian a su alrededor."

# game/script.rpy:2289
translate Spanish barraca_pierrot_5d5660c2:

    # narrator "It feels like he’s dancing with his own shadow."
    narrator "Se siente como si estuviera bailando con su propia sombra."

# game/script.rpy:2290
translate Spanish barraca_pierrot_b13f7f10:

    # narrator "Except when he moves one way, the shadow moves the other... in a really creepy way."
    narrator "Solo que cuando él se mueve en una dirección, la sombra se mueve en la otra... de una forma realmente espeluznante."

# game/script.rpy:2295
translate Spanish barraca_pierrot_b358d157:

    # mc "{color=#a0b0c0}(Whoa, he really changes on stage.)"
    mc "{color=#a0b0c0}(Vaya, realmente cambia en el escenario)."

# game/script.rpy:2305
translate Spanish barraca_pierrot_5a5f626c:

    # mc "A stage assistant! Even from here, you can tell how much taller he is than her."
    mc "¡Una asistente de escena! Incluso desde aquí, puedes ver cuánto más alto es él que ella."

# game/script.rpy:2314
translate Spanish barraca_pierrot_77fb1353:

    # mc "{color=#a0b0c0}(Knives?)"
    mc "{color=#a0b0c0}(¿Cuchillos?)"

# game/script.rpy:2316
translate Spanish barraca_pierrot_ad2a5dff:

    # narrator "The woman moves slowly, stretching her arms a few times."
    narrator "La mujer se mueve lentamente, estirando los brazos un par de veces."

# game/script.rpy:2324
translate Spanish barraca_pierrot_c3cad917:

    # mc "W-woah..."
    mc "V-vaya..."

# game/script.rpy:2329
translate Spanish barraca_pierrot_aa750e9e:

    # narrator "You hear some people cheering for him to hit her."
    narrator "Escuchas a algunas personas animándolo a que la golpee."

# game/script.rpy:2330
translate Spanish barraca_pierrot_897949fb:

    # mc "{color=#a0b0c0}(It’s just acting... and some crazy people... relax.)"
    mc "{color=#a0b0c0}(Es sólo actuar... y algunos locos... relájate.)"

# game/script.rpy:2334
translate Spanish barraca_pierrot_c9690d62:

    # mc "{color=#a0b0c0}(Those knives are landing way too close to her... That's--{nw=0.6})"
    mc "{color=#a0b0c0}(Esos cuchillos se están clavando demasiado cerca de ella... Eso es--{nw=0.6})"

# game/script.rpy:2345
translate Spanish barraca_pierrot_c6775026:

    # mc "{color=#a0b0c0}(... Terrifying!!)"
    mc "{color=#a0b0c0}(... ¡¡Aterrador!!)"

# game/script.rpy:2346
translate Spanish barraca_pierrot_0f0ea313:

    # mc "{sc=3}{color=#a0b0c0}(N-no... that wasn’t real... right? Ha... ha... just acting...){/sc}"
    mc "{sc=3}{color=#a0b0c0}(N-no... eso no fue real... ¿verdad? Ja... ja... solo están actuando...){/sc}"

# game/script.rpy:2347
translate Spanish barraca_pierrot_6ed32a82:

    # mc "{sc=1}{color=#a0b0c0}(It was just a performance. Of course it was... haha...){/sc}"
    mc "{sc=1}{color=#a0b0c0}(Fue solo una actuación. Por supuesto que lo fue... jaja...){/sc}"

# game/script.rpy:2348
translate Spanish barraca_pierrot_12048260:

    # mc "{sc=3}{color=#a0b0c0}(But... the blood... the way she fell...){/sc}"
    mc "{sc=3}{color=#a0b0c0}(Pero... la sangre... la forma en que cayó...){/sc}"

# game/script.rpy:2349
translate Spanish barraca_pierrot_811f4242:

    # mc "{sc=5}{color=#a0b0c0}(Damn it. I need to get out of here.){/sc}"
    mc "{sc=5}{color=#a0b0c0}(Maldita sea. Necesito salir de aquí.){/sc}"

# game/script.rpy:2360
translate Spanish circo_final_4b5bb96e:

    # mc "{sc=1}{color=#a0b0c0}(Air... I need air...)"
    mc "{sc=1}{color=#a0b0c0}(Aire... necesito aire...)"

# game/script.rpy:2361
translate Spanish circo_final_3875c301:

    # mc "{sc=1}{color=#a0b0c0}(Haha... this is insane. Just a show... it's just a show... right?)"
    mc "{sc=1}{color=#a0b0c0}(Jaja... esto es una locura. Sólo un espectáculo... es sólo un espectáculo... ¿verdad?)"

# game/script.rpy:2363
translate Spanish circo_final_f529cdbb:

    # mc "{color=#a0b0c0}(I guess the creepy atmosphere of this place got to me a little.)"
    mc "{color=#a0b0c0}(Supongo que la atmósfera espeluznante de este lugar me afectó un poco.)"

# game/script.rpy:2364
translate Spanish circo_final_d2a3100f:

    # mc "{color=#a0b0c0}(I mean, the stage lights were low for a reason, right? It was just a scare, that’s all. I wasn’t expecting it.)"
    mc "{color=#a0b0c0}(Quiero decir, las luces del escenario estaban bajas por una razón, ¿verdad? Fue solo un susto, eso es todo. No me lo esperaba.)"

# game/script.rpy:2367
translate Spanish circo_final_512d1c37:

    # mc "{color=#ff69b4}(But... I feel like the atmosphere here is messing with me. My body feels warm... in a good way.)"
    mc "{color=#ff69b4}(Pero... siento que la atmósfera de aquí me está afectando. Siento el cuerpo caliente... en el buen sentido.)"

# game/script.rpy:2369
translate Spanish circo_final_a5133a43:

    # narrator "You feel a heavy hand land on your shoulder."
    narrator "Sientes una mano pesada posarse en tu hombro."

# game/script.rpy:2373
translate Spanish circo_final_85fac459:

    # mc "!!!" with hpunch
    mc "!!!" with hpunch

# game/script.rpy:2376
translate Spanish circo_final_26e7196a:

    # mc "A-ah! Oh, it’s you, jeez…"
    mc "¡A-ah! Oh, eres tú, cielos..."

# game/script.rpy:2384
translate Spanish circo_final_d8e45c75:

    # mc "You’re awfully quiet for someone covered in bells..."
    mc "Eres muy silencioso para alguien cubierto de cascabeles..."

# game/script.rpy:2393
translate Spanish circo_final_b4b37f6f:

    # mc "W-what is it?"
    mc "¿Q-qué pasa?"

# game/script.rpy:2398
translate Spanish circo_final_07e495ca:

    # narrator "He slowly raises his hand, hesitant, and runs the claw of his glove along the pin on your collar."
    narrator "Levanta lentamente la mano, vacilante, y pasa la garra de su guante por el alfiler del cuello de tu camisa."

# game/script.rpy:2405
translate Spanish circo_final_13979469:

    # mc "Oh, right... Your, uh… friend? He gave it to me."
    mc "Ah, claro... ¿Tu... eh... amigo? Él me lo dio."

# game/script.rpy:2407
translate Spanish circo_final_38a1c614:

    # narrator "He grips your collar, leaning in closer."
    narrator "Él agarra el cuello de tu camisa y se acerca más."

# game/script.rpy:2428
translate Spanish circo_final_52d399cd:

    # mc "Pierrot?"
    mc "¿Pierrot?"

# game/script.rpy:2430
translate Spanish circo_final_3805a0b3:

    # p "{cps=10}{size=40}..."
    p "{cps=10}{size=40}..."

# game/script.rpy:2442
translate Spanish circo_final_70b42f99:

    # mc "Hmn?"
    mc "¿Mmm?"

# game/script.rpy:2444
translate Spanish circo_final_c37ef754:

    # mc "Uh… thanks?"
    mc "Eh... ¿gracias?"

# game/script.rpy:2445
translate Spanish circo_final_3f7405fe:

    # mc "{color=#a0b0c0}(They’re definitely not friends.)"
    mc "{color=#a0b0c0}(Definitivamente no son amigos.)"

# game/script.rpy:2455
translate Spanish circo_final_0b752f22:

    # narrator "He lowers himself, slowly getting closer to you, and leans in to whisper."
    narrator "Se agacha, se acerca lentamente a ti y se inclina para susurrarte al oído."

# game/script.rpy:2458
translate Spanish circo_final_5078d5bc:

    # mc "{color=#ff69b4}(My heart's beating faster...)"
    mc "{color=#ff69b4}(Mi corazón late más rápido...)"

# game/script.rpy:2459
translate Spanish circo_final_1b4fbc2f:

    # narrator "{sc=1}{color=#ff69b4}You feel your body slipping into euphoria. You're warm, your hands are shaking,\n and a strange joy and rush take over while your heart races wildly in your chest."
    narrator "{sc=1}{color=#ff69b4}Sientes que tu cuerpo cae en la euforia. Tienes calor, te tiemblan las manos \n y una extraña alegría y una oleada de adrenalina se apoderan de ti mientras tu corazón se acelera \n salvajemente en tu pecho."

# game/script.rpy:2462
translate Spanish circo_final_eee7922b:

    # p "Did you like my show?"
    p "¿Te gustó mi espectáculo?"

# game/script.rpy:2464
translate Spanish circo_final_9bb3ef8a:

    # mc "O-of course, it was… it was…"
    mc "P-por supuesto, fue… fue…"

# game/script.rpy:2468
translate Spanish circo_final_54ef6c33:

    # mc "Amazing! Your performance was amazing! It almost looked like two people dancing out there!"
    mc "¡Increíble! ¡Tu actuación fue increíble! ¡Casi parecían dos personas bailando ahí afuera!"

# game/script.rpy:2469
translate Spanish circo_final_0b8fbb83:

    # mc "And your magic tricks too! How did you make that woman seem so real?"
    mc "¡Y tus trucos de magia también! ¿Cómo hiciste que esa mujer pareciera tan real?"

# game/script.rpy:2471
translate Spanish circo_final_c112c328:

    # mc "Scary! I mean, I know scaring people is kind of your whole thing, but I wasn’t ready for that hah."
    mc "¡Aterrador! Quiero decir, sé que asustar a la gente es lo tuyo, pero no estaba preparad[letra] para eso, ja."

# game/script.rpy:2472
translate Spanish circo_final_800f2af8:

    # mc "That woman looked so real… I wasn’t sure if it was part of the act or…"
    mc "Esa mujer parecía tan real... No estaba segur[letra] de si era parte del acto o..."

# game/script.rpy:2473
translate Spanish circo_final_ed55e5d1:

    # mc "Heh, anyway… y-you really caught me off guard! How did you do that?"
    mc "Je, de todos modos... ¡realmente me tomaste desprevenid[letra]! ¿Cómo hiciste eso?"

# game/script.rpy:2475
translate Spanish circo_final_81149982:

    # mc "That was fun! I’ll admit it wasn’t what I expected, And that whole scene with the woman tied up? That was wild!"
    mc "¡Eso fue divertido! Admito que no era lo que esperaba. ¿Y toda esa escena con la mujer atada? ¡Eso fue una locura!"

# game/script.rpy:2476
translate Spanish circo_final_d816043e:

    # mc "How did you even do that?"
    mc "¿Cómo hiciste eso?"

# game/script.rpy:2486
translate Spanish circo_final_8479b233:

    # mc "So many secrets…"
    mc "Tantos secretos..."

# game/script.rpy:2492
translate Spanish circo_final_92d0f7a3:

    # p "{i}Why don’t you stay a little longer? I could show you the rest of the circus."
    p "{i}¿Por qué no te quedas un poco más? Podría mostrarte el resto del circo."

# game/script.rpy:2494
translate Spanish circo_final_c1677848:

    # mc "Actually, I should probably get going. It’s not a great idea to be wandering around alone this late."
    mc "En realidad, probablemente debería irme. No es buena idea andar sol[letra] por ahí a estas horas."

# game/script.rpy:2498
translate Spanish circo_final_a29c62c7:

    # p "Shall I escort you, [titulo_pierrot]? If you’re frightened, I can ensure you reach safety."
    p "¿Me permites escoltarte, [titulo_pierrot!t]? Si tienes miedo, puedo asegurarme de que llegues a salvo."

# game/script.rpy:2500
translate Spanish circo_final_0c634a58:

    # mc "No need, really! I’m fine, don’t worry. I wouldn’t want to bother you."
    mc "¡No es necesario, de verdad! Estoy bien, no te preocupes. No quisiera molestarte."

# game/script.rpy:2502
translate Spanish circo_final_f8c64441:

    # p "May I see you again tomorrow?"
    p "¿Puedo verte de nuevo mañana?"

# game/script.rpy:2506
translate Spanish circo_final_5dc2e6b0:

    # mc "Sure, why not? Things got a lot more interesting with you around."
    mc "Claro, ¿por qué no? Las cosas se pusieron mucho más interesantes contigo."

# game/script.rpy:2513
translate Spanish circo_final_6d195d3d:

    # mc "W-Woah!"
    mc "¡V-vaya!"

# game/script.rpy:2515
translate Spanish circo_final_eb85262c:

    # p "I shall look forward to it, [titulo_pierrot]."
    p "Lo esperaré con ansias, [titulo_pierrot!t]."

# game/script.rpy:2517
translate Spanish circo_final_d59d272a:

    # mc "Hah, see you tomorrow, Pierrot."
    mc "Ja, nos vemos mañana, Pierrot."

# game/script.rpy:2519
translate Spanish circo_final_f058f0f4:

    # p "Until tomorrow, [mc_nome], my dearest."
    p "Hasta mañana, [mc_nome], mi querid[letra]."

# game/script.rpy:2524
translate Spanish circo_final_22d5b5b9:

    # mc " I… think it’s better if I don’t."
    mc " Yo... creo que es mejor que no lo haga."

# game/script.rpy:2531
translate Spanish circo_final_3fe20344:

    # p "B-but… why? Did I do something wrong, [titulo_pierrot]?"
    p "P-pero… ¿por qué? ¿Hice algo malo, [titulo_pierrot!t]?"

# game/script.rpy:2541
translate Spanish circo_final_a5783a0c:

    # mc "I’m just… not so sure about all this. Give me some time, okay?"
    mc "Es que… no estoy tan segur[letra] de todo esto. Dame algo de tiempo, ¿sí?"

# game/script.rpy:2543
translate Spanish circo_final_3190f647:

    # p "{cps=5}{size=45}..."
    p "{cps=5}{size=45}..."

# game/script.rpy:2549
translate Spanish badend_c9426716:

    # mc "Well… good night."
    mc "Bueno… buenas noches."

# game/script.rpy:2558
translate Spanish badend_de6c605a:

    # p "Wait! … S-since I won’t get to see you tomorrow… may I give you one last gift?"
    p "¡Espera! … P-puesto que no podré verte mañana… ¿puedo darte un último regalo?"

# game/script.rpy:2560
translate Spanish badend_8cb9977f:

    # mc "Uh, well…"
    mc "Eh, bueno..."

# game/script.rpy:2562
translate Spanish badend_84ff54b8:

    # p "You must be starving! You haven’t eaten anything all day, have you [titulo_pierrot]?"
    p "¡Debes estar muriéndote de hambre! No has comido nada en todo el día, ¿verdad, [titulo_pierrot!t]?"

# game/script.rpy:2564
translate Spanish badend_dfd79f21:

    # mc "{color=#a0b0c0}(Ugh… he’s not wrong.)"
    mc "{color=#a0b0c0}(Uf… no se equivoca.)"

# game/script.rpy:2566
translate Spanish badend_a69d85dd:

    # p "I made this earlier, just for you. Please… try it and tell me if you like it."
    p "Hice esto antes, solo para ti. Por favor… pruébalo y dime si te gusta."

# game/script.rpy:2574
translate Spanish badend_934e937f:

    # mc "{color=#a0b0c0}(Aww, that’s actually kinda sweet. Well, I better eat so he’ll let me head home.)"
    mc "{color=#a0b0c0}(Aww, eso en realidad es un poco dulce. Bueno, será mejor que coma para que me deje regresar a casa.)"

# game/script.rpy:2582
translate Spanish badend_251f591d:

    # narrator "You eat the cake while Pierrot keeps you company."
    narrator "Te comes el pastel mientras Pierrot te hace compañía."

# game/script.rpy:2586
translate Spanish badend_ee5a20c9:

    # mc "That was really good! You’re actually great at this."
    mc "¡Eso estuvo muy bueno! Se te da muy bien esto."

# game/script.rpy:2595
translate Spanish badend_20ce0c64:

    # mc "Now I should just--"
    mc "Ahora debería simplemente--"

# game/script.rpy:2596
translate Spanish badend_706feeb9:

    # mc "{cps=10}Uhgn... ?"
    mc "{cps=10}Uhgn... ?"

# game/script.rpy:2598
translate Spanish badend_a6ee1d2d:

    # p "What is it? Are you thirsty?"
    p "¿Qué pasa? ¿Tienes sed?"

# game/script.rpy:2600
translate Spanish badend_858f1677:

    # mc "Yeah, but…"
    mc "Sí, pero…"

# game/script.rpy:2601
translate Spanish badend_621a4e9c:

    # mc "{sc=3}{color=#ff69b4}S-something’s wrong..."
    mc "{sc=3}{color=#ff69b4}Algo anda mal..."

# game/script.rpy:2602
translate Spanish badend_fbbe2cca:

    # mc "{sc=3}{color=#ff69b4}You..."
    mc "{sc=3}{color=#ff69b4}Tú..."

# game/script.rpy:2609
translate Spanish badend_8ff47503:

    # narrator "{sc=1}{color=#ff69b4}Your body collapses as your consciousness drifts away. You can feel someone holding \nyou tightly."
    narrator "{sc=1}{color=#ff69b4}Tu cuerpo colapsa mientras tu conciencia se aleja. Puedes sentir que alguien\n te abraza con fuerza."

# game/script.rpy:2610
translate Spanish badend_6c69fc8f:

    # narrator "{sc=1}{color=#ff69b4}Every sound seems distant, though you catch brief flashes of what’s happening \nbefore everything fades to black."
    narrator "{sc=1}{color=#ff69b4}Cada sonido parece distante, aunque captas breves destellos de lo que está sucediendo \nantes de que todo se vuelva negro."

# game/script.rpy:2612
translate Spanish badend_a4db942d:

    # p "T-That was close..."
    p "E-Eso estuvo cerca..."

# game/script.rpy:2613
translate Spanish badend_e02acca5:

    # p "I almost... almost lost you [titulo_pierrot]."
    p "Casi... casi te pierdo, [titulo_pierrot!t]."

# game/script.rpy:2614
translate Spanish badend_4bfbeb08:

    # p "{sc=1}{color=#ffaf54}I saw it in your eyes... you were going to leave me, weren’t you?"
    p "{sc=1}{color=#ffaf54}Lo vi en tus ojos... me ibas a dejar, ¿no?"

# game/script.rpy:2615
translate Spanish badend_c08f7cee:

    # p "{sc=1}{color=#ffaf54}For a second... I thought I’d have to..."
    p "{sc=1}{color=#ffaf54}Por un segundo... pensé que tendría que..."

# game/script.rpy:2624
translate Spanish badend_1402f120:

    # p "N-No... It’s all right now. Everything’s fine."
    p "N-No... Todo está bien ahora. Todo está bien."

# game/script.rpy:2625
translate Spanish badend_55c53e21:

    # p "You just needed... to stop fighting me."
    p "Sólo necesitabas... dejar de pelear conmigo."

# game/script.rpy:2626
translate Spanish badend_b9ee9a67:

    # p "{b}M-Maybe this was all a little game of pretend?"
    p "{b}¿T-tal vez todo esto fue solo un pequeño juego de fingir?"

# game/script.rpy:2627
translate Spanish badend_59fa175a:

    # p "{b}Maybe you wanted me to chase you?"
    p "{b}¿Quizás querías que te persiguiera?"

# game/script.rpy:2628
translate Spanish badend_4d02a52d:

    # p "Or... maybe I moved too fast."
    p "O... tal vez me moví demasiado rápido."

# game/script.rpy:2629
translate Spanish badend_bb26d850:

    # p "I should’ve been more patient... more gentle."
    p "Debería haber sido más paciente... más delicado."

# game/script.rpy:2630
translate Spanish badend_4e34f402:

    # p "I scared you, didn’t I?"
    p "Te asusté, ¿no?"

# game/script.rpy:2650
translate Spanish badend_cee985f8:

    # p "I’ll take good care of you, I promise."
    p "Te cuidaré bien, lo prometo."

# game/script.rpy:2651
translate Spanish badend_4be1ee42:

    # p "{sc=1}{color=#ffaf54}Even if you try to run again..."
    p "{sc=1}{color=#ffaf54}Incluso si intentas huir de nuevo..."

# game/script.rpy:2652
translate Spanish badend_e628c5aa:

    # p "{sc=1}{color=#ffaf54}Even if you look at me like that again..."
    p "{sc=1}{color=#ffaf54}Incluso si me miras así otra vez..."

# game/script.rpy:2653
translate Spanish badend_20523514:

    # p "{sc=1}{color=#ffaf54}I’ll gently remind you that you need me."
    p "{sc=1}{color=#ffaf54}Te recordaré con delicadeza que me necesitas."

# game/script.rpy:2654
translate Spanish badend_e67097ce:

    # p "{sc=1}{color=#ffaf54}With kindness, patience... or with another dose."
    p "{sc=1}{color=#ffaf54}Con amabilidad, paciencia... o con otra dosis."

# game/script.rpy:2670
translate Spanish badend_21e1a017:

    # p "{sc=3}{color=#ffaf54}Because I love you."
    p "{sc=3}{color=#ffaf54}Porque te amo."

# game/script.rpy:2671
translate Spanish badend_659ddbb3:

    # p "{sc=1}{color=#ffaf54}My sweet angel..."
    p "{sc=1}{color=#ffaf54}Mi dulce ángel..."

# game/script.rpy:2672
translate Spanish badend_eb606bbc:

    # p "{sc=1}{color=#ff0000}Don’t make me devour you too."
    p "{sc=1}{color=#ff0000}No hagas que te devore también."

# game/script.rpy:2687
translate Spanish emcasa_598fa00e:

    # mc "Man, I’m exhausted..."
    mc "Uf, estoy agotad[letra]..."

# game/script.rpy:2690
translate Spanish emcasa_14bb3c93:

    # mc "But that was fun, kinda creepy too."
    mc "Pero eso fue divertido, y también un poco espeluznante."

# game/script.rpy:2691
translate Spanish emcasa_5e4a1b4c:

    # mc "I’m not even hungry anymore. I think I’ll just head straight to bed."
    mc "Ya ni siquiera tengo hambre. Creo que me iré directamente a la cama."

# game/script.rpy:2734
translate Spanish emcasa_5d6e319c:

    # p "{cps=15} We can take it slow then, [titulo_pierrot]..."
    p "{cps=15} Podemos ir despacio entonces, [titulo_pierrot!t]..."

# game/script.rpy:2734
translate Spanish emcasa_3acf283e:

    # p "{cps=15}I can be patient, I can smile at you and pretend I’m not burning inside."
    p "{cps=15}Puedo ser paciente, puedo sonreírte y fingir que no estoy ardiendo por dentro."

# game/script.rpy:2745
translate Spanish emcasa_d8f8f7dc:

    # p "{cps=20}{sc=2}{color=#ffaf54}Pretend I’m not imagining you breathless, trembling beneath my touch."
    p "{cps=20}{sc=2}{color=#ffaf54}Fingir que no te imagino sin aliento, temblando bajo mi tacto."

# game/script.rpy:2745
translate Spanish emcasa_0d24b0c9:

    # p "{cps=20}{sc=2}{color=#ffaf54}Just look at what you're doing to me..."
    p "{cps=20}{sc=2}{color=#ffaf54}Solo mira lo que me estás haciendo..."

# game/script.rpy:2745
translate Spanish emcasa_e3868373:

    # p "{cps=20}{sc=2}{color=#ffaf54}This love... it’s growing, twisting, taking shapes that might scare you if I showed you now."
    p "{cps=20}{sc=2}{color=#ffaf54}Este amor... está creciendo, retorciéndose, tomando formas que podrían asustarte\n si te las mostrara ahora."

# game/script.rpy:2745
translate Spanish emcasa_8d8f3870:

    # p "{cps=20}{sc=2}{color=#ffaf54}But that’s all right. I can keep it hidden, for now."
    p "{cps=20}{sc=2}{color=#ffaf54}Pero está bien. Puedo mantenerlo oculto, por ahora."

# game/script.rpy:2745
translate Spanish emcasa_7a3138c9:

    # p "{cps=20}{sc=2}{color=#ffaf54}That sweet demeanor... that gaze that teases me without even knowing it..."
    p "{cps=20}{sc=2}{color=#ffaf54}Ese comportamiento dulce... esa mirada que me provoca sin siquiera saberlo..."

# game/script.rpy:2745
translate Spanish emcasa_19125d33:

    # p "{cps=20}{sc=2}{color=#ffaf54}As if you weren’t aware that you’re poisoning me with love in every little gesture."
    p "{cps=20}{sc=2}{color=#ffaf54}Como si no fueras consciente de que me estás envenenando de amor en cada pequeño gesto."

# game/script.rpy:2745
translate Spanish emcasa_e4f9b2e6:

    # p "{cps=20}{sc=2}{color=#ffaf54}But that’s all right, [titulo_pierrot]...."
    p "{cps=20}{sc=2}{color=#ffaf54}Pero está bien, [titulo_pierrot!t]...."

# game/script.rpy:2745
translate Spanish emcasa_bb08a42e:

    # p "{cps=30}{sc=2}{color=#ffaf54}Because when I have you, it won’t be gentle."
    p "{cps=30}{sc=2}{color=#ffaf54}Porque cuando te tenga, no será suave."

# game/script.rpy:2745
translate Spanish emcasa_f2b9c17b:

    # p "{cps=30}{sc=2}{color=#ffaf54}I want it to be, but I know it won’t. I’ll leave my mark on you. From the inside out."
    p "{cps=30}{sc=2}{color=#ffaf54}Quiero que así sea, pero sé que no será así. Dejaré mi huella en ti. De adentro hacia afuera."

# game/script.rpy:2745
translate Spanish emcasa_29b861ee:

    # p "{cps=30}{sc=2}{color=#ffaf54}Until your body knows my name better than it knows your own."
    p "{cps=30}{sc=2}{color=#ffaf54}Hasta que tu cuerpo conozca mi nombre mejor que el tuyo."

# game/script.rpy:2778
translate Spanish emcasa_babff2f6:

    # p "{cps=30}{sc=2}{color=#ffaf54}Until your skin burns at the touch of anyone who isn’t me."
    p "{cps=30}{sc=2}{color=#ffaf54}Hasta que tu piel arda ante el contacto de cualquiera que no sea yo."

# game/script.rpy:2778
translate Spanish emcasa_6d30e3a2:

    # p "{cps=30}{sc=2}{color=#ffaf54}You’ll cry, tremble, beg… But not from pain... Well."
    p "{cps=30}{sc=2}{color=#ffaf54}Llorarás, temblarás, rogarás… Pero no de dolor… Bueno."

# game/script.rpy:2778
translate Spanish emcasa_21e1e2e1:

    # p "{cps=30}{sc=2}{color=#ffaf54}{i}Unless that’s what you want ♪"
    p "{cps=30}{sc=2}{color=#ffaf54}{i}A menos que eso sea lo que quieras ♪"

# game/script.rpy:2778
translate Spanish emcasa_ea249137:

    # p "{cps=30}{sc=2}{color=#ffaf54}I’ll always be there for you, hungry, yet gentle."
    p "{cps=30}{sc=2}{color=#ffaf54}Siempre estaré ahí para ti, hambriento, pero delicado."

# game/script.rpy:2778
translate Spanish emcasa_3fd4bef4:

    # p "{cps=30}{sc=2}{color=#ffaf54}That’s how you like it, isn’t it?"
    p "{cps=30}{sc=2}{color=#ffaf54}Así es como te gusta, ¿no?"

# game/script.rpy:2778
translate Spanish emcasa_0b9b7fb0:

    # p "{cps=30}{sc=2}{color=#ffaf54}But if it’s not, I can change."
    p "{cps=30}{sc=2}{color=#ffaf54}Pero si no es así, puedo cambiar."

# game/script.rpy:2778
translate Spanish emcasa_bd7ed9ec:

    # p "{cps=30}{sc=2}{color=#ffaf54}I can move to your rhythm, in whatever way you desire."
    p "{cps=30}{sc=2}{color=#ffaf54}Puedo moverme a tu ritmo, de la forma que desees."

# game/script.rpy:2778
translate Spanish emcasa_c3c60129:

    # p "{cps=30}{sc=2}{color=#ffaf54}In whatever way makes you mine."
    p "{cps=30}{sc=2}{color=#ffaf54}De cualquier forma que haga que seas mí[letra]."

# game/script.rpy:2778
translate Spanish emcasa_690cf5a3:

    # p "{cps=30}{sc=2}{color=#ffaf54}I can remake myself for you, shape myself to fit the image you hold of me."
    p "{cps=30}{sc=2}{color=#ffaf54}Puedo rehacerme para ti, moldearme para adaptarme a la imagen que tienes de mí."

# game/script.rpy:2778
translate Spanish emcasa_3532273a:

    # p "{cps=30}{sc=2}{color=#ffaf54}Do you want me gentle? Affectionate? Shy? Or perhaps… bold?"
    p "{cps=30}{sc=2}{color=#ffaf54}¿Quieres que sea delicado? ¿Cariñoso? ¿Tímido? O tal vez… ¿audaz?"

# game/script.rpy:2778
translate Spanish emcasa_b3561bb3:

    # p "{cps=30}{sc=2}{color=#ffaf54}Do you want a hunter, chasing you with relentless passion?"
    p "{cps=30}{sc=2}{color=#ffaf54}¿Quieres un cazador que te persiga con pasión implacable?"

# game/script.rpy:2778
translate Spanish emcasa_f11fcb1f:

    # p "{cps=30}{sc=2}{color=#ffaf54}Do you want me rough?"
    p "{cps=30}{sc=2}{color=#ffaf54}¿Quieres que sea brusco?"

# game/script.rpy:2778
translate Spanish emcasa_05f03959:

    # p "{cps=30}{sc=2}{color=#ffaf54}It’s all right ♪ I’ll learn what takes your breath away."
    p "{cps=30}{sc=2}{color=#ffaf54}Está bien ♪ Descubriré qué te deja sin aliento."

# game/script.rpy:2778
translate Spanish emcasa_69ed03e0:

    # p "{cps=30}{sc=2}{color=#ffaf54}I’ll learn the intensity that makes your soul, and your body tremble for me."
    p "{cps=30}{sc=2}{color=#ffaf54}Aprenderé la intensidad que hace temblar tu alma y tu cuerpo por mí."

# game/script.rpy:2778
translate Spanish emcasa_ead97a35:

    # p "{cps=30}{sc=2}{color=#ffaf54}Because I love you, [titulo_pierrot] [mc_nome]."
    p "{cps=30}{sc=2}{color=#ffaf54}Porque te amo, [titulo_pierrot!t] [mc_nome]."

# game/script.rpy:2814
translate Spanish emcasa_8d900541:

    # p "And for you... I can be everything."
    p "Y para ti... puedo serlo todo."

# game/script.rpy:2827
translate Spanish envenenada_eee7922b:

    # p "Did you like my show?"
    p "¿Te gustó mi espectáculo?"

# game/script.rpy:2837
translate Spanish envenenada_9f64e12f:

    # mc "{sc=1}That was amazing!! I can’t even explain it. At first I felt scared and unsure,\n but now everything just feels so... incredible!"
    mc "{sc=1}¡¡Eso fue increíble!! Ni siquiera puedo explicarlo. Al principio me sentí asustad[letra] e insegur[letra], \n pero ahora todo se siente tan... ¡increíble!"

# game/script.rpy:2839
translate Spanish envenenada_269e632f:

    # narrator "{sc=1}{color=#ff69b4}He's still so close, whispering, keeping the conversation just between you two."
    narrator "{sc=1}{color=#ff69b4}Él sigue muy cerca, susurrando para mantener la conversación solo entre ustedes dos."

# game/script.rpy:2841
translate Spanish envenenada_0707dfd1:

    # mc "{sc=1.5}{color=#ff69b4}(My heart won’t stop racing... maybe... I actually like him?)"
    mc "{sc=1.5}{color=#ff69b4}(Mi corazón no deja de latir acelerado... tal vez... ¿realmente me gusta?)"

# game/script.rpy:2842
translate Spanish envenenada_b2a0cb75:

    # mc "{sc=2}{color=#ff69b4}(I feel kind of nervous when he gets this close.)"
    mc "{sc=2}{color=#ff69b4}(Me siento un poco nervios[letra] cuando se acerca tanto.)"

# game/script.rpy:2847
translate Spanish envenenada_47a8c8ed:

    # p "Would you like me to show you the rest of the circus?"
    p "¿Quieres que te muestre el resto del circo?"

# game/script.rpy:2849
translate Spanish envenenada_d04aae61:

    # mc "{sc=1}{color=#ff69b4}Of course! I... I’d love to spend more time with you."
    mc "{sc=1}{color=#ff69b4}¡Por supuesto! Yo... me encantaría pasar más tiempo contigo."

# game/script.rpy:2855
translate Spanish envenenada_cd43e4ad:

    # narrator "{sc=1}{color=#ff69b4}You take his hand. He blushes and squeezes yours firmly."
    narrator "{sc=1}{color=#ff69b4}Le tomas la mano. Él se sonroja y aprieta la tuya con firmeza."

# game/script.rpy:2857
translate Spanish envenenada_f5f27c33:

    # p "I’m certain you will find this place quite delightful, [titulo_pierrot]."
    p "Estoy seguro de que este lugar te parecerá encantador, [titulo_pierrot!t]."

# game/script.rpy:2859
translate Spanish envenenada_be40eb9f:

    # narrator "{sc=1}{color=#ff69b4}You smile, panting lightly, staring into Pierrot's grinning mask."
    narrator "{sc=1}{color=#ff69b4}Sonríes, jadeando ligeramente, mirando la máscara sonriente de Pierrot."

# game/script.rpy:2861
translate Spanish envenenada_70a525eb:

    # mc "{sc=3}{color=#ff69b4}(I'm... feeling dizzy...)" with fade
    mc "{sc=3}{color=#ff69b4}(Me siento... maread[letra]...)" with fade

# game/script.rpy:2862
translate Spanish envenenada_8cb1086a:

    # mc "{sc=3}{color=#ff69b4}I think... something’s wrong with me..." with fade
    mc "{sc=3}{color=#ff69b4}Creo... que algo anda mal conmigo..." with fade

# game/script.rpy:2870
translate Spanish envenenada_42eb6a9c:

    # p "Wha-- [titulo_pierrot]??"
    p "¿Qu-- [titulo_pierrot!t]??"

# game/script.rpy:2872
translate Spanish envenenada_9d7d8409:

    # narrator "{sc=1}{color=#ff69b4}Your body collapses as your consciousness drifts away. You can feel someone holding you tightly."
    narrator "{sc=1}{color=#ff69b4}Tu cuerpo se desploma mientras tu conciencia se aleja. Puedes sentir que alguien te sostiene con fuerza."

# game/script.rpy:2873
translate Spanish envenenada_6c69fc8f:

    # narrator "{sc=1}{color=#ff69b4}Every sound seems distant, though you catch brief flashes of what’s happening \nbefore everything fades to black."
    narrator "{sc=1}{color=#ff69b4}Cada sonido parece distante, aunque captas breves destellos de lo que está sucediendo \nantes de que todo se vuelva negro."

# game/script.rpy:2875
translate Spanish envenenada_2a3849e6:

    # p "{sc=1}{color=#ffaf54}What...?"
    p "{sc=1}{color=#ffaf54}¿Qué...?"

# game/script.rpy:2876
translate Spanish envenenada_d3162b9a:

    # p "Oh,{w=0.3}{cps=10} {i}I see now."
    p "Oh, {w=0.3}{cps=10}{i}Ya veo."

# game/script.rpy:2877
translate Spanish envenenada_df509fd3:

    # p "{cps=20}It's all right, [mc_nome] I am here to take care of you."
    p "{cps=20}Está bien, [mc_nome], estoy aquí para cuidarte."

# game/script.rpy:2880
translate Spanish envenenada_7f891bec:

    # p "{i}Oh, [titulo_pierrot] ♪"
    p "{i}Oh, [titulo_pierrot!t] ♪"

# game/script.rpy:2881
translate Spanish envenenada_ad3427c3:

    # p "{i}You’ve been waiting for this, haven’t you? Ah... but not nearly as much as I have."
    p "{i}Has estado esperando esto, ¿verdad? Ah... pero no tanto como yo."

# game/script.rpy:2882
translate Spanish envenenada_d1425dd0:

    # p "{i}It feels so {b}unbelievably{/b} good to hold you like this."
    p "{i}Se siente tan {b}increíblemente{/b} bien abrazarte así."

# game/script.rpy:2883
translate Spanish envenenada_ab42c3e8:

    # p "{sc=3}{color=#ffaf54}Finally mine."
    p "{sc=3}{color=#ffaf54}Por fin eres mí[letra]."

# game/script.rpy:2892
translate Spanish envenenada_c9458fb8:

    # p "{sc=1}{color=#ffaf54}The warmth of your skin… the scent of your flesh…"
    p "{sc=1}{color=#ffaf54}El calor de tu piel... el aroma de tu carne..."

# game/script.rpy:2893
translate Spanish envenenada_266f5d7a:

    # p "{sc=1}{color=#ffaf54}You have no idea what you’re doing to me right now…"
    p "{sc=1}{color=#ffaf54}No tienes idea de lo que me estás haciendo ahora mismo..."

# game/script.rpy:2907
translate Spanish envenenada_f7d1cf8a:

    # p "{sc=1}{color=#ffaf54}{b}The way your breath falters… how your body yields, even in unconsciousness."
    p "{sc=1}{color=#ffaf54}{b}La forma en que te falla la respiración... cómo tu cuerpo cede, \n incluso en la inconsciencia."

# game/script.rpy:2908
translate Spanish envenenada_5679af23:

    # p "{sc=1}{color=#ffaf54}{b}It's cruel of you, you know?"
    p "{sc=1}{color=#ffaf54}{b}Es cruel de tu parte, ¿sabes?"

# game/script.rpy:2909
translate Spanish envenenada_459d9f49:

    # p "{sc=1}{color=#ffaf54}To be so {b}delici-- {nw=0.2}"
    p "{sc=1}{color=#ffaf54}Para ser tan {b}delici-- {nw=0.2}"

# game/script.rpy:2910
translate Spanish envenenada_2ae6fec1:

    # p "{sc=1}{color=#ffaf54}{b}Lovely! so…{w=0.1} delicate."
    p "{sc=1}{color=#ffaf54}{b}¡Adorable! tan…{w=0.1} delicad[letra]."

# game/script.rpy:2911
translate Spanish envenenada_cab94879:

    # p "{sc=1}{color=#ffaf54}{b}And to leave me here,{w=0.1} on the edge of losing control."
    p "{sc=1}{color=#ffaf54}{b}Y dejarme aquí,{w=0.1} al borde de perder el control."

# game/script.rpy:2925
translate Spanish envenenada_fce2bd4e:

    # p "{sc=2}{color=#ffaf54}{b}I have so many thoughts, [titulo_pierrot]…"
    p "{sc=2}{color=#ffaf54}{b}Tengo tantos pensamientos, [titulo_pierrot!t]…"

# game/script.rpy:2926
translate Spanish envenenada_39f57a5a:

    # p "{sc=2}{color=#ffaf54}{b}So many desires…"
    p "{sc=2}{color=#ffaf54}{b}Tantos deseos…"

# game/script.rpy:2927
translate Spanish envenenada_fe7b02e4:

    # p "{sc=2}{color=#ffaf54}{b}My hands ache to explore every inch of you."
    p "{sc=2}{color=#ffaf54}{b}Me duelen las manos por explorar cada centímetro de ti."

# game/script.rpy:2928
translate Spanish envenenada_da68b8a9:

    # p "{sc=2}{color=#ffaf54}{b}My teeth itch at the thought of marking you. Claiming you as mine."
    p "{sc=2}{color=#ffaf54}{b}Me pican los dientes ante la idea de marcarte. Haciéndote mí[letra]."

# game/script.rpy:2929
translate Spanish envenenada_2c9a523d:

    # p "{sc=2}{color=#ffaf54}{b}But… no. Not yet."
    p "{sc=2}{color=#ffaf54}{b}Pero… no. Aún no."

# game/script.rpy:2944
translate Spanish envenenada_6ed19b8f:

    # p "{sc=2}{color=#ffaf54}{b}That wouldn’t be any fun, would it?"
    p "{sc=2}{color=#ffaf54}{b}Eso no sería divertido, ¿verdad?"

# game/script.rpy:2945
translate Spanish envenenada_371368f9:

    # p "{sc=2}{color=#ffaf54}{b}You need to see."
    p "{sc=2}{color=#ffaf54}{b}Necesitas ver."

# game/script.rpy:2946
translate Spanish envenenada_8bd0b5c5:

    # p "{sc=2}{color=#ffaf54}{b}To feel."
    p "{sc=2}{color=#ffaf54}{b}Sentir."

# game/script.rpy:2947
translate Spanish envenenada_6c8a9a40:

    # p "{sc=2}{color=#ffaf54}{b}To… choose. Choose me."
    p "{sc=2}{color=#ffaf54}{b}Para… elegir. Elígeme."

# game/script.rpy:2948
translate Spanish envenenada_7cccbf2f:

    # p "{sc=2}{color=#ffaf54}{b}Even though I’m completely obsessed with you right now."
    p "{sc=2}{color=#ffaf54}{b}Aunque estoy completamente obsesionado contigo en este momento."

# game/script.rpy:2949
translate Spanish envenenada_5e1f41f9:

    # p "{sc=2}{color=#ffaf54}{b}I’ll wait."
    p "{sc=2}{color=#ffaf54}{b}Esperaré."

# game/script.rpy:2956
translate Spanish envenenada_1221f079:

    # p "{sc=1}{color=#ffaf54}{b}For when you wake up..."
    p "{sc=1}{color=#ffaf54}{b}Para cuando te despiertes..."

# game/script.rpy:2957
translate Spanish envenenada_e0a152af:

    # p "{b}...I want your eyes on mine."
    p "{b}...Quiero tus ojos en los míos."

# game/script.rpy:2971
translate Spanish fimrosa_b893220d:

    # b "Oh! {w=0.2}That ticket gives you special access."
    b "¡Ah! {w=0.2}Ese boleto te da acceso especial."

# game/script.rpy:2973
translate Spanish fimrosa_97b975c0:

    # b "Please, come this way."
    b "Por favor, ven por aquí."

# game/script.rpy:2975
translate Spanish fimrosa_c906a3d0:

    # mc "Really? Wow, thanks!"
    mc "¿De verdad? ¡Vaya, gracias!"

# game/script.rpy:2983
translate Spanish fimrosa_5dcecf32:

    # mc "Huh? But it’s so dark in here..."
    mc "¿Eh? Pero está tan oscuro aquí..."

# game/script.rpy:2985
translate Spanish fimrosa_f88ed550:

    # mc "Hey{nw}"
    mc "Oye{nw}"

# game/script.rpy:2993
translate Spanish fimrosa_7003f3a0:

    # narrator "You feel a heavy blow before everything goes black."
    narrator "Sientes un fuerte golpe antes de que todo se vuelva negro."

# game/script.rpy:2995
translate Spanish fimrosa_afa462f3:

    # d "Take [persistent.p_objeto] to the back."
    d "Lléval[letra] a la parte de atrás."

# game/script.rpy:3000
translate Spanish fimrosa_c505ecc2:

    # mc "Mmhn... {color=#a0b0c0}(My head...)"
    mc "Mmhn... {color=#a0b0c0}(Mi cabeza...)"

# game/script.rpy:3001
translate Spanish fimrosa_31142c52:

    # mc "{color=#a0b0c0}(What...? I can’t move my legs... or my arms.)"
    mc "{color=#a0b0c0}(¿Qué...? No puedo mover las piernas... ni los brazos.)"

# game/script.rpy:3002
translate Spanish fimrosa_1ac5033f:

    # mc "Hummm uhuunmb!!!"
    mc "Hummm uhuunmb!!!"

# game/script.rpy:3003
translate Spanish fimrosa_52841208:

    # mc "{color=#a0b0c0}(My mouth is covered am I... tied up?)"
    mc "{color=#a0b0c0}(Mi boca está cubierta, ¿estoy... atad[letra]?)"

# game/script.rpy:3008
translate Spanish fimrosa_c972a20d:

    # des "{color=#2c1ee6}Looks like they're awake. They're pretty."
    des "{color=#2c1ee6}Parece que ya despertó. Es bonit[letra]."

# game/script.rpy:3010
translate Spanish fimrosa_02e50261:

    # des "{color=#2c1ee6}Looks like [persistent.p_sujeito]’s awake. [persistent.p_sujeito]’s pretty."
    des "{color=#2c1ee6}Parece que [persistent.p_sujeito!t] ya despertó. [persistent.p_sujeito!t] es bonit[letra]."

# game/script.rpy:3012
translate Spanish fimrosa_c93b6557:

    # des "{color=#2c1ee6}Let’s begin. Anyone interested in this one?"
    des "{color=#2c1ee6}Comencemos. ¿Alguien interesado en esta persona?"

# game/script.rpy:3017
translate Spanish fimrosa_bf222104:

    # des "{color=#ffaf54}No."
    des "{color=#ffaf54}No."

# game/script.rpy:3018
translate Spanish fimrosa_84dd845a:

    # des "{color=#41d623}Then I’m out too."
    des "{color=#41d623}Entonces yo también me retiro."

# game/script.rpy:3019
translate Spanish fimrosa_df58312f:

    # des "{color=#ffaf54}..."
    des "{color=#ffaf54}..."

# game/script.rpy:3020
translate Spanish fimrosa_214284b1:

    # des "{color=#961ee6}Hmm... No."
    des "{color=#961ee6}Mmmm... No."

# game/script.rpy:3021
translate Spanish fimrosa_71c8478e:

    # des "{color=#e74c3c}Nope."
    des "{color=#e74c3c}No."

# game/script.rpy:3022
translate Spanish fimrosa_4e8b773f:

    # des "{color=#2c1ee6}Hmm.. I think I’ll pass too."
    des "{color=#2c1ee6}Hmm... Creo que yo también pasaré."

# game/script.rpy:3024
translate Spanish fimrosa_2911edc3:

    # des "{color=#2c1ee6}Muy bien, entonces podemos trasladar a [persistent.p_objeto]..."
    des "{color=#2c1ee6}Muy bien, entonces podemos trasladarl[letra]..."

# game/script.rpy:3027
translate Spanish fimrosa_d891470b:

    # des "{b}{cps=20}{color=#2c1ee6}Or devour [persistent.p_objeto]."
    des "{b}{cps=20}{color=#2c1ee6}O devorarl[letra]."

# game/script.rpy:3032
translate Spanish fimrosa_c8c679ea:

    # narrator "You failed to catch the Pierrot’s attention... and met a tragic end."
    narrator "No lograste captar la atención de Pierrot... y tuviste un final trágico."

# game/script.rpy:3033
translate Spanish fimrosa_a58a683e:

    # narrator "{color=#e61ecb}Ending: Missing."
    narrator "{color=#e61ecb}Final: Desaparecid[letra]."

translate Spanish strings:

    # game/script.rpy:4
    old "Harlequin"
    new "Arlequín"

    # game/script.rpy:5
    old "Unknown"
    new "Desconocido"

    # game/script.rpy:6
    old "Strange 1"
    new "Extraño 1"

    # game/script.rpy:7
    old "Boss"
    new "Jefe"

    # game/script.rpy:8
    old "Customer 1"
    new "Cliente 1"

    # game/script.rpy:9
    old "Customer 2"
    new "Cliente 2"

    # game/script.rpy:10
    old "Customer 3"
    new "Cliente 3"

    # game/script.rpy:11
    old "Customer 4"
    new "Cliente 4"

    # game/script.rpy:12
    old "Customer 5"
    new "Cliente 5"

    # game/script.rpy:15
    old "Woman"
    new "Mujer"

    # game/script.rpy:16
    old "Ticket taker"
    new "Boletero"

    # game/script.rpy:32
    old "{size=40}A few quick instructions:"
    new "{size=40}Algunas instrucciones rápidas:"

    # game/script.rpy:39
    old "{size=50}Remember to adjust the game volume, some sounds might be louder.\nEnjoy the game!"
    new "{size=50}Recuerda ajustar el volumen del juego, algunos sonidos pueden ser más fuertes.\n¡Disfruta del juego!"

    # game/script.rpy:48
    old "{size=45}What are your pronouns?"
    new "{size=45}¿Cuáles son tus pronombres?"

    # game/script.rpy:55
    old "What name is on your badge?"
    new "¿Qué nombre aparece en tu gafete?"

    # game/script.rpy:171
    old "Intervene"
    new "Intervenir"

    # game/script.rpy:180
    old "Yell at the man"
    new "Gritarle al hombre"

    # game/script.rpy:188
    old "Do nothing"
    new "No hacer nada"

    # game/script.rpy:209
    old "Comfort him."
    new "Consolarlo."

    # game/script.rpy:217
    old "Offer a bandage."
    new "Ofrecerle una venda."

    # game/script.rpy:281
    old "{size=50}Click on the tables to deliver orders"
    new "{size=50}Haz clic en las mesas para entregar los pedidos"

    # game/script.rpy:484
    old "Take it"
    new "Tómalo"

    # game/script.rpy:491
    old "Decline"
    new "Rechazarlo"

    # game/script.rpy:572
    old "Turn on the lights"
    new "Encender las luces"

    # game/script.rpy:575
    old "Pick up a knife"
    new "Recoger un cuchillo"

    # game/script.rpy:583
    old "Check for intruder"
    new "Comprobar si hay intrusos"

    # game/script.rpy:655
    old "Ask him to leave"
    new "Pedirle que se vaya"

    # game/script.rpy:677
    old "Help with the injury"
    new "Ayudarlo con la herida"

    # game/script.rpy:1261
    old "Ask to pass"
    new "Pedir permiso para pasar"

    # game/script.rpy:1273
    old "Ignore him"
    new "Ignorarlo"

    # game/script.rpy:1500
    old "I promise"
    new "Lo prometo"

    # game/script.rpy:1588
    old "Weird"
    new "Raro"

    # game/script.rpy:1591
    old "Cute"
    new "Lindo"

    # game/script.rpy:1593
    old "Creepy"
    new "Espeluznante"

    # game/script.rpy:1714
    old "Give a bandage"
    new "Darle una venda"

    # game/script.rpy:1719
    old "Check the wound"
    new "Revisar la herida"

    # game/script.rpy:1774
    old "Pink tent"
    new "Carpa rosa"

    # game/script.rpy:1782
    old "Purple tent"
    new "Carpa morada"

    # game/script.rpy:1786
    old "Green tent"
    new "Carpa verde"

    # game/script.rpy:1926
    old "{glitch=20}{color=#e61ee6}The monsters realized a{/color}{color=#e73314} sacrifice{/color}{color=#e61ee6} would be necessary.{/glitch}"
    new "{glitch=20}{color=#e61ee6}Los monstruos se dieron cuenta de que un{/color}{color=#e73314} sacrificio{/color}{color=#e61ee6} sería necesario.{/glitch}"

    # game/script.rpy:1954
    old "{glitch=20}{b}{color=#e61ee6}Please, no!{/glitch}"
    new "{glitch=20}{b}{color=#e61ee6}¡POR FAVOR, NO!{/glitch}"

    # game/script.rpy:1956
    old "{glitch=20}{b}{color=#961ee6}We have no choice.{/glitch}"
    new "{glitch=20}{b}{color=#961ee6}No tenemos otra opción.{/glitch}"

    # game/script.rpy:1958
    old "{glitch=20}{b}{color=#41d623}She is the weakest of us.{/glitch}"
    new "{glitch=20}{b}{color=#41d623}Ella es la más débil de nosotros.{/glitch}"

    # game/script.rpy:1960
    old "{glitch=20}{b}{color=#ffffff}You will give us the strength to go on.{/glitch}"
    new "{glitch=20}{b}{color=#ffffff}Nos darás la fuerza para seguir adelante.{/glitch}"

    # game/script.rpy:2121
    old "Yes"
    new "Sí"

    # game/script.rpy:2145
    old "No"
    new "No"

    # game/script.rpy:2234
    old "Buy some food"
    new "Comprar algo de comida"

    # game/script.rpy:2238
    old "Popcorn"
    new "Palomitas de maiz"

    # game/script.rpy:2241
    old "Sweet popcorn"
    new "Palomitas dulces"

    # game/script.rpy:2244
    old "Candy apple"
    new "Manzana de caramelo"

    # game/script.rpy:2264
    old "Hot dog"
    new "Perrito caliente"

    # game/script.rpy:2268
    old "Forget it"
    new "Olvidarlo"

    # game/script.rpy:2467
    old "Amazing"
    new "Increíble"

    # game/script.rpy:2470
    old "Scary "
    new "Aterrador"

    # game/script.rpy:2474
    old "Fun"
    new "Divertido"

    # game/script.rpy:2505
    old "Sure"
    new "Seguro"

    # game/script.rpy:2522
    old "Better not"
    new "Mejor no"

    # game/script.rpy:2829
    old "{sc=2}{color=#ff69b4}Yes"
    new "{sc=2}{color=#ff69b4}Sí"
    
    old "Anchor: William B."
    new "Presentador: William B."

    old "Anchor: Fatima B."
    new "Presentadora: Fatima B."

