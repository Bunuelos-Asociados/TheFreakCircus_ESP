# TODO: Translation updated at 2026-10-03 14:34

translate Spanish strings:

    old "my dear"
    new "mi cielo"

    old "my lady"
    new "milady"

    old "my lord"
    new "milord"

    old "dear one"
    new "cielo"

    old "ma'am"
    new "madam"

    old "sir"
    new "sir"

    old "Mestra"
    new "Maestra"

    old "Mestre"
    new "Maestro"

    old "Monarca"
    new "Monarca"
    
    old "she"
    new "ella"
    
    old "he"
    new "él"
    
    old "they"
    new "elle"
    
    # game/pronomes.rpy:31
    old "He / Him"
    new "Él"

    # game/pronomes.rpy:31
    old "She / Her"
    new "Ella"

    # game/pronomes.rpy:31
    old "They / Them"
    new "Elle"
