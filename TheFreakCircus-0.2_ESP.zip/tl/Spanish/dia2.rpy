# TODO: Translation updated at 2026-10-03 14:34

# game/dia2.rpy:36
translate Spanish sonho_07f71e15:

    # narrator "{color=#3325f7}Hello, dear visitor, good to see you again."
    narrator "{color=#3325f7}Hola, querid[letra] visitante. Me alegra volver a verte."

# game/dia2.rpy:37
translate Spanish sonho_72f3dec2:

    # narrator "{color=#3325f7}But you’re very far… come closer."
    narrator "{color=#3325f7}Pero estás muy lejos… acércate."

# game/dia2.rpy:39
translate Spanish sonho_95923b62:

    # narrator "{color=#3325f7}Now, what are your pronouns again?"
    narrator "{color=#3325f7}Ahora, ¿cuáles son tus pronombres?"

# game/dia2.rpy:93
translate Spanish sonho_8d6b82be:

    # narrator "{color=#3325f7}And your name?"
    narrator "{color=#3325f7}¿Y tu nombre?"

# game/dia2.rpy:137
translate Spanish nomedenovo_672d25b7:

    # narrator "{color=#3325f7}Of course it was, [mc_nome]. I thought you’d tell me a different one this time."
    narrator "{color=#3325f7}Por supuesto que sí, [mc_nome]. Pensé que esta vez me dirías otro."

# game/dia2.rpy:143
translate Spanish nomedenovo_1ef5374f:

    # narrator "{color=#3325f7}Sure, so let’s recap a few things."
    narrator "{color=#3325f7}Claro, recapitulemos algunas cosas."

# game/dia2.rpy:144
translate Spanish nomedenovo_cce47407:

    # narrator "{color=#3325f7}I remember, you helped Pierrot that day, but did you help with his injury at the café?"
    narrator "{color=#3325f7}Recuerdo que ayudaste a Pierrot ese día, pero ¿lo ayudaste con su herida en el café?"

# game/dia2.rpy:185
translate Spanish nomedenovo_9cb9ea09:

    # narrator "{color=#3325f7}Good."
    narrator "{color=#3325f7}Bien."

# game/dia2.rpy:196
translate Spanish nomedenovo_463dd2c8:

    # narrator "{color=#3325f7}And in Harlequin’s tent, did you enjoy his company?"
    narrator "{color=#3325f7}Y en la carpa de Arlequín, ¿disfrutaste de su compañía?"

# game/dia2.rpy:213
translate Spanish nomedenovo_602b8023:

    # narrator "{color=#3325f7}Really?{w=0.2} I didn’t see that coming,{w=0.2} maybe not even him."
    narrator "{color=#3325f7}¿En serio?{w=0.2} No lo vi venir,{w=0.2} tal vez ni siquiera él."

# game/dia2.rpy:222
translate Spanish nomedenovo_0f8338de:

    # narrator "{color=#3325f7}It was expected."
    narrator "{color=#3325f7}Era de esperar."

# game/dia2.rpy:230
translate Spanish nomedenovo_5f5c67ff:

    # narrator "{color=#3325f7}Did you eat anything from the circus that day?"
    narrator "{color=#3325f7}¿Comiste algo del circo ese día?"

# game/dia2.rpy:237
translate Spanish nomedenovo_3288c626:

    # narrator "{color=#3325f7}Hahaha."
    narrator "{color=#3325f7}Jajaja."

# game/dia2.rpy:242
translate Spanish nomedenovo_e8689e59:

    # narrator "{color=#3325f7}Very well, good luck, dear guest."
    narrator "{color=#3325f7}Muy bien, buena suerte, querid[letra] invitad[letra]."

# game/dia2.rpy:248
translate Spanish nomedenovo_db8e948d:

    # narrator "{color=#3325f7}Hmmm..."
    narrator "{color=#3325f7}Hmmm..."

# game/dia2.rpy:256
translate Spanish nomedenovo_575e4489:

    # narrator "{color=#3325f7}And about Pierrot, did you let him visit you the other day?"
    narrator "{color=#3325f7}Y sobre Pierrot, ¿dejaste que te visitara el otro día?"

# game/dia2.rpy:263
translate Spanish nomedenovo_0711f534:

    # narrator "{color=#3325f7}How kind, so now..."
    narrator "{color=#3325f7}Qué amable, así que ahora..."

# game/dia2.rpy:266
translate Spanish nomedenovo_cc72820b:

    # narrator "{color=#3325f7}It’s time to wake."
    narrator "{color=#3325f7}Es hora de despertar."

# game/dia2.rpy:281
translate Spanish nomedenovo_2dae02c8:

    # narrator "{color=#3325f7}No?"
    narrator "{color=#3325f7}¿No?"

# game/dia2.rpy:287
translate Spanish nomedenovo_244f4a89:

    # narrator "{color=#3325f7}Why not?{nw=0.2}"
    narrator "{color=#3325f7}¿Por qué no?{nw=0.2}"

# game/dia2.rpy:291
translate Spanish nomedenovo_503320c5:

    # narrator "{color=#3325f7}I mean, your time is up, time to wake."
    narrator "{color=#3325f7}Quiero decir, se acabó el tiempo, es hora de despertar."

# game/dia2.rpy:310
translate Spanish sequestro_959d7993:

    # mc "Ugh... my head... Where the hell am I?"
    mc "Uf... mi cabeza... ¿Dónde diablos estoy?"

# game/dia2.rpy:322
translate Spanish sequestro_d1425dd0:

    # p "{i}It feels so {b}unbelievably{/b} good to hold you like this."
    p "{i}Se siente tan {b}increíblemente{/b} bien abrazarte así."

# game/dia2.rpy:323
translate Spanish sequestro_ab42c3e8:

    # p "{sc=3}{color=#ffaf54}Finally mine."
    p "{sc=3}{color=#ffaf54}Por fin eres mí[letra]."

# game/dia2.rpy:338
translate Spanish sequestro_cab94879:

    # p "{sc=1}{color=#ffaf54}{b}And to leave me here,{w=0.1} on the edge of losing control."
    p "{sc=1}{color=#ffaf54}{b}Y dejarme aquí,{w=0.1} al borde de perder el control."

# game/dia2.rpy:339
translate Spanish sequestro_fe7b02e4:

    # p "{sc=2}{color=#ffaf54}{b}My hands ache to explore every inch of you."
    p "{sc=2}{color=#ffaf54}{b}Mis manos se mueren por explorar cada centímetro de ti."

# game/dia2.rpy:352
translate Spanish sequestro_7cccbf2f:

    # p "{sc=2}{color=#ffaf54}{b}Even though I’m completely obsessed with you right now."
    p "{sc=2}{color=#ffaf54}{b}Aunque estoy completamente obsesionado contigo en este momento."

# game/dia2.rpy:353
translate Spanish sequestro_e0a152af:

    # p "{b}...I want your eyes on mine."
    p "{b}...Quiero tus ojos en los míos."

# game/dia2.rpy:364
translate Spanish sequestro_e02acca5:

    # p "I almost... almost lost you [titulo_pierrot]."
    p "Casi... casi te pierdo, [titulo_pierrot!t]."

# game/dia2.rpy:365
translate Spanish sequestro_55c53e21:

    # p "You just needed... to stop fighting me."
    p "Sólo necesitabas... dejar de pelear conmigo."

# game/dia2.rpy:382
translate Spanish sequestro_cee985f8:

    # p "I’ll take good care of you, I promise."
    p "Te cuidaré bien, lo prometo."

# game/dia2.rpy:383
translate Spanish sequestro_4be1ee42:

    # p "{sc=1}{color=#ffaf54}Even if you try to run again..."
    p "{sc=1}{color=#ffaf54}Incluso si intentas huir de nuevo..."

# game/dia2.rpy:396
translate Spanish sequestro_659ddbb3:

    # p "{sc=1}{color=#ffaf54}My sweet angel..."
    p "{sc=1}{color=#ffaf54}Mi dulce ángel..."

# game/dia2.rpy:403
translate Spanish sequestro_1332bfdb:

    # mc "He... did this? This is really happening? I need to--"
    mc "¿Él... hizo esto? ¿De verdad está pasando? Tengo que..."

# game/dia2.rpy:409
translate Spanish sequestro_6331ed14:

    # narrator "You feel something wrapped around your ankle, it's chained to the bed."
    narrator "Sientes algo alrededor de tu tobillo. Está encadenado a la cama."

# game/dia2.rpy:411
translate Spanish sequestro_fb7c43cc:

    # mc "No, no, no…"
    mc "No, no, no..."

# game/dia2.rpy:415
translate Spanish sequestro_42b594ed:

    # mc "(I can't get it off!!)" with hpunch
    mc "(¡¡No puedo quitármelo!!)" with hpunch

# game/dia2.rpy:447
translate Spanish sequestro_fc7fa4b4:

    # narrator "Your voice fades when your eyes meet his."
    narrator "Tu voz se desvanece cuando tus ojos se encuentran con los suyos."

# game/dia2.rpy:449
translate Spanish sequestro_ba268e0b:

    # narrator "He slowly sets a tray of food near the bed so slowly it feels like he’s afraid even the slightest movement might scare you more."
    narrator "Lentamente coloca una bandeja con comida cerca de la cama, tan lentamente que parece que teme que incluso el más mínimo movimiento pueda asustarte más."

# game/dia2.rpy:462
translate Spanish sequestro_c53ed802:

    # p "You’re finally awake, [titulo_pierrot]!"
    p "¡Por fin despertaste, [titulo_pierrot!t]!"

# game/dia2.rpy:463
translate Spanish sequestro_8fdf0d0f:

    # p "I’ve missed seeing the color of your eyes, and hearing your voice speaking to me."
    p "Extrañé ver el color de tus ojos y escuchar tu voz hablándome."

# game/dia2.rpy:468
translate Spanish sequestro_d4ea382b:

    # narrator "Your body pulls back on instinct, and you press against the headboard. He raises his hands gently, trying to calm you."
    narrator "Tu cuerpo retrocede por instinto y te presionas contra la cabecera. Levanta las manos suavemente, intentando calmarte."

# game/dia2.rpy:470
translate Spanish sequestro_30a60faf:

    # p "Ah, of course… you must be afraid right now..."
    p "Ah, por supuesto... debes tener miedo ahora mismo..."

# game/dia2.rpy:471
translate Spanish sequestro_d8f8320e:

    # p "It’s alright, [titulo_pierrot]. I won’t hurt you."
    p "Está bien, [titulo_pierrot!t]. No te haré daño."

# game/dia2.rpy:473
translate Spanish sequestro_94585b31:

    # mc "You… you drugged me!"
    mc "¡Tú… me drogaste!"

# game/dia2.rpy:475
translate Spanish sequestro_af939b19:

    # p "[mc_nome]..."
    p "[mc_nome]..."

# game/dia2.rpy:477
translate Spanish sequestro_c2c43066:

    # mc "And then you kidnapped me!!"
    mc "¡¡Y luego me secuestraste!!"

# game/dia2.rpy:496
translate Spanish sequestro_264ac496:

    # p "I!... I..."
    p "¡Yo!... yo..."

# game/dia2.rpy:504
translate Spanish sequestro_329e0c56:

    # p "No..."
    p "No..."

# game/dia2.rpy:507
translate Spanish sequestro_d1973ac5:

    # p "I didn’t know there would be something in the food that day..."
    p "No sabía que habría algo en la comida ese día..."

# game/dia2.rpy:510
translate Spanish sequestro_17df441d:

    # p "I had no choice... you were going to leave me. I needed to calm you down, so we could talk."
    p "No tenía elección... me ibas a dejar. Necesitaba calmarte para que pudiéramos hablar."

# game/dia2.rpy:512
translate Spanish sequestro_ae00d814:

    # p "Please, [titulo_pierrot], don’t scream, alright?"
    p "Por favor, [titulo_pierrot!t], no grites, ¿de acuerdo?"

# game/dia2.rpy:519
translate Spanish sequestro_0a18db07:

    # p "{cps=20}The others… {w=0.2}{/cps}they’re nearby. Just… listen to me."
    p "{cps=20}Los demás… {w=0.2}{/cps}están cerca. Sólo... escúchame."

# game/dia2.rpy:520
translate Spanish sequestro_7372f69a:

    # p "I saw you vulnerable, [titulo_pierrot], and it made..."
    p "Te vi vulnerable, [titulo_pierrot!t], y eso hizo que..."

# game/dia2.rpy:534
translate Spanish sequestro_f38d9c97:

    # p "... {cps=12}My body tremble in {bt=1}{color=#ffaf54}so many ways-{nw=1}"
    p "... {cps=12}mi cuerpo temblara de {bt=1}{color=#ffaf54}tantas maneras-{nw=1}"

# game/dia2.rpy:547
translate Spanish sequestro_b2c54aff:

    # p "I-I mean..."
    p "Q-quiero decir..."

# game/dia2.rpy:552
translate Spanish sequestro_616c40f0:

    # p "You felt it too, didn’t you? After you ate, your body became…"
    p "Tú también lo sentiste, ¿no? Después de comer, tu cuerpo se volvió..."

# game/dia2.rpy:553
translate Spanish sequestro_a09ada7a:

    # p "{cps=20}Receptive,{w=0.2} light and yielding."
    p "{cps=20}Receptivo, ligero y dócil."

# game/dia2.rpy:558
translate Spanish sequestro_8d2ada5b:

    # p "But then I saw how the world looked at you in that moment."
    p "Pero luego vi cómo te miraba el mundo en ese momento."

# game/dia2.rpy:559
translate Spanish sequestro_3b9d171b:

    # p "Like prey. I saw those hungry eyes trying to devour you, yearning to touch you."
    p "Como presa. Vi esos ojos hambrientos tratando de devorarte, anhelando tocarte."

# game/dia2.rpy:562
translate Spanish sequestro_491c5e2d:

    # p "{cps=10}It drove me mad."
    p "{cps=10}Me volvió loco."

# game/dia2.rpy:563
translate Spanish sequestro_3c963184:

    # p "{b}I had to bring you somewhere safe, somewhere under my watch."
    p "{b}Tenía que llevarte a un lugar seguro, a algún lugar bajo mi vigilancia."

# game/dia2.rpy:565
translate Spanish sequestro_0ffb0513:

    # narrator "He reaches out to touch you."
    narrator "Él se acerca para tocarte."

# game/dia2.rpy:579
translate Spanish sequestro_eb02fcc9:

    # p "I had to hide you, before anyone tried to lay a hand on [titulo_pierrot]."
    p "Tenía que esconderte, antes de que alguien intentara ponerte una mano encima, [titulo_pierrot!t]."

# game/dia2.rpy:580
translate Spanish sequestro_39a3f100:

    # p "Because if someone dared touch you, someone other than me…"
    p "Porque si alguien se atreviera a tocarte, alguien que no fuera yo…"

# game/dia2.rpy:596
translate Spanish sequestro_4fd37c41:

    # p "I don’t know what I might’ve done."
    p "No sé qué habría hecho."

# game/dia2.rpy:598
translate Spanish sequestro_7f276976:

    # mc "{color=#a0b0c0}(He’s terrifying. He says such sweet things, with this dark... hungry tone?)"
    mc "{color=#a0b0c0}(Es aterrador. Dice cosas tan dulces, con ese tono oscuro... ¿hambriento?)"

# game/dia2.rpy:607
translate Spanish sequestro_19a530f9:

    # p "I’m so glad you woke up, [mc_nome]! I was starting to get worried."
    p "¡Me alegro mucho de que hayas despertado, [mc_nome]! Estaba empezando a preocuparme."

# game/dia2.rpy:608
translate Spanish sequestro_f5b8fb9c:

    # mc "Worried? But I’m the one who…"
    mc "¿Preocupado? Pero soy yo quien..."

# game/dia2.rpy:609
translate Spanish sequestro_8f71e361:

    # p "You were breathing so slowly, so still… it was like…"
    p "Respirabas tan lentamente, estabas tan inmóvil… era como si..."

# game/dia2.rpy:620
translate Spanish sequestro_a83d7f33:

    # p "…like you were going to disappear forever, like..."
    p "…como si fueras a desaparecer para siempre, como…"

# game/dia2.rpy:621
translate Spanish sequestro_c1d7bf58:

    # p "{sc=1}{color=#ffaf54}N-no, I’d never hurt you like that! Believe me, back then I- {nw=3}"
    p "{sc=1}{color=#ffaf54}N-no, ¡nunca te lastimaría así! Créeme, en aquel entonces yo- {nw=3}"

# game/dia2.rpy:632
translate Spanish sequestro_6d8f4aee:

    # des "{color=#961ee6}Where’s Pierrot??"
    des "{color=#961ee6}¿Dónde está Pierrot?"

# game/dia2.rpy:639
translate Spanish sequestro_d89b29f7:

    # p "Please, [titulo_pierrot] listen to me. Place your trust in me."
    p "Por favor, [titulo_pierrot!t], escúchame. Confía en mí."

# game/dia2.rpy:643
translate Spanish sequestro_b874c6fd:

    # narrator "He places a mask gently over your face and leans in, resting his forehead against it."
    narrator "Coloca una máscara suavemente sobre tu cara y se inclina, apoyando su frente contra ella."

# game/dia2.rpy:646
translate Spanish sequestro_a8fdec0b:

    # p "I give you my word I shall return. If you wish for me to let go, I shall."
    p "Te doy mi palabra de que volveré. Si deseas que te deje ir, lo haré."

# game/dia2.rpy:647
translate Spanish sequestro_817e63b5:

    # p "But please, wait just a moment. And should anyone enter, say nothing."
    p "Pero por favor, espera un momento. Y si alguien entra, no digas nada."

# game/dia2.rpy:648
translate Spanish sequestro_f5fe43ae:

    # p "Do not breathe too heavily. Pretend you are merely a doll. You will be safe, yes?"
    p "No respires tan fuerte. Finge que eres simplemente una muñeca. Estarás a salvo, ¿verdad?"

# game/dia2.rpy:649
translate Spanish sequestro_22eb1267:

    # p "{cps=15}{b}Do not move."
    p "{cps=15}{b}No te muevas."

# game/dia2.rpy:651
translate Spanish sequestro_f61b9d0c:

    # narrator "He binds your hands with a rope, but it’s far too loose."
    narrator "Te ata las manos con una cuerda, pero está demasiado floja."

# game/dia2.rpy:655
translate Spanish sequestro_8576d528:

    # mc "{color=#a0b0c0}(He faked tying me up? What was that all about? Maybe I should-)"
    mc "{color=#a0b0c0}(¿Fingió atarme? ¿De qué se trató todo eso? Tal vez debería-)"

# game/dia2.rpy:660
translate Spanish sequestro_d0e06652:

    # narrator "As you try to move your leg, the weight of the chain pulls back."
    narrator "Al intentar mover la pierna, el peso de la cadena tira hacia atrás."

# game/dia2.rpy:662
translate Spanish sequestro_cc76af39:

    # mcp "(Oh, right. I can’t get out of bed. I just have to…{w=0.3} wait.)"
    mcp "(Oh, claro. No puedo levantarme de la cama. Sólo tengo que…{w=0.3} esperar.)"

# game/dia2.rpy:665
translate Spanish sequestro_60852811:

    # narrator "You hear footsteps coming closer."
    narrator "Oyes pasos acercándose."

# game/dia2.rpy:667
translate Spanish sequestro_71c94883:

    # mcp "(Is he back already? Should I stay quiet like he asked?)"
    mcp "(¿Ya ha vuelto? ¿Debería quedarme callad[letra] como me pidió?)"

# game/dia2.rpy:674
translate Spanish sequestro_1a4d0360:

    # a "Hmm?"
    a "Mmmm?"

# game/dia2.rpy:677
translate Spanish sequestro_6a548453:

    # a "Well, well… what do we have here?"
    a "Bueno, bueno… ¿qué tenemos aquí?"

# game/dia2.rpy:679
translate Spanish sequestro_6430d006:

    # mcp "(That’s not him…)"
    mcp "(Ese no es él…)"

# game/dia2.rpy:681
translate Spanish sequestro_c0fd3d95:

    # a "I knew he was hiding something… but this is way more fun than I thought!"
    a "Sabía que estaba ocultando algo... ¡pero esto es mucho más divertido de lo que pensaba!"

# game/dia2.rpy:686
translate Spanish sequestro_973ec142:

    # a "I must be really lucky today!"
    a "¡Debo tener mucha suerte hoy!"

# game/dia2.rpy:687
translate Spanish sequestro_1c79edbb:

    # a "{cps=15}Tied up to a bed, in a place you were {b}never{/b} supposed to be ♪"
    a "{cps=15}Atad[letra] a una cama, en un lugar donde {b}nunca{/b} se suponía que debías estar ♪"

# game/dia2.rpy:691
translate Spanish sequestro_e67e0103:

    # narrator "He climbs onto the bed and slowly makes his way toward you."
    narrator "Se sube a la cama y lentamente se dirige hacia ti."

# game/dia2.rpy:693
translate Spanish sequestro_5bc8702d:

    # a "He warned you, didn’t he?"
    a "Él te lo advirtió, ¿no?"

# game/dia2.rpy:701
translate Spanish sequestro_957731a6:

    # a "Here,{w=0.3} if you scream, things will get {b}really{/b} bad for you."
    a "Escucha,{w=0.3} si gritas, las cosas se pondrán {b}muy mal{/b} para ti."

# game/dia2.rpy:703
translate Spanish sequestro_bcf06bb4:

    # mcp "(His mask... it just opened?? And his tongue... {cps=10}it's green?)"
    mcp "(¿Su máscara... se acaba de abrir? Y su lengua... {cps=10}¿es verde?)"

# game/dia2.rpy:705
translate Spanish sequestro_15566ee0:

    # a "Guess it still tastes sweet ♪"
    a "Supongo que sigue teniendo un sabor dulce ♪"

# game/dia2.rpy:709
translate Spanish sequestro_e4d45114:

    # a "Hm? You're already shaking?"
    a "¿Mmm? ¿Ya estás temblando?"

# game/dia2.rpy:714
translate Spanish sequestro_2f71243a:

    # a "Oh,{w=0.3} you hadn’t seen that yet, huh?"
    a "Oh,{w=0.3} todavía no habías visto eso, ¿eh?"

# game/dia2.rpy:715
translate Spanish sequestro_73aa6fb6:

    # a "Wanna see more? {i}I could show you later."
    a "¿Quieres ver más? {i}Podría mostrártelo más tarde."

# game/dia2.rpy:716
translate Spanish sequestro_407f0e4f:

    # a "Now the real question is…"
    a "Ahora la verdadera pregunta es..."

# game/dia2.rpy:720
translate Spanish sequestro_532a6968:

    # a "{b}What should I do with you?"
    a "{b}¿Qué debo hacer contigo?"

# game/dia2.rpy:721
translate Spanish sequestro_a9f4a6b4:

    # a "Ugh, it’s so hard to choose."
    a "Uf, es muy difícil elegir."

# game/dia2.rpy:735
translate Spanish sequestro_64f09517:

    # a "You really are stubborn, aren’t you?"
    a "Realmente eres terc[letra], ¿no?"

# game/dia2.rpy:736
translate Spanish sequestro_481a6182:

    # a "If anyone’s going to break you, [titulo_arlequim], it better be {b}me{/b} and not them."
    a "Si alguien va a quebrarte, [titulo_arlequim!t], más vale que sea {b}yo{/b} y no ellos."

# game/dia2.rpy:737
translate Spanish sequestro_dea12df6:

    # a "So you’d better not scream, got it?"
    a "Así que será mejor que no grites, ¿entendido?"

# game/dia2.rpy:739
translate Spanish sequestro_ae32d714:

    # a "I wouldn’t mind hearing it, but I don’t like sharing."
    a "No me importaría oírte gritar, pero no me gusta compartir."

# game/dia2.rpy:747
translate Spanish sequestro_a3da4530:

    # a "Oh? Are you pretending to be a doll?"
    a "¿Oh? ¿Estás fingiendo ser una muñeca?"

# game/dia2.rpy:748
translate Spanish sequestro_dcd33924:

    # a "How much did he tell you? Now I’m curious."
    a "¿Cuánto te dijo? Ahora tengo curiosidad."

# game/dia2.rpy:755
translate Spanish sequestro_f570db8b:

    # a "But you’re not fooling me, your body’s way too tense, your arms are trembling."
    a "Pero no me estás engañando, tu cuerpo está demasiado tenso, tus brazos tiemblan."

# game/dia2.rpy:762
translate Spanish sequestro_d0226d6f:

    # narrator "He pushes your body down against the mattress."
    narrator "Empuja tu cuerpo contra el colchón."

# game/dia2.rpy:765
translate Spanish sequestro_dc728f89:

    # narrator "And sinks his teeth into your neck. You tense up, but stay silent."
    narrator "Y te hunde los dientes en el cuello. Te tensas, pero permaneces en silencio."

# game/dia2.rpy:768
translate Spanish sequestro_fc92c691:

    # a "{i}I know you’re in there ♪"
    a "{i}Sé que estás ahí ♪"

# game/dia2.rpy:770
translate Spanish sequestro_30707dc4:

    # narrator "You feel something warm and wet glide over the spot where he bit you."
    narrator "Sientes que algo cálido y húmedo se desliza sobre el lugar donde te mordió."

# game/dia2.rpy:772
translate Spanish sequestro_7dbbebf3:

    # a "Well, well, such resistance."
    a "Bueno, bueno, qué resistencia."

# game/dia2.rpy:773
translate Spanish sequestro_9b6cba56:

    # a "I’m impressed."
    a "Estoy impresionado."

# game/dia2.rpy:781
translate Spanish sequestro_3c4dc716:

    # narrator "He slides the knife along your skin, you feel the cold blade touch your neck and trail down your chest, but he doesn’t cut you."
    narrator "Desliza el cuchillo a lo largo de tu piel, sientes la hoja fría tocar tu cuello y bajar por tu pecho, pero no te corta."

# game/dia2.rpy:788
translate Spanish sequestro_0999d9f7:

    # a "You’re doing so well, didn’t even flinch."
    a "Lo estás haciendo tan bien que ni siquiera te inmutaste."

# game/dia2.rpy:789
translate Spanish sequestro_392e2f12:

    # a "But your skin tells on you, all those little goosebumps. Was it the blade’s cold kiss?"
    a "Pero tu piel te delata, toda esa piel de gallina. ¿Fue el beso frío de la hoja?"

# game/dia2.rpy:790
translate Spanish sequestro_c70422f5:

    # a "Or was it knowing you’re completely at my mercy?"
    a "¿O fue saber que estás completamente a mi merced?"

# game/dia2.rpy:803
translate Spanish sequestro_56afa2fb:

    # a "No escape...{w=0.3} {cps=15}{i}and no eyes of your loyal guard dog watching over you."
    a "No hay escapatoria...{w=0.3}{cps=15}{i}y no hay ojos de tu leal perro guardián vigilándote."

# game/dia2.rpy:804
translate Spanish sequestro_9a552265:

    # a "Still quiet? Oh, this game is really turning me on..."
    a "¿Sigues callad[letra]? Oh, este juego realmente me está excitando..."

# game/dia2.rpy:806
translate Spanish sequestro_4b9e23f6:

    # narrator "You're still trying to process what just happened, your body trembling with hesitation."
    narrator "Todavía estás tratando de procesar lo que acaba de suceder, tu cuerpo tiembla de vacilación."

# game/dia2.rpy:814
translate Spanish sequestro_29d5a70f:

    # mc "{sc=1}Please... go away Harlequin."
    mc "{sc=1}Por favor... vete, Arlequín."

# game/dia2.rpy:815
translate Spanish sequestro_af0b5da3:

    # narrator "You whisper so softly that the mask nearly muffles your voice entirely."
    narrator "Susurras tan suavemente que la máscara casi amortigua tu voz por completo."

# game/dia2.rpy:819
translate Spanish sequestro_6a245768:

    # a "{cps=10}\"Please\"?"
    a "{cps=10}¿\"Por favor\"?"

# game/dia2.rpy:820
translate Spanish sequestro_c1b1f456:

    # a "You sound so sweet when you beg like that."
    a "Suenas tan dulce cuando suplicas así."

# game/dia2.rpy:827
translate Spanish sequestro_2e8e1376:

    # narrator "He leans in and whispers."
    narrator "Se inclina y susurra."

# game/dia2.rpy:829
translate Spanish sequestro_58c50194:

    # a "But let me remind you. {cps=15}{b}I wasn’t the one who tied you up."
    a "Pero déjame recordarte algo. {cps=15}{b}No fui yo quien te ató."

# game/dia2.rpy:830
translate Spanish sequestro_43b659c2:

    # a "{cps=30}I’m just here because {b}someone else{/b} left you all alone… with the {i}wrong predator."
    a "{cps=30}Solo estoy aquí porque {b}otra persona{/b} te dejó a solas… con el {i}depredador equivocado."

# game/dia2.rpy:839
translate Spanish sequestro_51b7f29c:

    # narrator "You reach for his hand, trembling, a quiet plea for him to stop."
    narrator "Buscas su mano, temblando, en una súplica silenciosa para que se detenga."

# game/dia2.rpy:841
translate Spanish sequestro_8288d609:

    # a "{cps=10}{size=50}..."
    a "{cps=10}{size=50}..."

# game/dia2.rpy:855
translate Spanish sequestro_0b452e58:

    # a "Oh?{w=0.2} You're trembling so much this time, my dear."
    a "¿Oh?{w=0.2} Estás temblando mucho esta vez, querid[letra]."

# game/dia2.rpy:861
translate Spanish sequestro_622e7927:

    # a "Are you asking me to stop, or just to {i}slow down?"
    a "¿Me estás pidiendo que me detenga o simplemente que {i}vaya más despacio?"

# game/dia2.rpy:863
translate Spanish sequestro_1fc3fe2b:

    # narrator "You lower your head, and notice{cps=15} he's holding back a laugh."
    narrator "Bajas la cabeza y notas que{cps=15} está conteniendo una risa."

# game/dia2.rpy:872
translate Spanish sequestro_56803009:

    # a "Alright, I’ll let you catch your breath, {b}just this once."
    a "Muy bien, te dejaré recuperar el aliento, {b}sólo por esta vez."

# game/dia2.rpy:873
translate Spanish sequestro_23b5dd2b:

    # a "I know when your eyes are begging for me."
    a "Sé cuándo tus ojos me suplican."

# game/dia2.rpy:880
translate Spanish sequestro_7b1ac640:

    # a "But next time, you won’t get a break."
    a "Pero la próxima vez no tendrás descanso."

# game/dia2.rpy:888
translate Spanish sequestro_18426482:

    # narrator "He comes closer, and you hold onto his hand hesitantly."
    narrator "Él se acerca y tú tomas su mano con vacilación."

# game/dia2.rpy:891
translate Spanish sequestro_45585dfd:

    # narrator "His poisonous stare burns into you, while his smile grows with twisted delight."
    narrator "Su mirada venenosa te quema, mientras su sonrisa crece con retorcido deleite."

# game/dia2.rpy:893
translate Spanish sequestro_f4cac8e6:

    # a "Shhh."
    a "Shhh."

# game/dia2.rpy:894
translate Spanish sequestro_d072e52c:

    # a "Don’t move."
    a "No te muevas."

# game/dia2.rpy:897
translate Spanish sequestro_9f45981e:

    # narrator "He gently places his hand over yours."
    narrator "Él coloca suavemente su mano sobre la tuya."

# game/dia2.rpy:899
translate Spanish sequestro_5187607c:

    # mcp "(Is he… trying to comfort me?)"
    mcp "(¿Está… tratando de consolarme?)"

# game/dia2.rpy:901
translate Spanish sequestro_42422403:

    # a "I have to admit. I’m really starting to like the way you look at me."
    a "Tengo que admitirlo. Realmente me está empezando a gustar la forma en que me miras."

# game/dia2.rpy:903
translate Spanish sequestro_fc997df7:

    # mcp "(Maybe not...)"
    mcp "(Quizás no...)"

# game/dia2.rpy:911
translate Spanish sequestro_232954e5:

    # mcp "(He... let me go? Why?)"
    mcp "(Él… ¿me dejó ir? ¿Por qué?)"

# game/dia2.rpy:913
translate Spanish sequestro_b11f7f87:

    # a "Why? Is that what you’re thinking? Because this way’s more fun."
    a "¿Por qué? ¿Es eso lo que estás pensando? Porque así es más divertido."

# game/dia2.rpy:914
translate Spanish sequestro_1469e74d:

    # a "I don’t like prey all tied up. I like the hunt. And the best part-"
    a "No me gustan las presas atadas. Me gusta la caza. Y la mejor parte-"

# game/dia2.rpy:917
translate Spanish sequestro_7fa7dd35:

    # a "Is gonna be the look on his face when he finds out."
    a "Esa será la expresión de su cara cuando se entere."

# game/dia2.rpy:925
translate Spanish sequestro_2591d589:

    # a "Run kitten." with hpunch
    a "Corre, gatit[letra]." with hpunch

# game/dia2.rpy:935
translate Spanish fuga_d9b791bf:

    # mcp "(This isn’t just an act, something’s seriously wrong with those two!)"
    mcp "(Esto no es sólo un acto, ¡algo anda muy mal con esos dos!)"

# game/dia2.rpy:958
translate Spanish fuga_94a09ac5:

    # mc "Ouch!"
    mc "¡Ay!"

# game/dia2.rpy:966
translate Spanish carol_c74a0282:

    # mc "Sorry, I... I don’t..."
    mc "Lo siento, yo... yo no..."

# game/dia2.rpy:994
translate Spanish carol_b1b6db9c:

    # des "{color=#90c2da}Don’t miss the attractions, you’re gonna love it, visitor."
    des "{color=#90c2da}No te pierdas las atracciones, te encantará, visitante."

# game/dia2.rpy:998
translate Spanish carol_282e5851:

    # mc "What...?"
    mc "¿Qué...?"

# game/dia2.rpy:999
translate Spanish carol_8ee59c63:

    # mc "C-Carol?"
    mc "¿Carol?"

# game/dia2.rpy:1001
translate Spanish carol_ec308498:

    # ca "Don’t miss the--{nw=0.5}"
    ca "No te pierdas el--{nw=0.5}"

# game/dia2.rpy:1006
translate Spanish carol_72ace766:

    # b "Oh! How embarrassing, darling your mask just slipped off."
    b "¡Ah! Qué vergonzoso, cariño, se te acaba de caer la máscara."

# game/dia2.rpy:1019
translate Spanish carol_fd91940c:

    # b "Don't worry about her, visitor. She's just playing her part."
    b "No te preocupes por ella, visitante. Ella sólo está desempeñando su papel."

# game/dia2.rpy:1020
translate Spanish carol_3687ab75:

    # b "Around here, no one ever breaks character. Not for anything."
    b "Por aquí nadie se sale de su personaje. Por nada del mundo."

# game/dia2.rpy:1021
translate Spanish carol_8e5b293b:

    # b "But, you look kinda shaken."
    b "Pero te ves un poco conmocionad[letra]."

# game/dia2.rpy:1022
translate Spanish carol_6b5a14e3:

    # b "Are you enjoying the promotional attractions? Or did something happen?"
    b "¿Estás disfrutando de las atracciones promocionales? ¿O pasó algo?"

# game/dia2.rpy:1024
translate Spanish carol_ac17e9f4:

    # mc "I-I… I…"
    mc "Y-yo... yo..."

# game/dia2.rpy:1032
translate Spanish carol_86be9fde:

    # narrator "He shifts his posture after locking eyes with you for a moment."
    narrator "Cambia su postura después de mirarte a los ojos por un momento."

# game/dia2.rpy:1034
translate Spanish carol_fbbfcfec:

    # b "Are you lost, visitor? This area’s really close to the restricted zone."
    b "¿Estás perdid[letra], visitante? Esta área está muy cerca de la zona restringida."

# game/dia2.rpy:1035
translate Spanish carol_5943c296:

    # b "Which way did you come from?"
    b "¿Por dónde viniste?"

# game/dia2.rpy:1054
translate Spanish carol_8302da2e:

    # narrator "Your voice falters, and he doesn't buy it."
    narrator "Tu voz falla y él no se lo cree."

# game/dia2.rpy:1056
translate Spanish carol_c5a36c2d:

    # b "That's...{w=0.5}{cps=15} alright, visitor. These things happen."
    b "Está...{w=0.5}{cps=15} bien, visitante. Estas cosas pasan."

# game/dia2.rpy:1061
translate Spanish carol_7f028b7e:

    # b "Please, come with me let me guide you to the exit."
    b "Por favor, ven conmigo déjame guiarte hasta la salida."

# game/dia2.rpy:1063
translate Spanish carol_bbc1367f:

    # mcp "(I'm pretty sure the exit isn’t that way...)"
    mcp "(Estoy bastante segur[letra] de que la salida no es por ahí...)"

# game/dia2.rpy:1065
translate Spanish carol_a45e44fb:

    # mc "N-no, it’s okay! The exit’s this way, right? I can go on my own."
    mc "N-no, ¡está bien! La salida es por aquí, ¿no? Puedo ir sol[letra]."

# game/dia2.rpy:1071
translate Spanish carol_319c1c2d:

    # narrator "He grabs your wrist firmly." with hpunch
    narrator "Te agarra la muñeca con firmeza." with hpunch

# game/dia2.rpy:1073
translate Spanish carol_d875ee16:

    # b "{b}I insist."
    b "{b}Insisto."

# game/dia2.rpy:1079
translate Spanish carol_1cc8ee27:

    # mcp "(Pierrot??)"
    mcp "(¿¿Pierrot??)"

# game/dia2.rpy:1081
translate Spanish carol_a18ace43:

    # b "Pierrot? What are you..."
    b "¿Pierrot? ¿Qué haces...?"

# game/dia2.rpy:1094
translate Spanish carol_6ccccc92:

    # b "Are [persistent.p_sujeito] with you?"
    b "¿[persistent.p_sujeito!t] está contigo?"

# game/dia2.rpy:1096
translate Spanish carol_c97f027c:

    # b "Is [persistent.p_sujeito] with you?"
    b "¿[persistent.p_sujeito!t] está contigo?"

# game/dia2.rpy:1107
translate Spanish carol_60ce843a:

    # mcp "(I-Is that… blood?)"
    mcp "(¿E-eso es… sangre?)"

# game/dia2.rpy:1110
translate Spanish carol_60ce843a_1:

    # mcp "(I-Is that… blood?)"
    mcp "(¿E-eso es… sangre?)"

# game/dia2.rpy:1113
translate Spanish carol_78581e53:

    # b "That look, Pierrot… they're scared."
    b "Esa mirada, Pierrot… tiene miedo."

# game/dia2.rpy:1115
translate Spanish carol_4006a296:

    # b "That look, Pierrot… [persistent.p_sujeito]'s scared."
    b "Esa mirada, Pierrot… [persistent.p_sujeito!t] tiene miedo."

# game/dia2.rpy:1117
translate Spanish carol_48c63261:

    # b "It's like [persistent.p_sujeito] saw the part of the circus {b}we don’t show."
    b "Es como si [persistent.p_sujeito!t] hubiera visto la parte del circo que {b}no mostramos."

# game/dia2.rpy:1126
translate Spanish carol_39864245:

    # p "{sc=1}{color=#ffaf54}{size=20}Circus of horrors. Of course they're scared."
    p "{sc=1}{color=#ffaf54}{size=20}Circo de los horrores. Por supuesto que tiene miedo."

# game/dia2.rpy:1128
translate Spanish carol_eeb4e4ce:

    # p "{sc=1}{color=#ffaf54}{size=20}Circus of horrors. Of course [persistent.p_sujeito]’s scared."
    p "{sc=1}{color=#ffaf54}{size=20}Circo de los horrores. Por supuesto que [persistent.p_sujeito!t] tiene miedo."

# game/dia2.rpy:1133
translate Spanish carol_5e1d86b2:

    # voice "audio/dublagem/bilheteiro.mp3"
    # b "{b}Do not speak."
    voice "audio/dublagem/bilheteiro.mp3"
    b "{b}No hables."

# game/dia2.rpy:1136
translate Spanish carol_7cda4ce7:

    # b "In that case..."
    b "En ese caso..."

# game/dia2.rpy:1161
translate Spanish carol_1b692084:

    # b "I'm certain our guest will be thrilled to return for the nightly attractions, won’t [persistent.p_sujeito]?"
    b "Estoy seguro de que nuestr[letra] invitad[letra] estará encantad[letra] de volver para las atracciones nocturnas, ¿verdad?"

# game/dia2.rpy:1162
translate Spanish carol_3f107ee3:

    # b "Give [persistent.p_objeto] your ticket, Pierrot. Or I’ll have to offer mine."
    b "Dale tu boleto, Pierrot. O tendré que ofrecerle el mío."

# game/dia2.rpy:1163
translate Spanish carol_f3409b12:

    # b "If everything’s fine, [persistent.p_sujeito]’ll be delighted to join us again, right, guest?"
    b "Si todo está bien, [persistent.p_sujeito!t] estará encantad[letra] de unirse a nosotros otra vez, ¿verdad, invitad[letra]?"

# game/dia2.rpy:1165
translate Spanish carol_e8d2e388:

    # narrator "Pierrot stares at you and subtly nods."
    narrator "Pierrot te mira fijamente y asiente sutilmente."

# game/dia2.rpy:1167
translate Spanish carol_3899c5f1:

    # mcp "(Maybe… it’s better to play along. I don’t know what’s going on here, but if I leave, I won’t have to come back.)"
    mcp "(Tal vez... es mejor seguir el juego. No sé qué está pasando aquí, pero si me voy, no tendré que volver)."

# game/dia2.rpy:1169
translate Spanish carol_99321040:

    # mc "Sure! I’d... love to."
    mc "¡Claro! Me encantaría."

# game/dia2.rpy:1174
translate Spanish carol_275651f2:

    # b "Perfect. We look forward to your return, guest."
    b "Perfecto. Esperamos tu regreso, invitad[letra]."

# game/dia2.rpy:1188
translate Spanish carol_2b35b6fe:

    # mc "..."
    mc "..."

# game/dia2.rpy:1198
translate Spanish carol_734813fb:

    # narrator "He tries to touch your shoulder but holds back, afraid you’ll run."
    narrator "Intenta tocarte el hombro, pero se detiene por miedo a que salgas corriendo."

# game/dia2.rpy:1199
translate Spanish carol_e202d3ee:

    # mcp "(I don’t know what happened back there, but he seems okay)"
    mcp "(No sé qué pasó allí, pero parece estar bien)"

# game/dia2.rpy:1200
translate Spanish carol_7362c833:

    # mc "Harlequin is… {nw=0.5}"
    mc "Arlequín está… {nw=0.5}"

# game/dia2.rpy:1201
translate Spanish carol_208b8e19:

    # p "{size=20}Breathing."
    p "{size=20}Respirando."

# game/dia2.rpy:1203
translate Spanish carol_997f7ba1:

    # mc "I… just need to go home for a bit, okay?"
    mc "Yo... sólo necesito irme a casa un rato, ¿vale?"

# game/dia2.rpy:1209
translate Spanish carol_ca87230b:

    # p "You’re scared..."
    p "Tienes miedo..."

# game/dia2.rpy:1210
translate Spanish carol_bd55d288:

    # p "{cps=5}..."
    p "{cps=5}..."

# game/dia2.rpy:1211
translate Spanish carol_3ab4056a:

    # p "S-Sure."
    p "C-Claro."

# game/dia2.rpy:1222
translate Spanish carol_2f3d6ce7:

    # mc "Please, don’t… just let me go home. I think that was too much for my head."
    mc "Por favor, no... déjame ir a casa. Creo que eso fue demasiado para mi cabeza."

# game/dia2.rpy:1238
translate Spanish carol_1884f201:

    # narrator "He nods, and you step away."
    narrator "Él asiente y tú te alejas."

# game/dia2.rpy:1241
translate Spanish carol_3b4cf669:

    # p "{size=20}I’ll wait for you there."
    p "{size=20}Te espero allí."

# game/dia2.rpy:1257
translate Spanish devolta_emcasa_d1cbeb00:

    # mcp "(Ugh, what a weird feeling… I felt like I was being watched last night.)"
    mcp "(Uf, qué sensación más extraña… anoche sentí como si me estuvieran observando)."

# game/dia2.rpy:1259
translate Spanish devolta_emcasa_ba669d6d:

    # mcp "(I guess Pierrot and Harlequin’s performances really got into my head.)"
    mcp "(Supongo que las actuaciones de Pierrot y Arlequín realmente se me metieron en la cabeza.)"

# game/dia2.rpy:1260
translate Spanish devolta_emcasa_a743af8f:

    # mcp "(I’ve got the day off today. I was thinking of watching something, but...)"
    mcp "(Hoy tengo el día libre. Estaba pensando en ver algo, pero...)"

# game/dia2.rpy:1261
translate Spanish devolta_emcasa_a7e451d6:

    # mcp "(I kinda want to see Pierrot. Maybe I’ll stop by the circus and watch him work.)"
    mcp "(Como que tengo ganas de ver a Pierrot. Tal vez pase por el circo y lo vea trabajar)."

# game/dia2.rpy:1265
translate Spanish devolta_emcasa_354b505e:

    # narrator "You change into a comfy shirt and notice the pins on the collar."
    narrator "Te pones una camisa cómoda y notas los alfileres en el cuello."

# game/dia2.rpy:1272
translate Spanish devolta_emcasa_bec7176e:

    # mcp "(Pierrot and Harlequin’s pins! They seemed to care a lot about these yesterday.)"
    mcp "(¡Los alfileres de Pierrot y Arlequín! Ayer parecían importarles mucho)."

# game/dia2.rpy:1273
translate Spanish devolta_emcasa_69cbe4a9:

    # mcp "(I think I’ll… put them away for now. Feels like if I wear one, I’ll definitely catch their attention.)"
    mcp "(Creo que... los guardaré por ahora. Siento que si uso uno, definitivamente llamaré su atención)."

# game/dia2.rpy:1278
translate Spanish devolta_emcasa_2bda9fde:

    # narrator "You check your pockets and find something."
    narrator "Revisas tus bolsillos y encuentras algo."

# game/dia2.rpy:1279
translate Spanish devolta_emcasa_02680055:

    # mcp "(Pierrot’s ticket!)"
    mcp "(¡El boleto de Pierrot!)"

# game/dia2.rpy:1283
translate Spanish devolta_emcasa_c0876848:

    # mcp "(I really like his photo on the back of the ticket. It’s kinda dark… but I like that.)"
    mcp "(Me gusta mucho su foto en el reverso del boleto. Es un poco oscura... pero eso me gusta.)"

# game/dia2.rpy:1284
translate Spanish devolta_emcasa_f45ebe82:

    # mcp "(I’ll keep this too. It’s already punched, so I can’t use it again.)"
    mcp "(Me quedaré con esto también. Ya está perforado, así que no puedo volver a usarlo)."

# game/dia2.rpy:1285
translate Spanish devolta_emcasa_3e124085:

    # mcp "(But it might be nice to save it since it seems kind of \"special.\")"
    mcp "(Pero sería bueno guardarlo ya que parece algo \"especial.\")"

# game/dia2.rpy:1290
translate Spanish devolta_emcasa_43257242:

    # mcp "(The flower Pierrot gave me!)"
    mcp "(¡La flor que me regaló Pierrot!)"

# game/dia2.rpy:1298
translate Spanish devolta_emcasa_d1134c16:

    # mcp "(It’s dark now, and it smells like...{w=0.3}{cps=12} iron, I guess.)"
    mcp "(Ahora está oscura y huele a...{w=0.3}{cps=12} hierro, supongo.)"

# game/dia2.rpy:1299
translate Spanish devolta_emcasa_2cb204c7:

    # mc "{size=45}{cps=10}..."
    mc "{size=45}{cps=10}..."

# game/dia2.rpy:1300
translate Spanish devolta_emcasa_ffd8f0c9:

    # mcp "(Well, I won’t think too much about it for now, maybe it’s just in my head.)"
    mcp "(Bueno, no pensaré mucho en eso por ahora, tal vez solo esté en mi cabeza)."

# game/dia2.rpy:1301
translate Spanish devolta_emcasa_d3f3e97f:

    # mc "{cps=12}Hahah..."
    mc "{cps=12}Jaja..."

# game/dia2.rpy:1302
translate Spanish devolta_emcasa_b7842039:

    # mcp "{cps=20}(Maybe not…)"
    mcp "{cps=20}(Quizás no…)"

# game/dia2.rpy:1309
translate Spanish devolta_emcasa_024866a8:

    # mcp "(Still... I’ll keep it.)"
    mcp "(Aun así... la conservaré.)"

# game/dia2.rpy:1314
translate Spanish devolta_emcasa_1cffa1e3:

    # mc "Let’s see how he’s doing!"
    mc "¡Veamos cómo le va!"

# game/dia2.rpy:1320
translate Spanish circorua_128c0784:

    # mcp "(During the day they do street acts to promote the circus, from what I’ve noticed.)"
    mcp "(Durante el día hacen actos callejeros para promocionar el circo, por lo que he notado)."

# game/dia2.rpy:1321
translate Spanish circorua_de326116:

    # mcp "(And at night, they have the real performances and all that. It’s funny how the whole vibe of this place changes during the day.)"
    mcp "(Y por la noche, tienen actuaciones reales y todo eso. Es curioso cómo cambia todo el ambiente de este lugar durante el día)."

# game/dia2.rpy:1323
translate Spanish circorua_b815f529:

    # narrator "You walk closer to the entrance of the circus and spot performers trying to grab people’s attention as they tell spooky stories."
    narrator "Caminas más cerca de la entrada del circo y ves a los artistas que intentan captar la atención de la gente mientras cuentan historias espeluznantes."

# game/dia2.rpy:1324
translate Spanish circorua_76b8b173:

    # narrator "Alongside them, masked clowns in bright pink costumes hand out flyers."
    narrator "Junto a ellos, payasos enmascarados vestidos con trajes de color rosa brillante reparten folletos."

# game/dia2.rpy:1327
translate Spanish circorua_a5ba2f83:

    # mc "Harlequins and Jesters, huh? At least that’s what Pierrot said, though."
    mc "Arlequines y bufones, ¿eh? Al menos eso es lo que dijo Pierrot."

# game/dia2.rpy:1328
translate Spanish circorua_d3e759c1:

    # mc "I don’t really see the difference."
    mc "Realmente no veo la diferencia."

# game/dia2.rpy:1334
translate Spanish circorua_1fde06a3:

    # a "He said that? Oh my, he actually talked to you?"
    a "¿Dijo eso? Dios mío, ¿realmente habló contigo?"

# game/dia2.rpy:1336
translate Spanish circorua_e970465c:

    # mc "Wha-?! Where did you come from??"
    mc "¡¿Qué-?! ¿De dónde saliste?"

# game/dia2.rpy:1337
translate Spanish circorua_8c20b5bb:

    # mcp "(I didn’t even notice I said that out loud!)"
    mcp "(¡Ni siquiera me di cuenta de que dije eso en voz alta!)"

# game/dia2.rpy:1345
translate Spanish circorua_8d4628f7:

    # a "So, you heard his voice. Interesting ♪"
    a "Entonces escuchaste su voz. Interesante ♪"

# game/dia2.rpy:1347
translate Spanish circorua_695d3488:

    # mcp "(Ugh, I hope that doesn’t get Pierrot in trouble…)"
    mcp "(Uf, espero que eso no meta a Pierrot en problemas…)"

# game/dia2.rpy:1355
translate Spanish circorua_cfad7702:

    # a "{i}Aww, look at that guilty little face! Don’t worry, [titulo_arlequim], maybe I’ll keep your secret."
    a "{i}Aww, ¡mira esa carita culpable! No te preocupes, [titulo_arlequim!t], quizás guarde tu secreto."

# game/dia2.rpy:1356
translate Spanish circorua_d1fcf201:

    # a "But no, those aren’t Harlequins. They’re {b}Fools."
    a "Pero no, esos no son Arlequines. Son {b}necios."

# game/dia2.rpy:1363
translate Spanish circorua_703fcd97:

    # a "Of course he would compare me to some street fool."
    a "Por supuesto que me compararía con algún tonto callejero."

# game/dia2.rpy:1367
translate Spanish circorua_77674ef0:

    # mc "Fools?"
    mc "¿Tontos?"

# game/dia2.rpy:1370
translate Spanish circorua_be25dcb7:

    # narrator "He smiles at your curiosity, stops behind you and leans in to whisper, guiding your gaze toward the fools."
    narrator "Él sonríe ante tu curiosidad, se detiene detrás de ti y se inclina para susurrar, guiando tu mirada hacia los tontos."

# game/dia2.rpy:1371
translate Spanish circorua_73ffa52a:

    # a "There’s only one Harlequin, one Pierrot, and one Jester in our circus."
    a "En nuestro circo sólo hay un Arlequín, un Pierrot y un Bufón."

# game/dia2.rpy:1372
translate Spanish circorua_c18065b7:

    # a "{bt=1}{color=#41d623}{i}Those little darlings in pink? Hah! They’re {color=#e61ee6}Fools{color=#41d623} ♪"
    a "{bt=1}{color=#41d623}{i}¿Esos angelitos vestidos de rosa? ¡Ja! Son {color=#e61ee6}Tontos{color=#41d623} ♪"

# game/dia2.rpy:1373
translate Spanish circorua_cd4318d0:

    # mcp "(There’s something disturbingly sadistic in the way he explains it.)"
    mcp "(Hay algo inquietantemente sádico en la forma en que lo explica)."

# game/dia2.rpy:1374
translate Spanish circorua_ba06b111:

    # a "{cps=20}Oh,{w=0.3} you’re not wearing my pin.{/cps} That really breaks my heart, you know?"
    a "{cps=20}Oh,{w=0.3} no llevas mi pin.{/cps} Eso realmente me rompe el corazón, ¿sabes?"

# game/dia2.rpy:1376
translate Spanish circorua_fb761f27:

    # narrator "His fingers brush the collar of your blouse."
    narrator "Sus dedos rozan el cuello de tu camisa."

# game/dia2.rpy:1383
translate Spanish circorua_9734060a:

    # a "So, what else did he tell you?"
    a "Entonces, ¿qué más te dijo?"

# game/dia2.rpy:1384
translate Spanish circorua_283763b5:

    # a "Have you seen what’s behind his mask?"
    a "¿Has visto lo que hay detrás de su máscara?"

# game/dia2.rpy:1386
translate Spanish circorua_bee67870:

    # mc "No. And don’t drag me into your fight I’m not trying to cause trouble for anyone."
    mc "No. Y no me arrastres a tu pelea. No estoy tratando de causar problemas a nadie."

# game/dia2.rpy:1388
translate Spanish circorua_cfa261ec:

    # a "But you’re curious about them, aren’t you?"
    a "Pero sientes curiosidad por ellos, ¿no?"

# game/dia2.rpy:1389
translate Spanish circorua_2b35b6fe:

    # mc "..."
    mc "..."

# game/dia2.rpy:1396
translate Spanish circorua_1f3ee5ff:

    # a "Hmm… {i}silence.{/i} Always the most honest reply."
    a "Hmm… {i}silencio.{/i} Siempre la respuesta más honesta."

# game/dia2.rpy:1402
translate Spanish circorua_ba06b111_1:

    # a "{cps=20}Oh,{w=0.3} you’re not wearing my pin.{/cps} That really breaks my heart, you know?"
    a "{cps=20}Oh,{w=0.3} no llevas mi pin.{/cps} Eso realmente me rompe el corazón, ¿sabes?"

# game/dia2.rpy:1405
translate Spanish circorua_553e5986:

    # narrator "He steps behind you, leaning in to whisper while keeping his gaze fixed on the performance."
    narrator "Se pone detrás de ti, inclinándose para susurrar mientras mantiene la mirada fija en la actuación."

# game/dia2.rpy:1408
translate Spanish circorua_b3d5d97c:

    # mc "The cast looks bigger."
    mc "El elenco parece más grande."

# game/dia2.rpy:1409
translate Spanish circorua_6b92027a:

    # mc "There weren’t this many people handing out flyers at first."
    mc "Al principio no había tanta gente repartiendo folletos."

# game/dia2.rpy:1415
translate Spanish circorua_be5323ab:

    # a "There really weren’t."
    a "Realmente no había tantos."

# game/dia2.rpy:1417
translate Spanish circorua_e970465c_1:

    # mc "Wha-?! Where did you come from??"
    mc "¡¿Qué-?! ¿De dónde saliste?"

# game/dia2.rpy:1418
translate Spanish circorua_8c20b5bb_1:

    # mcp "(I didn’t even notice I said that out loud!)"
    mcp "(¡Ni siquiera me di cuenta de que dije eso en voz alta!)"

# game/dia2.rpy:1420
translate Spanish circorua_9aad13c8:

    # a "Forgive me, [titulo_arlequim]. You just looked so charming, all focused on the show. Having fun?"
    a "Perdóname, [titulo_arlequim!t]. Te veías tan adorable, tan concentrad[letra] en el espectáculo. ¿Te diviertes?"

# game/dia2.rpy:1422
translate Spanish circorua_7df4dd38:

    # mc "I think so, things are really… Different at your circus."
    mc "Creo que sí. Las cosas son realmente… diferentes en tu circo."

# game/dia2.rpy:1430
translate Spanish circorua_26bc46a3:

    # a "How sweet when you say {i}“different,” what you really mean is..."
    a "Qué tierno que digas {i}“diferente”, cuando en realidad quieres decir..."

# game/dia2.rpy:1438
translate Spanish circorua_ae2e922b:

    # a "{b}Freakish{/b}, isn’t it?"
    a "{b}Monstruoso{/b}, ¿no es así?"

# game/dia2.rpy:1446
translate Spanish circorua_ba06b111_2:

    # a "{cps=20}Oh,{w=0.3} you’re not wearing my pin.{/cps} That really breaks my heart, you know?"
    a "{cps=20}Oh,{w=0.3} no llevas mi pin.{/cps} Eso realmente me rompe el corazón, ¿sabes?"

# game/dia2.rpy:1450
translate Spanish circorua_6ce093d1:

    # narrator "He stops behind you, leaning in to whisper while keeping his gaze fixed on the performance."
    narrator "Se detiene detrás de ti, inclinándose para susurrar mientras mantiene la mirada fija en la actuación."

# game/dia2.rpy:1452
translate Spanish circorua_52b4e735:

    # a "No need to look at me. Watch the show like I’m not even here, dear."
    a "No es necesario que me mires. Mira el espectáculo como si ni siquiera estuviera aquí, querid[letra]."

# game/dia2.rpy:1453
translate Spanish circorua_77c0920d:

    # a "We attract less attention that way."
    a "De esa manera atraemos menos atención."

# game/dia2.rpy:1455
translate Spanish circorua_c7a09039:

    # mcp "(You’re a green dot in the middle of the street there’s no way to stand out more than this.)"
    mcp "(Eres un punto verde en medio de la calle, no hay forma de destacar más que esto)."

# game/dia2.rpy:1459
translate Spanish circorua_9c626c06:

    # a "I love that curious look in your eyes, and I know...{w=0.3}{cps=15} you came here for Pierrot."
    a "Me encanta esa mirada curiosa en tus ojos, y sé que...{w=0.3}{cps=15} viniste aquí por Pierrot."

# game/dia2.rpy:1460
translate Spanish circorua_7f26a003:

    # a "You like the way we send shivers down your spine, don’t you?"
    a "Te gusta la forma en que te hacemos sentir escalofríos, ¿no?"

# game/dia2.rpy:1464
translate Spanish circorua_420b94ce:

    # narrator "You feel his body press lightly against your back."
    narrator "Sientes su cuerpo presionarse suavemente contra tu espalda."

# game/dia2.rpy:1466
translate Spanish circorua_a3649c3b:

    # mc "Maybe that’s because you guys get way too close, don’t you think?"
    mc "Tal vez sea porque se acercan demasiado, ¿no crees?"

# game/dia2.rpy:1469
translate Spanish circorua_a2eb467b:

    # a "{cps=30}{i}Hmm… isn’t that the best part?"
    a "{cps=30}{i}Hmm… ¿no es esa la mejor parte?"

# game/dia2.rpy:1470
translate Spanish circorua_6b69d736:

    # a "Maybe...{w=0.3}{cps=20} I was a little rude the last time we met. Don’t get me wrong."
    a "Quizás...{w=0.3}{cps=20} Fui un poco grosero la última vez que nos vimos. No me malinterpretes."

# game/dia2.rpy:1471
translate Spanish circorua_72388709:

    # a "{cps=30}I think your eyes enchanted me, and I wanted to get so close that I crossed a line, didn’t I?"
    a "{cps=30}Creo que tus ojos me hechizaron y quise acercarme tanto que crucé la línea, ¿no?"

# game/dia2.rpy:1472
translate Spanish circorua_4d2dba3f:

    # a "{cps=30}But tell me, did you think about me too? Or..."
    a "{cps=30}Pero dime, ¿tú también pensaste en mí? O..."

# game/dia2.rpy:1473
translate Spanish circorua_97ae69e5:

    # a "{cps=35}Am I the only {i}fool{/i} caught in your spell?"
    a "{cps=35}¿Soy el único {i}tonto{/i} atrapado en tu hechizo?"

# game/dia2.rpy:1475
translate Spanish circorua_23c3d5ad:

    # mcp "(His voice, sounds different...)"
    mcp "(Su voz suena diferente...)"

# game/dia2.rpy:1477
translate Spanish circorua_35c450ca:

    # a "That’s just my nature, my dear. I like making your heart {b}race{/b}, stirring your reactions."
    a "Esa es mi naturaleza, querid[letra]. Me gusta hacer que tu corazón se {b}acelere{/b}, provocando tus reacciones."

# game/dia2.rpy:1478
translate Spanish circorua_4de46381:

    # a "But subtle? That’s not me, unlike a lovesick Pierrot."
    a "¿Pero sutil? Ese no soy yo, a diferencia de un Pierrot enamorado."

# game/dia2.rpy:1480
translate Spanish circorua_6a2409ae:

    # mcp "(His voice actually sounds, warmer? If I turn around now...)"
    mcp "(Su voz suena, de hecho, ¿más cálida? Si me doy la vuelta ahora…)"

# game/dia2.rpy:1481
translate Spanish circorua_818d4a40:

    # mcp "(Will he be smiling that cynical smile?)"
    mcp "(¿Estará sonriendo con esa sonrisa cínica?)"

# game/dia2.rpy:1484
translate Spanish circorua_ba92566c:

    # narrator "His face is too close, like he’s hearing you and wants to keep your cruel doubt alive."
    narrator "Tiene el rostro demasiado cerca, como si pudiera oír tus pensamientos y quisiera mantener viva esa duda cruel."

# game/dia2.rpy:1485
translate Spanish circorua_42376059:

    # narrator "You can’t look at him and he doesn’t give you a chance to pull away."
    narrator "No puedes mirarlo y él no te da la oportunidad de alejarte."

# game/dia2.rpy:1487
translate Spanish circorua_3f853826:

    # mcp "(If I turn, I’ll be way too close to him.)"
    mcp "(Si me giro, estaré demasiado cerca de él)."

# game/dia2.rpy:1489
translate Spanish circorua_5591205b:

    # narrator "You feel his hand hesitantly reach toward yours but it quickly pulls back."
    narrator "Sientes que su mano se acerca vacilante a la tuya, pero rápidamente la retira."

# game/dia2.rpy:1491
translate Spanish circorua_7fe18732:

    # a "If I held your hand right now... would you pull away?"
    a "Si tomara tu mano ahora mismo... ¿te alejarías?"

# game/dia2.rpy:1492
translate Spanish circorua_870e8e9f:

    # a "{cps=20}Or are you waiting for me to make the first move again?"
    a "{cps=20}¿O estás esperando a que vuelva a dar el primer paso?"

# game/dia2.rpy:1494
translate Spanish circorua_775fa2cb:

    # narrator "He trails his claw along the collar of your blouse, right where the green heart pin used to be."
    narrator "Pasa su garra por el cuello de tu camisa, justo donde solía estar el alfiler del corazón verde."

# game/dia2.rpy:1497
translate Spanish circorua_2a401dd4:

    # a "[mc_nome], do you want to feel my heart beating for you?"
    a "[mc_nome], ¿quieres sentir mi corazón latir por ti?"

# game/dia2.rpy:1498
translate Spanish circorua_98afc9d1:

    # a "Want me to show you how I feel? Come with me..."
    a "¿Quieres que te muestre cómo me siento? Ven conmigo..."

# game/dia2.rpy:1499
translate Spanish circorua_c6058dc6:

    # a "I’ll make your heart beat in time with mine."
    a "Haré que tu corazón lata al mismo tiempo que el mío."

# game/dia2.rpy:1500
translate Spanish circorua_f29e277f:

    # a "{i}But maybe, you’ll lose your breath."
    a "{i}Pero tal vez te quedes sin aliento."

# game/dia2.rpy:1504
translate Spanish circorua_9783b7c7:

    # narrator "He steps back, slipping between the circus tents, subtly looking at you, giving a silent invitation."
    narrator "Da un paso atrás, deslizándose entre las carpas del circo, mirándote sutilmente, haciéndote una invitación silenciosa."

# game/dia2.rpy:1506
translate Spanish circorua_78179c21:

    # mcp "(I get chills every time he comes close, every time he talks to me like that.)"
    mcp "(Me dan escalofríos cada vez que se acerca, cada vez que me habla así)."

# game/dia2.rpy:1508
translate Spanish circorua_bdbde839:

    # mcp "(What does he really mean by it?)"
    mcp "(¿Qué quiere decir realmente con eso?)"

# game/dia2.rpy:1513
translate Spanish circorua_50a2efc1:

    # narrator "You see Harlequin’s mischievous smile from a distance, but you don’t follow him."
    narrator "Ves la sonrisa traviesa de Arlequín desde lejos, pero no lo sigues."

# game/dia2.rpy:1514
translate Spanish circorua_efc2b05b:

    # mcp "(He really had a wicked grin.)"
    mcp "(Realmente tenía una sonrisa malvada)."

# game/dia2.rpy:1515
translate Spanish circorua_5fe16413:

    # mcp "(Better go the other way, maybe I can still find Pierrot around here.)"
    mcp "(Será mejor que vaya por el otro lado, tal vez todavía pueda encontrar a Pierrot por aquí.)"

# game/dia2.rpy:1519
translate Spanish circorua_a2d56608:

    # mc "{size=40}{cps=10}..."
    mc "{size=40}{cps=10}..."

# game/dia2.rpy:1520
translate Spanish circorua_3c68e4fc:

    # mcp "(But, what was he actually trying to imply?)"
    mcp "(Pero, ¿qué estaba realmente tratando de dar a entender?)"

# game/dia2.rpy:1524
translate Spanish circorua_94a09ac5:

    # mc "Ouch!"
    mc "¡Ay!"

# game/dia2.rpy:1526
translate Spanish circorua_dac47e21:

    # mcp "(I was so lost in my thoughts that I bumped into someone.)"
    mcp "(Estaba tan perdid[letra] en mis pensamientos que choqué con alguien.)"

# game/dia2.rpy:1532
translate Spanish circorua_96a7546b:

    # narrator "His words echo in your mind, your skin tingles, and you can't hide your curiosity."
    narrator "Sus palabras resuenan en tu mente, tu piel hormiguea y no puedes ocultar tu curiosidad."

# game/dia2.rpy:1533
translate Spanish circorua_b41c62b5:

    # mcp "(I want to see where this leads...)"
    mcp "(Quiero ver a dónde lleva esto...)"

# game/dia2.rpy:1538
translate Spanish circorua_d10e1094:

    # mcp "(I'm sure he was around here. How does he move without making a sound with those bells?)"
    mcp "(Estoy segur[letra] de que estuvo por aquí. ¿Cómo se mueve sin hacer ruido con esos cascabeles?)"

# game/dia2.rpy:1544
translate Spanish circorua_e8dc268a:

    # narrator "You feel something brush against your back. He leans down, resting his face on your shoulder."
    narrator "Sientes que algo roza tu espalda. Se inclina y apoya su rostro en tu hombro."

# game/dia2.rpy:1545
translate Spanish circorua_0b192fce:

    # a "So, you took my invite? Brave."
    a "Entonces, ¿aceptaste mi invitación? Valiente."

# game/dia2.rpy:1546
translate Spanish circorua_11b9fde9:

    # a "Were you more curious about \"hearing my heart\" or \"losing your breath\"?"
    a "¿Tenías más curiosidad por \"escuchar mi corazón\" o por \"perder el aliento\"?"

# game/dia2.rpy:1551
translate Spanish circorua_8189f469:

    # narrator "He grabs your waist, pulling you closer." with hpunch
    narrator "Él te agarra por la cintura y te acerca más." with hpunch

# game/dia2.rpy:1553
translate Spanish circorua_672115d7:

    # mc "Of course, you were mocking me…"
    mc "Por supuesto, te estabas burlando de mí..."

# game/dia2.rpy:1555
translate Spanish circorua_8a1623d6:

    # a "Mocking? Huhum no, [mc_nome]."
    a "¿Burlarme? Mm-mm, no, [mc_nome]."

# game/dia2.rpy:1556
translate Spanish circorua_776a7ecf:

    # a "I haven’t lied to you. I’m always clear about what I want."
    a "No te he mentido. Siempre tengo claro lo que quiero."

# game/dia2.rpy:1558
translate Spanish circorua_08e746ca:

    # narrator "You feel his claws dig into your waist a little harder."
    narrator "Sientes que sus garras se clavan un poco más en tu cintura."

# game/dia2.rpy:1560
translate Spanish circorua_441630c3:

    # a "And you’ve already figured that out, haven’t you?"
    a "Y eso ya lo has descubierto, ¿no?"

# game/dia2.rpy:1562
translate Spanish circorua_2b092bac:

    # mc "I think it’s pretty easy to figure out what you want."
    mc "Creo que es bastante fácil descubrir lo que quieres."

# game/dia2.rpy:1564
translate Spanish circorua_47d5b71b:

    # a "Then how about we turn the lights off? I like it when you get lost."
    a "Entonces ¿qué tal si apagamos las luces? Me gusta cuando te pierdes."

# game/dia2.rpy:1565
translate Spanish circorua_a6ab56fd:

    # a "{i}{sc=1}{color=#41d623}When you can’t see where my fingers will end up."
    a "{i}{sc=1}{color=#41d623}Cuando no puedes ver dónde terminarán mis dedos."

# game/dia2.rpy:1566
translate Spanish circorua_bc33ff32:

    # a "And since you came to me… {i}let’s play ♪"
    a "Y ya que viniste a mí… {i}juguemos ♪"

# game/dia2.rpy:1573
translate Spanish natenda_27327bce:

    # narrator "You’re pulled inside the tent."
    narrator "Te arrastran dentro de la carpa."

# game/dia2.rpy:1578
translate Spanish natenda_b0be59b7:

    # a "Look at you..."
    a "Mírate..."

# game/dia2.rpy:1585
translate Spanish natenda_4dfec3b9:

    # a "Your heart’s already beating at the pace I like."
    a "Tu corazón ya late al ritmo que me gusta."

# game/dia2.rpy:1589
translate Spanish natenda_58572935:

    # a "Too dark for your eyes, isn’t it? But the perfect grounds for me."
    a "Demasiado oscuro para tus ojos, ¿no? Pero el terreno perfecto para mí."

# game/dia2.rpy:1591
translate Spanish natenda_edaf8085:

    # mc "T-that’s not funny, Harlequin! It’s way too dark in here."
    mc "¡E-eso no es gracioso, Arlequín! Está demasiado oscuro aquí."

# game/dia2.rpy:1598
translate Spanish natenda_ac863405:

    # a "{i}I know{/i}, you can’t see me, but I see you."
    a "{i}Lo sé{/i}, no puedes verme, pero yo te veo."

# game/dia2.rpy:1599
translate Spanish natenda_2b3bb076:

    # a "Every detail. And trust me, it’s better this way."
    a "Cada detalle. Y créeme, es mejor así."

# game/dia2.rpy:1604
translate Spanish natenda_439c4028:

    # narrator "The cold mask brushes against your skin, and two hot trails run down the length of your neck."
    narrator "La máscara fría roza tu piel y dos rastros cálidos recorren tu cuello."

# game/dia2.rpy:1606
translate Spanish natenda_7982255d:

    # a "Ah… exactly how I imagined you’d taste. I could lose myself in this."
    a "Ah… exactamente como imaginé que sabrías. Podría perderme en esto."

# game/dia2.rpy:1608
translate Spanish natenda_f6fdea80:

    # mc "Did you just lick me??"
    mc "¿Me acabas de lamer?"

# game/dia2.rpy:1610
translate Spanish natenda_f53c1e0b:

    # a "That’s all you’re worried about? Mm…"
    a "¿Eso es todo lo que te preocupa? Mmm..."

# game/dia2.rpy:1611
translate Spanish natenda_2d70c338:

    # a "{cps=15}You have no idea how much deeper this can go."
    a "{cps=15}No tienes idea de cuánto más profundo puede llegar esto."

# game/dia2.rpy:1620
translate Spanish natenda_d38cae19:

    # narrator "You step back and bump into what feels like a table." with vpunch
    narrator "Das un paso atrás y chocas contra lo que parece una mesa." with vpunch

# game/dia2.rpy:1622
translate Spanish natenda_f08f9c80:

    # narrator "He grabs your wrist and tilts your chin up."
    narrator "Te agarra la muñeca y te levanta la barbilla."

# game/dia2.rpy:1628
translate Spanish natenda_9f673700:

    # a "You’re not afraid of monsters in the dark, are you?"
    a "No les temes a los monstruos en la oscuridad, ¿verdad?"

# game/dia2.rpy:1631
translate Spanish natenda_d10351c4:

    # narrator "You feel something coil and slide around your ankles."
    narrator "Sientes que algo se enrolla y se desliza alrededor de tus tobillos."

# game/dia2.rpy:1633
translate Spanish natenda_c6abef9c:

    # mc "W-What the hell is that??"
    mc "¿Q-Qué diablos es eso?"

# game/dia2.rpy:1635
translate Spanish natenda_e20715d3:

    # a "Shhh… I can almost hear your heart screaming ♪"
    a "Shhh… casi puedo escuchar tu corazón gritar ♪"

# game/dia2.rpy:1638
translate Spanish natenda_ce0766b0:

    # narrator "Something seizes your other wrist, your waist, your thighs like living ropes pulling you closer to him."
    narrator "Algo agarra tu otra muñeca, tu cintura, tus muslos como cuerdas vivas que te acercan a él."

# game/dia2.rpy:1644
translate Spanish natenda_5ebe8971:

    # mcp "(Something’s wrong, I can feel his hands gripping me, but what are these things touching me??)"
    mcp "(Algo anda mal, puedo sentir sus manos agarrándome, pero ¿¿qué son estas cosas que me tocan??)"

# game/dia2.rpy:1646
translate Spanish natenda_bfb8d3d8:

    # mc "H-how are you doing this?"
    mc "¿C-cómo estás haciendo esto?"

# game/dia2.rpy:1652
translate Spanish natenda_740cb7c9:

    # a "You know, he lies to you. Hides and whispers passion when you’re not listening."
    a "Ya sabes, te miente. Se esconde y susurra pasión cuando no estás escuchando."

# game/dia2.rpy:1653
translate Spanish natenda_538da031:

    # a "Me? I don’t need to lie, I can show you a little... more."
    a "¿Yo? No necesito mentir; puedo mostrarte un poco... más."

# game/dia2.rpy:1654
translate Spanish natenda_e59fbe96:

    # a "Do you want to see… what we really are?"
    a "¿Quieres ver… lo que realmente somos?"

# game/dia2.rpy:1657
translate Spanish natenda_f7043ad2:

    # narrator "The \"ropes\" tighten and wind around you harder."
    narrator "Las \"cuerdas\" se aprietan y se enrollan con más fuerza a tu alrededor."

# game/dia2.rpy:1669
translate Spanish natenda_f7101125:

    # a "Ah… your eyes right now..."
    a "Ah... tus ojos ahora mismo..."

# game/dia2.rpy:1680
translate Spanish natenda_6a92013b:

    # a "Wide, desperate, clinging to every scrap of light, as if it could save you."
    a "Abiertos de par en par, desesperados, aferrándose a cada rastro de luz, como si pudiera salvarte."

# game/dia2.rpy:1681
translate Spanish natenda_00b156e7:

    # a "{i}It’s almost adorable ♪"
    a "{i}Es casi adorable ♪"

# game/dia2.rpy:1684
translate Spanish natenda_e3ef84c6:

    # narrator "He calmly presses your body against the table."
    narrator "Con calma presiona tu cuerpo contra la mesa."

# game/dia2.rpy:1697
translate Spanish natenda_09ac5909:

    # narrator "The \"ropes\" slither like snakes, brushing against your skin."
    narrator "Las \"cuerdas\" se deslizan como serpientes y rozan tu piel."

# game/dia2.rpy:1699
translate Spanish natenda_fcc58588:

    # mcp "(What the hell are these things all over me??)"
    mcp "(¿Qué diablos son estas cosas encima de mí?)"

# game/dia2.rpy:1701
translate Spanish natenda_f2d15c51:

    # mc "Harlequin you’re freaking me out! what- {nw=1.0}"
    mc "¡Arlequín, me estás asustando! qué- {nw=1.0}"

# game/dia2.rpy:1703
translate Spanish natenda_95707b10:

    # a "\"What’s{cps=12} touching me?\""
    a "\"¿Qué{cps=12} me está tocando?\""

# game/dia2.rpy:1704
translate Spanish natenda_bb1932eb:

    # a "Oh, darling trust me, it’s better if we stay in the dark."
    a "Oh, cariño, confía en mí, es mejor si nos quedamos en la oscuridad."

# game/dia2.rpy:1705
translate Spanish natenda_3eaca29a:

    # a "What you feel crawling over your body..."
    a "Lo que sientes arrastrándose por tu cuerpo..."

# game/dia2.rpy:1706
translate Spanish natenda_de0ca56b:

    # a "{b}It’s me."
    a "{b}Soy yo."

# game/dia2.rpy:1708
translate Spanish natenda_40128613:

    # a "And I really want to feel your skin right now."
    a "Y ahora mismo tengo muchas ganas de sentir tu piel."

# game/dia2.rpy:1721
translate Spanish natenda_aa686ca9:

    # a "{i}Wild ♪"
    a "{i}Salvaje ♪"

# game/dia2.rpy:1729
translate Spanish natenda_c84af805:

    # narrator "He pins your wrists to the table."
    narrator "Te sujeta las muñecas a la mesa."

# game/dia2.rpy:1731
translate Spanish natenda_2855010d:

    # a "Ah... {cps=12}[mc_nome], [mc_nome]..."
    a "Ah... {cps=12}[mc_nome], [mc_nome]..."

# game/dia2.rpy:1732
translate Spanish natenda_7b7baad0:

    # a "You knew exactly where this road would end, and still, you walked it."
    a "Sabías exactamente dónde terminaría este camino y aun así lo recorriste."

# game/dia2.rpy:1733
translate Spanish natenda_25e0b97d:

    # a "You followed me."
    a "Me seguiste."

# game/dia2.rpy:1734
translate Spanish natenda_cc2ce1f8:

    # a "Go ahead, pretend you didn’t want this."
    a "Adelante, finge que no querías esto."

# game/dia2.rpy:1735
translate Spanish natenda_be3563a2:

    # a "Pretend you didn’t ache for my hands to trap you like this."
    a "Finge que no anhelabas que mis manos te atraparan así."

# game/dia2.rpy:1736
translate Spanish natenda_8cc7be98:

    # a "You want me to devour you, but you’re too afraid to admit it."
    a "Quieres que te devore, pero tienes demasiado miedo para admitirlo."

# game/dia2.rpy:1737
translate Spanish natenda_752c488e:

    # a "That’s fine, I can read your hunger better than you can."
    a "Está bien, puedo leer tu hambre mejor que tú."

# game/dia2.rpy:1741
translate Spanish natenda_d25d9aee:

    # narrator "The \"ropes\" start to slide into your clothes."
    narrator "Las \"cuerdas\" comienzan a deslizarse dentro de tu ropa."

# game/dia2.rpy:1742
translate Spanish natenda_d9d7d6d2:

    # mc "H-Harlequin!!"
    mc "¡¡Arlequín!!"

# game/dia2.rpy:1748
translate Spanish natenda_6e0d596c:

    # narrator "You clutch at the \"ropes\" winding over your body."
    narrator "Te agarras a las \"cuerdas\" que se enrollan sobre tu cuerpo."

# game/dia2.rpy:1749
translate Spanish natenda_bdb955f7:

    # mcp "(It’s warm… kind of soft, the tips are thin and move like they’re alive.)"
    mcp "(Es cálido... algo suave, las puntas son delgadas y se mueven como si estuvieran vivas)."

# game/dia2.rpy:1750
translate Spanish natenda_fd6e2a01:

    # mcp "(Just, what the hell am I holding? What is he doing to me?)"
    mcp "(Pero ¿qué diablos estoy sosteniendo? ¿Qué me está haciendo?)"

# game/dia2.rpy:1756
translate Spanish natenda_53b24a87:

    # a "Mmm… gripping me so tight, are you? I might think you’re enjoying this."
    a "Mmm… me estás sujetando con tanta fuerza, ¿eh? Podría pensar que estás disfrutando de esto."

# game/dia2.rpy:1760
translate Spanish natenda_d25d9aee_1:

    # narrator "The \"ropes\" start to slide into your clothes."
    narrator "Las \"cuerdas\" comienzan a deslizarse dentro de tu ropa."

# game/dia2.rpy:1762
translate Spanish natenda_15e73f2c:

    # a "But don’t worry I’m not letting you go anyway."
    a "Pero no te preocupes, no te dejaré ir de todos modos."

# game/dia2.rpy:1765
translate Spanish natenda_d9b8757a:

    # narrator "He brushes his lips against your skin."
    narrator "Roza sus labios contra tu piel."

# game/dia2.rpy:1767
translate Spanish natenda_d5873a1b:

    # mcp "(It’s different from before, his lips are warm.)"
    mcp "(Es diferente a antes, sus labios están cálidos)."

# game/dia2.rpy:1769
translate Spanish natenda_453cae22:

    # a "I’m going to leave my mark ♪"
    a "Voy a dejar mi marca ♪"

# game/dia2.rpy:1770
translate Spanish natenda_a7a52ee6:

    # a "So you remember exactly who made your body burn first."
    a "Así recordarás exactamente quién hizo que tu cuerpo ardiese primero."

# game/dia2.rpy:1773
translate Spanish natenda_e5641b1c:

    # narrator "He bites down, sharp teeth sinking into your skin, and you have to choke down the sound in your throat." with vpunch
    narrator "Muerde, sus dientes afilados se hunden en tu piel y tienes que ahogar el sonido en tu garganta." with vpunch

# game/dia2.rpy:1781
translate Spanish natenda_9b747440:

    # mcp "(Pierrot?)"
    mcp "(¿Pierrot?)"

# game/dia2.rpy:1802
translate Spanish natenda_60fef2df:

    # mcp "(I need to get out of here.)"
    mcp "(Necesito salir de aquí.)"

# game/dia2.rpy:1814
translate Spanish casa_pos_eventos_b1a9ecbf:

    # mc "What was all that??"
    mc "¿Qué fue todo eso?"

# game/dia2.rpy:1815
translate Spanish casa_pos_eventos_92e04f57:

    # mc "I-I… I don’t even know where to start freaking out!" with hpunch
    mc "Yo-yo… ¡Ni siquiera sé por dónde empezar a enloquecer!" with hpunch

# game/dia2.rpy:1820
translate Spanish casa_pos_eventos_7639690b:

    # mc "{sc=1}He kidnapped me!! And what if he did something to me?"
    mc "{sc=1}¡¡Me secuestró!! ¿Y si me hizo algo?"

# game/dia2.rpy:1821
translate Spanish casa_pos_eventos_5b5680d5:

    # mc "How did things escalate this much?"
    mc "¿Cómo es que las cosas escalaron tanto?"

# game/dia2.rpy:1822
translate Spanish casa_pos_eventos_d7776607:

    # mc "C-Carol is there! What’s happening in that place??"
    mc "¡Carol está ahí! ¿Qué está pasando en ese lugar?"

# game/dia2.rpy:1823
translate Spanish casa_pos_eventos_1738932f:

    # mc "{sc=1}S-she looked.... looked..."
    mc "{sc=1}E-ella parecía... parecía..."

# game/dia2.rpy:1824
translate Spanish casa_pos_eventos_7cb6f088:

    # mc "{cps=15}Like a doll...?"
    mc "{cps=15}¿Como una muñeca...?"

# game/dia2.rpy:1827
translate Spanish casa_pos_eventos_1fda3c04:

    # mc "Harlequin… what the hell was he doing to me?"
    mc "Arlequín… ¿qué diablos me estaba haciendo?"

# game/dia2.rpy:1828
translate Spanish casa_pos_eventos_0ff90fb5:

    # mc "Okay, I knew he wanted something… in that way."
    mc "Está bien, sabía que él quería algo… de esa manera."

# game/dia2.rpy:1829
translate Spanish casa_pos_eventos_0c2f617c:

    # mc "{sc=1}But those things touching me… that wasn’t normal!"
    mc "{sc=1}Pero esas cosas tocándome… ¡eso no era normal!"

# game/dia2.rpy:1830
translate Spanish casa_pos_eventos_4e255655:

    # mc "And then Pierrot! {sc=2}My god, did Pierrot stab him??"
    mc "¡Y luego Pierrot! {sc=2}Dios mío, ¿Pierrot lo apuñaló?"

# game/dia2.rpy:1831
translate Spanish casa_pos_eventos_c9ee457e:

    # mc "{sc=2.5}Oh god, there’s blood on my shirt too!"
    mc "{sc=2.5}¡Oh Dios, también hay sangre en mi camisa!"

# game/dia2.rpy:1832
translate Spanish casa_pos_eventos_ff4981bf:

    # mc "{sc=1}And then Carol… She was there! Completely oblivious to everything!"
    mc "{sc=1}Y luego Carol... ¡Ella estaba allí! ¡Completamente ajena a todo!"

# game/dia2.rpy:1833
translate Spanish casa_pos_eventos_e572e994:

    # mc "{sc=1}What’s happening in that place?"
    mc "{sc=1}¿Qué está pasando en ese lugar?"

# game/dia2.rpy:1836
translate Spanish casa_pos_eventos_d7776607_1:

    # mc "C-Carol is there! What’s happening in that place??"
    mc "¡Carol está ahí! ¿Qué está pasando en ese lugar?"

# game/dia2.rpy:1837
translate Spanish casa_pos_eventos_e70f1f4b:

    # mc "She didn’t recognize me! She was acting weird with this empty look."
    mc "¡Ella no me reconoció! Estaba actuando raro con esa mirada vacía."

# game/dia2.rpy:1838
translate Spanish casa_pos_eventos_c17ea2c7:

    # mc "And that Ticket Taker… He wouldn’t let me talk to her."
    mc "Y ese Boletero... No me dejaba hablar con ella."

# game/dia2.rpy:1839
translate Spanish casa_pos_eventos_b0a6944a:

    # mc "That conversation with Pierrot wasn’t normal at all, something’s really wrong there."
    mc "Esa conversación con Pierrot no fue nada normal, algo anda realmente mal ahí."

# game/dia2.rpy:1842
translate Spanish casa_pos_eventos_043c90c5:

    # mc "Maybe I...{nw=1.0}"
    mc "Tal vez yo...{nw=1.0}"

# game/dia2.rpy:1843
translate Spanish casa_pos_eventos_88d1bf49:

    # mcp "(Shit, did I leave the balcony door open?)"
    mcp "(Mierda, ¿dejé la puerta del balcón abierta?)"

# game/dia2.rpy:1853
translate Spanish casa_pos_eventos_08eb2a3f:

    # mc "N-No, it’s not open."
    mc "N-No, no está abierta."

# game/dia2.rpy:1868
translate Spanish casa_pos_eventos_344412ca:

    # mc "Pierrot...."
    mc "Pierrot...."

# game/dia2.rpy:1870
translate Spanish casa_pos_eventos_79d09641:

    # p "M-[titulo_pierrot]... puedo explicarlo todo."
    p "M-[titulo_pierrot!t]... puedo explicarlo todo."

# game/dia2.rpy:1879
translate Spanish casa_pos_eventos_1a8c054e:

    # mc "Then why was my missing friend there, looking like a \"doll\" to begin with??"
    mc "Entonces, ¿por qué mi amiga desaparecida estaba allí con pinta de \"muñeca\" para empezar?"

# game/dia2.rpy:1881
translate Spanish casa_pos_eventos_6dd1a496:

    # mc "Then why was my missing friend there, looking like a zombie to begin with??"
    mc "Entonces, ¿por qué estaba allí mi amiga desaparecida, con aspecto de zombi?"

# game/dia2.rpy:1890
translate Spanish casa_pos_eventos_cfc481c3:

    # p "Except for that."
    p "Excepto por eso."

# game/dia2.rpy:1895
translate Spanish casa_pos_eventos_99fb512e:

    # narrator "You take a step back."
    narrator "Das un paso atrás."

# game/dia2.rpy:1900
translate Spanish casa_pos_eventos_20aed86d:

    # p "Don’t run away, [titulo_pierrot]..."
    p "No huyas, [titulo_pierrot!t]..."

# game/dia2.rpy:1901
translate Spanish casa_pos_eventos_cd6aa3ff:

    # p "I might end up liking pulling you back…"
    p "Puede que al final me guste traerte de vuelta..."

# game/dia2.rpy:1902
translate Spanish casa_pos_eventos_a3040945:

    # p "Just hear me out first!"
    p "¡Escúchame primero!"

# game/dia2.rpy:1910
translate Spanish casa_pos_eventos_d998733a:

    # p "Please."
    p "Por favor."

# game/dia2.rpy:1921
translate Spanish casa_pos_eventos_9ddc8cf3:

    # narrator "He gently pushes you down onto the mattress in silence."
    narrator "Te empuja suavemente sobre el colchón en silencio."

# game/dia2.rpy:1926
translate Spanish casa_pos_eventos_1607f8b6:

    # p "Thank you..."
    p "Gracias..."

# game/dia2.rpy:1930
translate Spanish casa_pos_eventos_e0fc7626:

    # p "Thank you, [titulo_pierrot]. I shall…"
    p "Gracias, [titulo_pierrot!t]. Yo…"

# game/dia2.rpy:1931
translate Spanish casa_pos_eventos_95d24da2:

    # p "I shall try to be gentle, and restrain myself for your sake, is that alright?"
    p "Intentaré ser delicado y contenerme por ti, ¿está bien?"

# game/dia2.rpy:1946
translate Spanish casa_pos_eventos_489bca7a:

    # narrator "You feel him grab your wrist firmly and throw you onto the bed"
    narrator "Sientes que te agarra la muñeca con firmeza y te tira sobre la cama."

# game/dia2.rpy:1948
translate Spanish casa_pos_eventos_c1a02603:

    # p "Sorry!!"
    p "¡¡Lo siento!!"

# game/dia2.rpy:1954
translate Spanish casa_pos_eventos_d2d74980:

    # p "{sc=1}{color=#ffaf54}Forgive me! Do not…{w=0.2} run,{w=0.2} [titulo_pierrot]…"
    p "{sc=1}{color=#ffaf54}¡Perdóname! No…{w=0.2} huyas,{w=0.2} [titulo_pierrot!t]…"

# game/dia2.rpy:1955
translate Spanish casa_pos_eventos_d9e31109:

    # p "I cannot allow you to flee with such frightened eyes."
    p "No puedo permitir que huyas con ojos tan asustados."

# game/dia2.rpy:1958
translate Spanish casa_pos_eventos_93ef7c01:

    # p "I feel your fear, as if I could taste its sweetness with my tongue."
    p "Siento tu miedo, como si pudiera saborear su dulzura con mi lengua."

# game/dia2.rpy:1959
translate Spanish casa_pos_eventos_22ebe4f3:

    # p "I see it, you know… what does that do to me?"
    p "Lo veo, ¿sabes?... ¿Y sabes lo que eso me provoca?"

# game/dia2.rpy:1960
translate Spanish casa_pos_eventos_c39417e0:

    # p "{sc=1}{color=#ffaf54}{b}It makes my body burn,{w=0.2} throb, yet it terrifies me to think..."
    p "{sc=1}{color=#ffaf54}{b}Hace que mi cuerpo arda,{w=0.2} palpite, pero me aterroriza pensar..."

# game/dia2.rpy:1961
translate Spanish casa_pos_eventos_75af074b:

    # p "{sc=2}{color=#ffaf54}...You might no longer be able to look at me."
    p "{sc=2}{color=#ffaf54}...Es posible que ya no puedas mirarme."

# game/dia2.rpy:1962
translate Spanish casa_pos_eventos_2becd25e:

    # p "{sc=1}{color=#ffaf54}It makes me want to hold you tighter, to break you with my heat."
    p "{sc=1}{color=#ffaf54}Me dan ganas de abrazarte más fuerte, de romperte con mi calor."

# game/dia2.rpy:1963
translate Spanish casa_pos_eventos_5180d72c:

    # p "{sc=0.5}{color=#ffaf54}Until you forget that anything else in the world exists {b}besides me!"
    p "{sc=0.5}{color=#ffaf54}¡Hasta que olvides que existe cualquier otra cosa en el mundo {b}además de mí!"

# game/dia2.rpy:1964
translate Spanish casa_pos_eventos_5e3f615f:

    # p "{sc=2.5}{color=#ffaf54}Suffocating every thought of yours with my presence."
    p "{sc=2.5}{color=#ffaf54}Ahogando cada pensamiento tuyo con mi presencia."

# game/dia2.rpy:1965
translate Spanish casa_pos_eventos_b781419b:

    # p "{sc=2}{color=#ffaf54}And your eyes cling to my image as much..."
    p "{sc=2}{color=#ffaf54}Y tus ojos se aferran tanto a mi imagen..."

# game/dia2.rpy:1966
translate Spanish casa_pos_eventos_7084d8ec:

    # p "{b}{size=35}As I want to cling to you right now."
    p "{b}{size=35}Como quiero aferrarme a ti ahora mismo."

# game/dia2.rpy:1968
translate Spanish casa_pos_eventos_9df3c1c2:

    # p "If you run again, I don’t know if I could stop…{w=0.2} not again…"
    p "Si vuelves a huir, no sé si podría parar…{w=0.2} otra vez no…"

# game/dia2.rpy:1969
translate Spanish casa_pos_eventos_1eb126e9:

    # p "{sc=1}{color=#ffaf54}{b}Would that make you scream?"
    p "{sc=1}{color=#ffaf54}{b}¿Eso te haría gritar?"

# game/dia2.rpy:1971
translate Spanish casa_pos_eventos_dd523681:

    # p "I could end up addicted to pulling you {b}harder and harder until you surrender…"
    p "Podría terminar volviéndome adicto a arrastrarte {b}cada vez con más fuerza hasta que te rindas..."

# game/dia2.rpy:1972
translate Spanish casa_pos_eventos_30402c52:

    # p "{sc=1}{color=#ffaf54}But I also want so much to see you stay..."
    p "{sc=1}{color=#ffaf54}Pero también tengo muchas ganas de verte quedarte..."

# game/dia2.rpy:1973
translate Spanish casa_pos_eventos_e3ec981a:

    # p "{sc=1}{color=#ffaf54}Stay... because you want me too…"
    p "{sc=1}{color=#ffaf54}Quédate... porque tú también me quieres..."

# game/dia2.rpy:1974
translate Spanish casa_pos_eventos_61f179ae:

    # p "I could do anything for you if you gave me the chance!"
    p "¡Podría hacer cualquier cosa por ti si me dieras la oportunidad!"

# game/dia2.rpy:1975
translate Spanish casa_pos_eventos_d4af5ba7:

    # p "{b}Even if I had to crawl through darkness until I lose my mind."
    p "{b}Incluso si tuviera que arrastrarme a través de la oscuridad hasta perder la cabeza."

# game/dia2.rpy:1976
translate Spanish casa_pos_eventos_c94c1875:

    # p "{b}And set the rest of the world on fire."
    p "{b}Y prender fuego al resto del mundo."

# game/dia2.rpy:1978
translate Spanish casa_pos_eventos_d01164ff:

    # narrator "You feel his breath, heavy against you. His hands tremble slightly, as if he’s holding himself back."
    narrator "Sientes su aliento, pesado contra ti. Sus manos tiemblan ligeramente, como si se estuviera conteniendo."

# game/dia2.rpy:1980
translate Spanish casa_pos_eventos_dad040f4:

    # mcp "{cps=20}(Pierrot… something inside him feels so broken.)"
    mcp "{cps=20}(Pierrot... algo dentro de él se siente tan roto.)"

# game/dia2.rpy:1982
translate Spanish casa_pos_eventos_1300dce2:

    # mcp "{cps=20}(It’s beautiful…{w=0.2} but also sad.)"
    mcp "{cps=20}(Es hermoso…{w=0.2} pero también triste.)"

# game/dia2.rpy:1984
translate Spanish casa_pos_eventos_41cae181:

    # p "I can’t tell you anything about your friend right now, but if you want her…"
    p "No puedo decirte nada sobre tu amiga ahora mismo, pero si la quieres…"

# game/dia2.rpy:1985
translate Spanish casa_pos_eventos_43018c15:

    # p "I… I’ll bring her back to you.{w=0.2} Just not now."
    p "Yo... te la traeré de vuelta.{w=0.2} Pero ahora no."

# game/dia2.rpy:1986
translate Spanish casa_pos_eventos_803a714f:

    # p "Because {b}he{/b} saw you looking at her too much."
    p "Porque {b}él{/b} te vio mirándola demasiado."

# game/dia2.rpy:1988
translate Spanish casa_pos_eventos_81cb658e:

    # mc "Pierrot, what’s happening in that place?"
    mc "Pierrot, ¿qué está pasando en ese lugar?"

# game/dia2.rpy:1994
translate Spanish casa_pos_eventos_01a07668:

    # p "I can’t say. If you know more, they’ll get suspicious."
    p "No puedo decirlo. Si sabes más, sospecharán."

# game/dia2.rpy:1995
translate Spanish casa_pos_eventos_f61923d6:

    # p "I don’t want them coming after you, so the less you know, the less your eyes will give you away to them."
    p "No quiero que vengan tras de ti, así que cuanto menos sepas, menos te delatarán tus ojos."

# game/dia2.rpy:1997
translate Spanish casa_pos_eventos_ce267208:

    # narrator "You feel your heart racing."
    narrator "Sientes que tu corazón se acelera."

# game/dia2.rpy:1999
translate Spanish casa_pos_eventos_313676ca:

    # mcp "(Them?)"
    mcp "(¿Ellos?)"

# game/dia2.rpy:2001
translate Spanish casa_pos_eventos_07def51f:

    # p "Your heart’s racing… such a sweet sound…"
    p "Tu corazón está acelerado... un sonido tan dulce..."

# game/dia2.rpy:2002
translate Spanish casa_pos_eventos_725dbfd9:

    # p "Trust me, [titulo_pierrot], I know you’re scared, but you need to go back to the circus today."
    p "Confía en mí, [titulo_pierrot!t], sé que tienes miedo, pero necesitas volver al circo hoy."

# game/dia2.rpy:2004
translate Spanish casa_pos_eventos_1249dd13:

    # mc "{b}What?? Are you serious? After all this??" with vpunch
    mc "{b}¿¿Qué?? ¿Hablas en serio? ¿¿Después de todo esto??" with vpunch

# game/dia2.rpy:2006
translate Spanish casa_pos_eventos_b55e3f25:

    # p "I know, I know. But if you don’t go today, {b}he{/b}’ll remember."
    p "Lo sé, lo sé. Pero si no vas hoy, {b}él{/b} lo recordará."

# game/dia2.rpy:2007
translate Spanish casa_pos_eventos_a3f39cf2:

    # p "The others will get suspicious, and they’ll come for you anyway."
    p "Los demás sospecharán y vendrán a por ti de todos modos."

# game/dia2.rpy:2008
translate Spanish casa_pos_eventos_5b9f612e:

    # p "B-but as long as you have my red ticket, you’ll be fine!"
    p "P-pero mientras tengas mi boleto rojo, ¡estarás bien!"

# game/dia2.rpy:2009
translate Spanish casa_pos_eventos_64a4ef73:

    # p "Just keep it with you and walk around the circus."
    p "Guárdalo contigo y camina por el circo."

# game/dia2.rpy:2010
translate Spanish casa_pos_eventos_e5f4b3dc:

    # p "You don’t even need to go on the rides if you don’t want to!"
    p "¡Ni siquiera necesitas subir a las atracciones si no quieres!"

# game/dia2.rpy:2012
translate Spanish casa_pos_eventos_5d8e0b90:

    # mc "{cps=5}{i}Sigh…{/i}{/cps}{w=0.2}\nPierrot…"
    mc "{cps=5}{i}Suspiro…{/i}{/cps}{w=0.2}\nPierrot…"

# game/dia2.rpy:2014
translate Spanish casa_pos_eventos_97606d77:

    # mcp "(Even after everything, it’s hard to stay mad at him)"
    mcp "(Incluso después de todo, es difícil seguir enojad[letra] con él.)"

# game/dia2.rpy:2015
translate Spanish casa_pos_eventos_0fa7f2e6:

    # mcp "(He really seems to be trying to protect me from something.)"
    mcp "(Realmente parece estar tratando de protegerme de algo)."

# game/dia2.rpy:2017
translate Spanish casa_pos_eventos_e7f6ab96:

    # mc "Why are you doing all this?"
    mc "¿Por qué estás haciendo todo esto?"

# game/dia2.rpy:2020
translate Spanish casa_pos_eventos_ae692f25:

    # voice "audio/dublagem/pierrot1.mp3"
    # p "Why?? Hah…"
    voice "audio/dublagem/pierrot1.mp3"
    p "¿Por qué? Jaja…"

# game/dia2.rpy:2025
translate Spanish casa_pos_eventos_d56c65bd:

    # voice "audio/dublagem/pierrot2.mp3"
    # p "{b}{cps=0}Because I love you, [titulo_pierrot]!!"
    voice "audio/dublagem/pierrot2.mp3"
    p "{b}{cps=0}¡¡Porque te amo, [titulo_pierrot!t]!!"

# game/dia2.rpy:2027
translate Spanish casa_pos_eventos_858bbaec:

    # voice "audio/dublagem/pierrot3.mp3"
    # p "{sc=2}{color=#ffaf54}{cps=100}I love you, I love you! I love you so much it hurts, it burns!!"
    voice "audio/dublagem/pierrot3.mp3"
    p "{sc=2}{color=#ffaf54}{cps=100}¡Te amo, te amo! ¡¡Te amo tanto que duele, quema!!"

# game/dia2.rpy:2029
translate Spanish casa_pos_eventos_4d54f9ab:

    # p "{sc=2}{color=#ffaf54}{cps=100}Like hellfire in my chest!"
    p "{sc=2}{color=#ffaf54}{cps=100}¡Como fuego del infierno en mi pecho!"

# game/dia2.rpy:2030
translate Spanish casa_pos_eventos_25b6bb93:

    # p "{sc=2}{color=#ffaf54}{cps=100}When your eyes met mine that day."
    p "{sc=2}{color=#ffaf54}{cps=100}Cuando tus ojos se encontraron con los míos ese día."

# game/dia2.rpy:2031
translate Spanish casa_pos_eventos_46f189af:

    # p "{sc=2}{color=#ffaf54}{cps=100}It was like my whole existence was screaming for you!!"
    p "{sc=2}{color=#ffaf54}{cps=100}¡¡Era como si toda mi existencia estuviera gritando por ti!!"

# game/dia2.rpy:2032
translate Spanish casa_pos_eventos_e2357b45:

    # p "{sc=2}{color=#ffaf54}{cps=100}Screaming your name, [mc_nome]!"
    p "{sc=2}{color=#ffaf54}{cps=100}¡Gritando tu nombre, [mc_nome]!"

# game/dia2.rpy:2033
translate Spanish casa_pos_eventos_3f75a045:

    # p "{sc=2}{color=#ffaf54}{cps=100}So loud and desperate it echoed through my soul!!"
    p "{sc=2}{color=#ffaf54}{cps=100}¡¡Tan fuerte y desesperado que resonó en mi alma!!"

# game/dia2.rpy:2034
translate Spanish casa_pos_eventos_da61d6a3:

    # p "{sc=2}{color=#ffaf54}{cps=100}You felt it, didn’t you?? Please-- {nw=1.0}"
    p "{sc=2}{color=#ffaf54}{cps=100}Lo sentiste, ¿no? Por favor-- {nw=1.0}"

# game/dia2.rpy:2040
translate Spanish casa_pos_eventos_d57a00a9:

    # mc "{size=50}{cps=10}..."
    mc "{size=50}{cps=10}..."

# game/dia2.rpy:2041
translate Spanish casa_pos_eventos_06e0c309:

    # mcp "(It’s still too soon for me to answer that, I need a little time after all this madness.)"
    mcp "(Aún es demasiado pronto para responder eso, necesito un poco de tiempo después de toda esta locura)."

# game/dia2.rpy:2044
translate Spanish casa_pos_eventos_135cbde2:

    # p "You’re blushing…"
    p "Te estás sonrojando..."

# game/dia2.rpy:2045
translate Spanish casa_pos_eventos_36d0e144:

    # p "Did my words… reach you, [titulo_pierrot]?"
    p "¿Mis palabras… llegaron a ti, [titulo_pierrot!t]?"

# game/dia2.rpy:2046
translate Spanish casa_pos_eventos_b253529c:

    # mc "You’re intense, did you know that?"
    mc "Eres intenso, ¿lo sabías?"

# game/dia2.rpy:2047
translate Spanish casa_pos_eventos_7f6e6542:

    # p "I didn’t mean to embarrass you, [mc_nome]."
    p "No quise avergonzarte, [mc_nome]."

# game/dia2.rpy:2048
translate Spanish casa_pos_eventos_921efa70:

    # p "Do you want me to leave, give you some space?"
    p "¿Quieres que me vaya, te dé un poco de espacio?"

# game/dia2.rpy:2049
translate Spanish casa_pos_eventos_80cbda5e:

    # p "I know you need to calm down for tonight."
    p "Sé que necesitas calmarte para esta noche."

# game/dia2.rpy:2054
translate Spanish casa_pos_eventos_438f1002:

    # mc "I think I need a little time to think…"
    mc "Creo que necesito un poco de tiempo para pensar..."

# game/dia2.rpy:2056
translate Spanish casa_pos_eventos_3c3a0213:

    # p "Alright, I can give you that."
    p "Muy bien, puedo darte eso."

# game/dia2.rpy:2057
translate Spanish casa_pos_eventos_349ca646:

    # p "I’ll see you there…"
    p "Te veré allí..."

# game/dia2.rpy:2064
translate Spanish casa_pos_eventos_c49d3b70:

    # mc "I’ll be there, Pierrot."
    mc "Allí estaré, Pierrot."

# game/dia2.rpy:2065
translate Spanish casa_pos_eventos_87a3d19d:

    # p "Thank you, [titulo_pierrot]."
    p "Gracias, [titulo_pierrot!t]."

# game/dia2.rpy:2073
translate Spanish casa_pos_eventos_ede16c72:

    # narrator "He opens the balcony door as if it were the front door and steps outside."
    narrator "Abre la puerta del balcón como si fuera la puerta de entrada y sale."

# game/dia2.rpy:2075
translate Spanish casa_pos_eventos_3250b2bf:

    # mc "Pierrot? We’re on the second floor!"
    mc "¿Pierrot? ¡Estamos en el segundo piso!"

# game/dia2.rpy:2082
translate Spanish casa_pos_eventos_2a953421:

    # mc "Yeah, of course… he just jumped."
    mc "Sí, por supuesto… simplemente saltó."

# game/dia2.rpy:2083
translate Spanish casa_pos_eventos_aba1a970:

    # mc "I shouldn’t even be surprised."
    mc "Ni siquiera debería sorprenderme."

# game/dia2.rpy:2089
translate Spanish casa_pos_eventos_38316076:

    # mc "You can stay, I guess… Just…"
    mc "Puedes quedarte, supongo... Sólo..."

# game/dia2.rpy:2090
translate Spanish casa_pos_eventos_934e0f1a:

    # mc "Stay quiet while I try to get my head straight, okay?"
    mc "Quédate callado mientras intento aclarar mis ideas, ¿vale?"

# game/dia2.rpy:2094
translate Spanish casa_pos_eventos_f33004a9:

    # narrator "He smiles brightly and jumps onto you, resting against your chest."
    narrator "Él sonríe alegremente y salta sobre ti, descansando contra tu pecho."

# game/dia2.rpy:2097
translate Spanish casa_pos_eventos_b7f261f9:

    # p "Very well, I’ll be quiet again, anything you wish [titulo_pierrot]!"
    p "Muy bien, volveré a quedarme callado, ¡lo que desees, [titulo_pierrot!t]!"

# game/dia2.rpy:2099
translate Spanish casa_pos_eventos_33a49892:

    # narrator "He rubs his face against you, while his body slowly relaxes at the sound of your heartbeat."
    narrator "Frota su rostro contra ti, mientras su cuerpo se relaja lentamente ante el sonido de los latidos de tu corazón."

# game/dia2.rpy:2111
translate Spanish casa_pos_eventos_459ae23a:

    # mcp "(Huh? There’s something… weird under his hat.)"
    mcp "(¿Eh? Hay algo... extraño debajo de su sombrero.)"

# game/dia2.rpy:2113
translate Spanish casa_pos_eventos_c00f45a3:

    # narrator "His body tenses over yours, and he practically holds his breath."
    narrator "Su cuerpo se tensa sobre el tuyo y prácticamente contiene la respiración."

# game/dia2.rpy:2115
translate Spanish casa_pos_eventos_ec6f56c3:

    # mc "Sorry, I won’t do that again."
    mc "Lo siento, no volveré a hacer eso."

# game/dia2.rpy:2117
translate Spanish casa_pos_eventos_c7e0b2ee:

    # mcp "(His scent is so subtle and pleasant...)"
    mcp "(Su aroma es tan sutil y agradable...)"

# game/dia2.rpy:2122
translate Spanish casa_pos_eventos_4c4dfde3:

    # mcp "(Things have gotten kinda crazy ever since Pierrot showed up.)"
    mcp "(Las cosas se han vuelto un poco locas desde que apareció Pierrot)."

# game/dia2.rpy:2125
translate Spanish casa_pos_eventos_91f2c36a:

    # mcp "(He kidnapped me, but that doesn’t bother me, I can feel he didn’t do anything besides tying me up.)"
    mcp "(Me secuestró, pero eso no me molesta. Siento que no hizo nada más que atarme.)"

# game/dia2.rpy:2126
translate Spanish casa_pos_eventos_28f7585d:

    # mcp "(And now he seems like he’s trying to protect me.)"
    mcp "(Y ahora parece que está tratando de protegerme)."

# game/dia2.rpy:2127
translate Spanish casa_pos_eventos_124f32c6:

    # mcp "(Even though he looks pretty unstable at times. Should I really trust him?)"
    mcp "(Aunque a veces parece bastante inestable. ¿Realmente debería confiar en él?)"

# game/dia2.rpy:2130
translate Spanish casa_pos_eventos_5397ad48:

    # mcp "(I really felt a strange danger when Harlequin pulled me, but Pierrot showed up to \"defend me\".)"
    mcp "(Realmente sentí un peligro extraño cuando Arlequín tiró de mí, pero Pierrot apareció para \"defenderme\".)"

# game/dia2.rpy:2131
translate Spanish casa_pos_eventos_86b23640:

    # mcp "(I still don’t know what’s up with Harlequin… that mysterious guy.)"
    mcp "(Aún no sé qué le pasa a Arlequín… ese tipo misterioso)."

# game/dia2.rpy:2132
translate Spanish casa_pos_eventos_d4baaf53:

    # mcp "(He doesn’t have Pierrot’s sweet warmth. He’s more like an icy shiver running down my spine.)"
    mcp "(No tiene la dulce calidez de Pierrot. Es más como un escalofrío helado que recorre mi espalda)."

# game/dia2.rpy:2133
translate Spanish casa_pos_eventos_4a53598b:

    # mcp "(And… pulling my body toward him. Do I like that?)"
    mcp "(Y… acercando mi cuerpo hacia él. ¿Me gusta eso?)"

# game/dia2.rpy:2136
translate Spanish casa_pos_eventos_1ee6d959:

    # mcp "(Carol was there, but those eyes, the way she talked, it wasn’t anything like her usual self.)"
    mcp "(Carol estaba allí, pero esos ojos, la forma en que hablaba, no se parecía en nada a su yo habitual)."

# game/dia2.rpy:2137
translate Spanish casa_pos_eventos_9bc9e196:

    # mcp "(And the way that ticket guy pulled her away? Something’s really off.)"
    mcp "(¿Y la forma en que el tipo de los boletos se la llevó? Algo está realmente mal)."

# game/dia2.rpy:2138
translate Spanish casa_pos_eventos_96dae5ae:

    # mcp "(Maybe those disappearances do have something to do with the circus after all.)"
    mcp "(Quizás esas desapariciones tengan algo que ver con el circo después de todo)."

# game/dia2.rpy:2139
translate Spanish casa_pos_eventos_8ab635cf:

    # mcp "(Pierrot and Harlequin, are they actually dangerous?)"
    mcp "(Pierrot y Arlequín, ¿son realmente peligrosos?)"

# game/dia2.rpy:2141
translate Spanish casa_pos_eventos_4f21e246:

    # mc "{i}Sighs..."
    mc "{i}Suspira..."

# game/dia2.rpy:2143
translate Spanish casa_pos_eventos_df5d4a7c:

    # mcp "(I don’t know why those two suddenly seem so interested in me.)"
    mcp "(No sé por qué esos dos de repente parecen tan interesados en mí)."

# game/dia2.rpy:2144
translate Spanish casa_pos_eventos_8ab6b3b7:

    # mcp "(But I’ll wait a little longer before deciding anything about them.)"
    mcp "(Pero esperaré un poco más antes de decidir algo sobre ellos)."

# game/dia2.rpy:2145
translate Spanish casa_pos_eventos_4eb863db:

    # mcp "(First, I’ll do what Pierrot asked and go to the circus tonight.)"
    mcp "(Primero, haré lo que Pierrot me pidió e iré al circo esta noche)."

# game/dia2.rpy:2146
translate Spanish casa_pos_eventos_fa311e52:

    # mcp "(And then I can think about what to do about… those two.)"
    mcp "(Y luego puedo pensar en qué hacer con... esos dos)."

# game/dia2.rpy:2148
translate Spanish casa_pos_eventos_b7c4c7b5:

    # mc "I’ve got so many questions…"
    mc "Tengo tantas preguntas..."

# game/dia2.rpy:2159
translate Spanish casa_pos_eventos_a55e9de3:

    # p "I know."
    p "Lo sé."

# game/dia2.rpy:2161
translate Spanish casa_pos_eventos_db97da53:

    # mc "Alright, I guess we can go and just get this over with."
    mc "Muy bien, supongo que podemos irnos y terminar con esto de una vez."

# game/dia2.rpy:2162
translate Spanish casa_pos_eventos_abc8486d:

    # p "Very well."
    p "Muy bien."

# game/dia2.rpy:2168
translate Spanish casa_pos_eventos_a58a3315:

    # p "What?..."
    p "¿Qué?..."

# game/dia2.rpy:2171
translate Spanish casa_pos_eventos_c6848a76:

    # p "He… marked you."
    p "Él… te marcó."

# game/dia2.rpy:2173
translate Spanish casa_pos_eventos_50a20e43:

    # narrator "You run your hand over your neck, remembering that awkward bite."
    narrator "Pasas tu mano por tu cuello, recordando ese incómodo mordisco."

# game/dia2.rpy:2175
translate Spanish casa_pos_eventos_ef56bf79:

    # mc "A-ah… well..."
    mc "A-ah... bueno..."

# game/dia2.rpy:2177
translate Spanish casa_pos_eventos_d3d94021:

    # p "{cps=15}May I…{w=0.5} cover it?"
    p "{cps=15}¿Puedo…{w=0.5} cubrirlo?"

# game/dia2.rpy:2179
translate Spanish casa_pos_eventos_48f85d25:

    # mc "Cover it? I--{nw=0.5}"
    mc "¿Cubrirlo? Yo--{nw=0.5}"

# game/dia2.rpy:2181
translate Spanish casa_pos_eventos_ce5cb54d:

    # p "With my mark. Let me replace his with mine."
    p "Con mi marca. Déjame reemplazar la suya por la mía."

# game/dia2.rpy:2182
translate Spanish casa_pos_eventos_2cfb25b6:

    # mc "Pierrot, are you seriously asking me to let you bite me?"
    mc "Pierrot, ¿en serio me estás pidiendo que te deje morderme?"

# game/dia2.rpy:2187
translate Spanish casa_pos_eventos_3b88c420:

    # p "Yes."
    p "Sí."

# game/dia2.rpy:2189
translate Spanish casa_pos_eventos_c130cc26:

    # mc "That was pretty direct."
    mc "Eso fue bastante directo."

# game/dia2.rpy:2190
translate Spanish casa_pos_eventos_0acec709:

    # mc "Is this really that important to you?"
    mc "¿Es esto realmente tan importante para ti?"

# game/dia2.rpy:2193
translate Spanish casa_pos_eventos_c6329147:

    # narrator "He nods."
    narrator "Él asiente."

# game/dia2.rpy:2199
translate Spanish casa_pos_eventos_6d0f60ff:

    # p "If it hurts too much, you can ask me to stop [titulo_pierrot]."
    p "Si te duele demasiado, puedes pedirme que pare, [titulo_pierrot!t]."

# game/dia2.rpy:2202
translate Spanish casa_pos_eventos_30ce0797:

    # mcp "(Ugh… He’s got way too sharp teeth.)"
    mcp "(Uf... Tiene dientes demasiado afilados)."

# game/dia2.rpy:2203
translate Spanish casa_pos_eventos_7999c4e7:

    # mcp "(Ok, that’s hurting more now!!!)"
    mcp "(Vale, ¡¡¡eso duele más ahora!!!)"

# game/dia2.rpy:2204
translate Spanish casa_pos_eventos_b8293261:

    # mc "Pierrot!?" with vpunch
    mc "¿¡Pierrot!?" with vpunch

# game/dia2.rpy:2212
translate Spanish casa_pos_eventos_d9099435:

    # p "I apologize..."
    p "Pido disculpas..."

# game/dia2.rpy:2213
translate Spanish casa_pos_eventos_78ed72df:

    # p "Now, when you feel that warmth on your neck..."
    p "Ahora, cuando sientas ese calor en tu cuello..."

# game/dia2.rpy:2218
translate Spanish casa_pos_eventos_ce16b817:

    # p "You’ll remember {b}me{/b}, not him."
    p "Te acordarás de {b}mí{/b}, no de él."

# game/dia2.rpy:2219
translate Spanish casa_pos_eventos_3c672813:

    # mc "S-Sure, I guess."
    mc "C-claro, supongo."

# game/dia2.rpy:2223
translate Spanish casa_pos_eventos_8377ac48:

    # mc "I better not…"
    mc "Mejor no..."

# game/dia2.rpy:2224
translate Spanish casa_pos_eventos_bafb8629:

    # mc "I can’t go around with marks on my neck. I’ll cover it with something."
    mc "No puedo andar con marcas en el cuello. Lo cubriré con algo."

# game/dia2.rpy:2228
translate Spanish casa_pos_eventos_f22a4222:

    # p "{b}{color=#ff0000}He’ll pay for this…"
    p "{b}{color=#ff0000}Él pagará por esto..."

# game/dia2.rpy:2236
translate Spanish casa_pos_eventos_17429880:

    # mcp "(I’ve never heard him sound this furious before.)"
    mcp "(Nunca antes lo había oído sonar tan furioso.)"

# game/dia2.rpy:2238
translate Spanish casa_pos_eventos_5127b959:

    # mc "Well, it’s time to go."
    mc "Bueno, es hora de irse."

# game/dia2.rpy:2244
translate Spanish casa_pos_eventos_cab47f87:

    # p "I’ll follow you from a distance, [titulo_pierrot], and as soon as my performance is over."
    p "Te seguiré desde lejos, [titulo_pierrot!t]. En cuanto termine mi actuación..."

# game/dia2.rpy:2245
translate Spanish casa_pos_eventos_ba3cc3f9:

    # p "I’ll come to you."
    p "Iré a buscarte."

# game/dia2.rpy:2254
translate Spanish casa_pos_eventos_4808f520:

    # mc "Alright, you owe me a lot of explanations."
    mc "Muy bien, me debes muchas explicaciones."

# game/dia2.rpy:2255
translate Spanish casa_pos_eventos_19c4ec35:

    # mc "So, see you there."
    mc "Así que nos vemos allí."

# game/dia2.rpy:2256
translate Spanish casa_pos_eventos_65b58efb:

    # p "See you my love."
    p "Nos vemos, mi amor."

# game/dia2.rpy:2264
translate Spanish casa_pos_eventos_3250b2bf_1:

    # mc "Pierrot? We’re on the second floor!"
    mc "¿Pierrot? ¡Estamos en el segundo piso!"

# game/dia2.rpy:2266
translate Spanish casa_pos_eventos_2a953421_1:

    # mc "Yeah, of course… he just jumped."
    mc "Sí, por supuesto… simplemente saltó."

# game/dia2.rpy:2267
translate Spanish casa_pos_eventos_aba1a970_1:

    # mc "I shouldn’t even be surprised."
    mc "Ni siquiera debería sorprenderme."

# game/dia2.rpy:2289
translate Spanish visita_arlequim_1da2fafb:

    # a "Finally he’s gone."
    a "Finalmente se ha ido."

# game/dia2.rpy:2291
translate Spanish visita_arlequim_28a3bac1:

    # a "It was almost cruel of you not to ask more about me, [titulo_arlequim]."
    a "Fue casi cruel de tu parte no preguntar más por mí, [titulo_arlequim!t]."

# game/dia2.rpy:2299
translate Spanish visita_arlequim_b9ad5f9a:

    # mc "I’m sorry! I got scared."
    mc "¡Lo lamento! Me asusté."

# game/dia2.rpy:2300
translate Spanish visita_arlequim_95c7633a:

    # mc "Are you okay?"
    mc "¿Estás bien?"

# game/dia2.rpy:2305
translate Spanish visita_arlequim_f3cdc0a8:

    # a "How sweet, worried about me?"
    a "Qué dulce, ¿preocupad[letra] por mí?"

# game/dia2.rpy:2307
translate Spanish visita_arlequim_19805236:

    # mc "What do you think??"
    mc "¿¿Tú qué crees??"

# game/dia2.rpy:2309
translate Spanish visita_arlequim_0d25a6cd:

    # a "Hah.. That sounds so sweet coming from your mouth."
    a "Ja... Eso suena tan dulce viniendo de tu boca."

# game/dia2.rpy:2314
translate Spanish visita_arlequim_bbde2c2d:

    # a "But I hate sweets."
    a "Pero odio los dulces."

# game/dia2.rpy:2315
translate Spanish visita_arlequim_ebcfc37d:

    # a "Though I might make an exception and taste yours ♪"
    a "Aunque podría hacer una excepción y probar el tuyo ♪"

# game/dia2.rpy:2317
translate Spanish visita_arlequim_1cf1abe8:

    # mc "I’m serious, you pervert!!"
    mc "¡¡Lo digo en serio, pervertido!!"

# game/dia2.rpy:2318
translate Spanish visita_arlequim_8f95dd0b:

    # mcp "(He seems on edge this time.)"
    mcp "(Esta vez parece nervioso.)"

# game/dia2.rpy:2322
translate Spanish visita_arlequim_0db12e1c:

    # a "Huhum, now you’re almost convincing me, [titulo_arlequim]."
    a "Huhum, ahora casi me convences, [titulo_arlequim!t]."

# game/dia2.rpy:2324
translate Spanish visita_arlequim_b85d18db:

    # mc "{size=50}..."
    mc "{size=50}..."

# game/dia2.rpy:2328
translate Spanish visita_arlequim_33cf41a4:

    # a "Oh, {i}that look! And if I said I believe those sweet little words."
    a "¡Oh, {i}esa mirada! Y si dijera que creo en esas dulces palabritas."

# game/dia2.rpy:2329
translate Spanish visita_arlequim_06fcaabf:

    # a "You gonna spread nice and wide for me, huh?"
    a "¿Te abrirás de par en par para mí, eh?"

# game/dia2.rpy:2331
translate Spanish visita_arlequim_a26ba8ee:

    # mc "Uhn… You really don’t believe a word of it."
    mc "Uhn... Realmente no crees ni una palabra de eso."

# game/dia2.rpy:2332
translate Spanish visita_arlequim_5f70cbad:

    # mc "Alright, this isn’t going anywhere."
    mc "Muy bien, esto no va a ninguna parte."

# game/dia2.rpy:2340
translate Spanish visita_arlequim_3ac1ab23:

    # a "Quê?"
    a "¿Qué?"

# game/dia2.rpy:2342
translate Spanish visita_arlequim_66c8b279:

    # mc "Are you okay? I saw blood. I got really worried."
    mc "¿Estás bien? Vi sangre. Me preocupé mucho."

# game/dia2.rpy:2347
translate Spanish visita_arlequim_5220d59f:

    # a "Ah? Worried about me? Huhum. ♪"
    a "¿Oh? ¿Preocupad[letra] por mí? Huhum. ♪"

# game/dia2.rpy:2349
translate Spanish visita_arlequim_b85d18db_1:

    # mc "{size=50}..."
    mc "{size=50}..."

# game/dia2.rpy:2350
translate Spanish visita_arlequim_4d219439:

    # mcp "(There’s something weird when I hug him... it feels like there’s something raised under the fabric.)"
    mcp "(Hay algo raro cuando lo abrazo... se siente como si hubiera algo levantado debajo de la tela.)"

# game/dia2.rpy:2351
translate Spanish visita_arlequim_a3163b87:

    # mcp "(I... don’t know what it is. It’s not hard like bones.)"
    mcp "(Yo… no sé qué es. No es duro como los huesos.)"

# game/dia2.rpy:2352
translate Spanish visita_arlequim_51695a6d:

    # mcp "(And he smells so good.)"
    mcp "(Y huele tan bien)."

# game/dia2.rpy:2354
translate Spanish visita_arlequim_73954fbb:

    # a "Are you really serious?"
    a "¿Hablas realmente en serio?"

# game/dia2.rpy:2355
translate Spanish visita_arlequim_eb0cfe4e:

    # a "A few stabs aren’t gonna stop me, [titulo_arlequim]. This is just child’s play."
    a "Un par de puñaladas no me detendrán, [titulo_arlequim!t]. Esto es un juego de niños."

# game/dia2.rpy:2357
translate Spanish visita_arlequim_0a22174e:

    # a "You can let me go now."
    a "Puedes dejarme ir ahora."

# game/dia2.rpy:2358
translate Spanish visita_arlequim_2a5deb19:

    # a "You hear me?"
    a "¿Me oyes?"

# game/dia2.rpy:2361
translate Spanish visita_arlequim_da1baa40:

    # a "If you want me to touch you again so badly, we can--"
    a "Si tanto quieres que te toque de nuevo, podemos..."

# game/dia2.rpy:2362
translate Spanish visita_arlequim_90b70b4b:

    # mc "{i}Sigh..."
    mc "{i}Suspiro..."

# game/dia2.rpy:2370
translate Spanish visita_arlequim_e67fd19e:

    # mc "I think you also owe me a lot of explanations about what happened in that tent."
    mc "Creo que también me debes muchas explicaciones sobre lo que pasó en esa carpa."

# game/dia2.rpy:2378
translate Spanish visita_arlequim_8dd4ffb2:

    # a "We were just having fun, weren’t we?"
    a "Sólo nos estábamos divirtiendo, ¿no?"

# game/dia2.rpy:2379
translate Spanish visita_arlequim_12ae00c1:

    # a "Is that your way of asking to pick up where we left off?"
    a "¿Es esa tu forma de pedir continuar donde lo dejamos?"

# game/dia2.rpy:2382
translate Spanish visita_arlequim_85adb8a9:

    # mc "D-don’t change the subject! How did you even do all that?"
    mc "¡N-no cambies de tema! ¿Cómo hiciste todo eso?"

# game/dia2.rpy:2383
translate Spanish visita_arlequim_ccafa02d:

    # mc "And how are you not bleeding after being stabbed once?"
    mc "¿Y cómo no sangras después de haber sido apuñalado una vez?"

# game/dia2.rpy:2391
translate Spanish visita_arlequim_b75b5398:

    # a "Five times, actually.{nw=1.0}"
    a "Cinco veces, en realidad.{nw=1.0}"

# game/dia2.rpy:2395
translate Spanish visita_arlequim_3bb94492:

    # mc "You’ve gotta be kidding me??" with vpunch
    mc "¿Tienes que estar bromeando?" with vpunch

# game/dia2.rpy:2397
translate Spanish visita_arlequim_b9a86bc9:

    # a "Sure, I don’t need to lie."
    a "Claro, no necesito mentir."

# game/dia2.rpy:2400
translate Spanish visita_arlequim_28971304:

    # a "But you already look a little shaken today."
    a "Pero hoy ya pareces un poco conmocionad[letra]."

# game/dia2.rpy:2401
translate Spanish visita_arlequim_24df38c7:

    # a "I heard you two talking about visiting our home."
    a "Los escuché a ustedes dos hablando de visitar nuestra casa."

# game/dia2.rpy:2403
translate Spanish visita_arlequim_fc33001b:

    # mc "The circus? Yeah, Pierrot asked me to come back."
    mc "¿El circo? Sí, Pierrot me pidió que volviera."

# game/dia2.rpy:2410
translate Spanish visita_arlequim_039816f5:

    # mc "Harlequin! What happened back there?"
    mc "¡Arlequín! ¿Qué pasó allí atrás?"

# game/dia2.rpy:2413
translate Spanish visita_arlequim_4ce796a1:

    # a "He lost his mind when he couldn’t find you in the storage room, [titulo_arlequim]."
    a "Perdió la cabeza cuando no te encontró en el almacén, [titulo_arlequim!t]."

# game/dia2.rpy:2414
translate Spanish visita_arlequim_d0db2f41:

    # a "You should’ve seen the murderous look he can pull off."
    a "Deberías haber visto la mirada asesina que sabe poner."

# game/dia2.rpy:2416
translate Spanish visita_arlequim_96198a70:

    # mc "You… did you get hurt?"
    mc "Tú... ¿te lastimaste?"

# game/dia2.rpy:2418
translate Spanish visita_arlequim_020447c3:

    # narrator "He laughs, mockery dripping from his voice."
    narrator "Él se ríe, la burla goteando de su voz."

# game/dia2.rpy:2420
translate Spanish visita_arlequim_03567247:

    # mcp "(That on his glove, wasn’t blood after all?)"
    mcp "(Eso en su guante, ¿no era sangre después de todo?)"

# game/dia2.rpy:2422
translate Spanish visita_arlequim_0bc9fa3f:

    # a "Not even a \"Thank you for letting me out, Harlequin. I’m oh-so excited, just for you.\"?"
    a "¿Ni siquiera un \"Gracias por dejarme salir, Arlequín. Estoy tan emocionad[letra], solo por ti\"?"

# game/dia2.rpy:2424
translate Spanish visita_arlequim_1ae9a871:

    # mc "I think it’s pretty clear you didn’t let me go out of kindness. You just wanted to piss Pierrot off."
    mc "Creo que está bastante claro que no me dejaste ir por amabilidad. Sólo querías cabrear a Pierrot."

# game/dia2.rpy:2428
translate Spanish visita_arlequim_4ab51b81:

    # a "Ah, yes ♪ I’m starting to think we’d make a deliciously wicked pair."
    a "Ah, sí ♪ Estoy empezando a pensar que haríamos una pareja deliciosamente perversa."

# game/dia2.rpy:2429
translate Spanish visita_arlequim_397d2826:

    # a "With a little help from you, the two of us could drive him mad, [titulo_arlequim]."
    a "Con un poquito de tu ayuda, tú y yo podríamos volverlo loco, [titulo_arlequim!t]."

# game/dia2.rpy:2431
translate Spanish visita_arlequim_26c6a5af:

    # mc "God, what’s wrong with you."
    mc "Dios, ¿qué te pasa?"

# game/dia2.rpy:2436
translate Spanish visita_arlequim_b980e148:

    # a "Don’t lie to me, [mc_nome] weren’t we having fun?"
    a "No me mientas, [mc_nome]. ¿No nos estábamos divirtiendo?"

# game/dia2.rpy:2438
translate Spanish visita_arlequim_73632e4c:

    # mc "Your idea of fun is playing with a knife against my skin?"
    mc "¿Tu idea de diversión es jugar con un cuchillo contra mi piel?"

# game/dia2.rpy:2444
translate Spanish visita_arlequim_5120c57e:

    # a "My idea of fun is making you moan and shiver, dear. You held back so well…"
    a "Mi idea de diversión es hacerte gemir y temblar, querid[letra]. Te contuviste tan bien..."

# game/dia2.rpy:2445
translate Spanish visita_arlequim_865c3363:

    # a "I almost couldn’t resist going harder."
    a "Casi no pude resistirme a ir más fuerte."

# game/dia2.rpy:2448
translate Spanish visita_arlequim_51fda1ab:

    # a "{i}Oh! I saw that. ♪"
    a "{i}¡Oh! Vi eso. ♪"

# game/dia2.rpy:2449
translate Spanish visita_arlequim_cb03cec3:

    # a "You hold your breath."
    a "Aguantas la respiración."

# game/dia2.rpy:2451
translate Spanish visita_arlequim_89e221a8:

    # mc "I’ve got so many questions. And I know you won’t answer any of them."
    mc "Tengo tantas preguntas. Y sé que no responderás a ninguna de ellas."

# game/dia2.rpy:2453
translate Spanish visita_arlequim_273e63ee:

    # a "My green tongue’s still haunting your mind, isn’t it? I told you I could show you even more."
    a "Mi lengua verde todavía ronda tu mente, ¿no? Te dije que podía mostrarte aún más."

# game/dia2.rpy:2458
translate Spanish visita_arlequim_a1fff4a3:

    # a "{cps=30}Oh, asking to see more, are we?{w=0.3} {i}Naughty{/i},{cps=20} I’m surprised. ♪"
    a "{cps=30}Oh, ¿así que estás pidiendo ver más?{w=0.3} {i}Travies[letra]{/i},{cps=20} me sorprendes. ♪"

# game/dia2.rpy:2459
translate Spanish visita_arlequim_7602eb81:

    # a "I’d love to see the look on your face, if I let you peek just a little beneath what the fabrics are hiding."
    a "Me encantaría ver la expresión de tu rostro, si te dejo mirar un poco debajo de lo que esconden las telas."

# game/dia2.rpy:2464
translate Spanish visita_arlequim_a54bc5c7:

    # a "But, patience [titulo_arlequim], that little taste is not yours this night."
    a "Pero paciencia, [titulo_arlequim!t], ese pequeño bocado no es tuyo esta noche."

# game/dia2.rpy:2470
translate Spanish visita_arlequim_9250e9d9:

    # a "Your little act of shyness, it’s adorable, but it doesn’t fool me dear."
    a "Tu pequeño acto de timidez es adorable, pero no me engaña, querid[letra]."

# game/dia2.rpy:2473
translate Spanish visita_arlequim_e885e29b:

    # a "I know exactly how my words make your body respond."
    a "Sé exactamente cómo mis palabras hacen que tu cuerpo responda."

# game/dia2.rpy:2474
translate Spanish visita_arlequim_da3bfb42:

    # a "Pierrot may have your heart, but it’s me your body wants."
    a "Pierrot puede tener tu corazón, pero soy a mí a quien tu cuerpo quiere."

# game/dia2.rpy:2477
translate Spanish visita_arlequim_cf08e7ba:

    # a "{cps=20}By the way, I overheard your little conversation."
    a "{cps=20}Por cierto, escuché tu pequeña conversación."

# game/dia2.rpy:2483
translate Spanish visita_arlequim_e6e78dc2:

    # a "He was right."
    a "Tenía razón."

# game/dia2.rpy:2484
translate Spanish visita_arlequim_e4d78af1:

    # a "For tonight, it’s better your pretty eyes don’t scream your doubts to everyone else."
    a "Por esta noche, es mejor que tus bonitos ojos no griten tus dudas a los demás."

# game/dia2.rpy:2485
translate Spanish visita_arlequim_53a3f226:

    # a "But tomorrow…"
    a "Pero mañana…"

# game/dia2.rpy:2491
translate Spanish visita_arlequim_021e0c5a:

    # voice "audio/dublagem/arlequim1.mp3"
    # a "Tomorrow, if you come chasing after me again."
    voice "audio/dublagem/arlequim1.mp3"
    a "Mañana, si vienes a perseguirme otra vez."

# game/dia2.rpy:2493
translate Spanish visita_arlequim_c43f4a10:

    # voice "audio/dublagem/arlequim2.mp3"
    # a "I’ll tell you, I’ll show you, and if you still don’t run, oh my dangerous dear."
    voice "audio/dublagem/arlequim2.mp3"
    a "Te lo diré, te lo mostraré, y si aún no huyes, oh mi peligros[letra] querid[letra]."

# game/dia2.rpy:2500
translate Spanish visita_arlequim_41be8236:

    # voice "audio/dublagem/arlequim3.mp3"
    # a "I’ll ruin you in ways that’ll make what happened in the tent look{cps=10} innocent. ♪"
    voice "audio/dublagem/arlequim3.mp3"
    a "Te arruinaré de tal manera que lo que pasó en la carpa parezca inocente. ♪"

# game/dia2.rpy:2502
translate Spanish visita_arlequim_f19cfd11:

    # a "Then our little game is going to go much further."
    a "Entonces nuestro jueguito va a llegar mucho más lejos."

# game/dia2.rpy:2503
translate Spanish visita_arlequim_72ed8aa6:

    # a "Well, have fun at the circus today, [mc_nome] {i}I know I will."
    a "Bueno, diviértete hoy en el circo, [mc_nome]. {i}Yo seguro que sí."

# game/dia2.rpy:2513
translate Spanish visita_arlequim_0a69f768:

    # mc "Sigh..."
    mc "Suspiro..."

# game/dia2.rpy:2526
translate Spanish circodoshorrores_71039cad:

    # b "Greetings, visitor. May I see your--{w=0.5} ah!"
    b "Saludos, visitante. ¿Puedo ver tu--{w=0.5} ¡ah!"

# game/dia2.rpy:2530
translate Spanish circodoshorrores_08ef9e64:

    # b "The guest with the red ticket, aren’t you?"
    b "Eres [arti] invitad[letra] del boleto rojo, ¿verdad?"

# game/dia2.rpy:2532
translate Spanish circodoshorrores_aeef71bf:

    # mcp "(Just act natural, I just need to act natural…)"
    mcp "(Solo actúa con naturalidad, solo necesito actuar con naturalidad…)"

# game/dia2.rpy:2538
translate Spanish circodoshorrores_2e657475:

    # b "{cps=10}{size=45}..."
    b "{cps=10}{size=45}..."

# game/dia2.rpy:2539
translate Spanish circodoshorrores_270cc9e3:

    # mcp "(Crap, I laid it on too thick.)"
    mcp "(Mierda, exageré demasiado.)"

# game/dia2.rpy:2543
translate Spanish circodoshorrores_ea0ab288:

    # b "Enjoy yourself, guest."
    b "Diviértete, invitad[letra]."

# game/dia2.rpy:2544
translate Spanish circodoshorrores_2d563bec:

    # b "The circus has sharp eyes, it always notices those who seek joy..."
    b "El circo tiene ojos penetrantes, siempre se fija en aquellos que buscan la alegría..."

# game/dia2.rpy:2545
translate Spanish circodoshorrores_0c52d2a6:

    # b "{cps=15}Or those who hide a {i}secret{/i} deep in their hearts."
    b "{cps=15}O aquellos que esconden un {i}secreto{/i} en lo profundo de sus corazones."

# game/dia2.rpy:2547
translate Spanish circodoshorrores_3c38ad2c:

    # mc "Ah… haha… well, I’ll, uh, wander around a bit."
    mc "Ah… jaja… bueno, daré una vuelta por ahí un poco."

# game/dia2.rpy:2548
translate Spanish circodoshorrores_0ae24751:

    # mcp "(God, he knows that I know.)"
    mcp "(Dios, él sabe que yo lo sé.)"

# game/dia2.rpy:2553
translate Spanish circodoshorrores_fcc1788a:

    # b "Should you need anything, please, do not hesitate to speak with me."
    b "Si necesitas algo, no dudes en hablar conmigo."

# game/dia2.rpy:2554
translate Spanish circodoshorrores_3ddd3a76:

    # b "And one small warning, the pink tent and the black one are beyond the bounds of your ticket."
    b "Y una pequeña advertencia, la carpa rosa y la negra están fuera de los límites de tu boleto."

# game/dia2.rpy:2555
translate Spanish circodoshorrores_8bb14fb9:

    # b "You won’t be able to enter."
    b "No podrás entrar."

# game/dia2.rpy:2557
translate Spanish circodoshorrores_606e2d02:

    # mc "Sure."
    mc "Claro."

# game/dia2.rpy:2561
translate Spanish circodoshorrores_ee63ee6d:

    # mcp "(Since I need to walk around, I’ll check out the other attractions.)"
    mcp "(Como necesito caminar, revisaré las otras atracciones)."

# game/dia2.rpy:2562
translate Spanish circodoshorrores_5ed42405:

    # mcp "(Looks like Pierrot’s show is in the middle, can’t get in.)"
    mcp "(Parece que el show de Pierrot está en el medio, no puedo entrar)."

# game/dia2.rpy:2563
translate Spanish circodoshorrores_aa41af60:

    # mcp "(The Harlequin show’s already over, maybe there’ll be another later.)"
    mcp "(El espectáculo de Arlequín ya terminó, tal vez haya otro más tarde.)"

# game/dia2.rpy:2564
translate Spanish circodoshorrores_6ba1ade1:

    # mcp "(And I’ll probably end up running into him at some point.)"
    mcp "(Y probablemente terminaré encontrándome con él en algún momento)."

# game/dia2.rpy:2586
translate Spanish tendas1_abadcdf5:

    # mc "Looks like this is the last attraction of the night."
    mc "Parece que esta es la última atracción de la noche."

# game/dia2.rpy:2587
translate Spanish tendas1_53b516c3:

    # mc "I can check out the others until it’s time for this one."
    mc "Puedo ver los demás hasta que llegue el momento de este."

# game/dia2.rpy:2598
translate Spanish ciano_c82b6aa7:

    # narrator "You see someone stumbling out of the tent, pale, rubbing their arms with a terrified look."
    narrator "Ves a alguien salir de la carpa a trompicones, con el rostro pálido, frotándose los brazos con una mirada aterrada."

# game/dia2.rpy:2600
translate Spanish ciano_bd2c34d7:

    # mcp "(This looks straight out of a haunted house. Only one person goes in at a time.)"
    mcp "(Esto parece sacado directamente de una casa encantada. Sólo entra una persona a la vez)."

# game/dia2.rpy:2604
translate Spanish ciano_f8070ddd:

    # narrator "You’re handed a clipboard with a feather pen to sign."
    narrator "Te entregan un portapapeles con una pluma para que firmes."

# game/dia2.rpy:2606
translate Spanish ciano_2b7ac9c8:

    # mcp "(A contract? What kind of attraction is this?)"
    mcp "(¿Un contrato? ¿Qué tipo de atracción es esta?)"

# game/dia2.rpy:2615
translate Spanish ciano_21aeefe6:

    # mcp "(Well, I’m already here anyway, so why not?)"
    mcp "(Bueno, ya estoy aquí de todos modos, ¿por qué no?)"

# game/dia2.rpy:2617
translate Spanish ciano_e3ef4c9e:

    # narrator "You hand the paper back to the masked one."
    narrator "Le devuelves el papel al enmascarado."

# game/dia2.rpy:2634
translate Spanish doutor_ca5037ff:

    # doc "Come closer, dear patient, don’t be shy."
    doc "Acércate, querid[letra] paciente, no seas tímid[letra]."

# game/dia2.rpy:2638
translate Spanish doutor_757e8704:

    # doc "Oh, that? Don’t mind them."
    doc "Ah, ¿eso? No les hagas caso."

# game/dia2.rpy:2639
translate Spanish doutor_e971dbf4:

    # doc "I promise they can’t bite you. Well…{w=0.2}{cps=13} not anymore, huhum."
    doc "Te prometo que no podrán morderte. Bueno…{w=0.2}{cps=13} ya no, huhum."

# game/dia2.rpy:2649
translate Spanish doutor_f4aa46a8:

    # mcp "(No turning back now…)"
    mcp "(No hay vuelta atrás ahora…)"

# game/dia2.rpy:2655
translate Spanish doutor_6ab94f48:

    # doc "Don’t forget to roll up your sleeves, please."
    doc "No olvides arremangarte, por favor."

# game/dia2.rpy:2660
translate Spanish doutor_60651a39:

    # narrator "You smell sweet incense, a scent you’ve never experienced in your life."
    narrator "Percibes un olor a incienso dulce, un aroma que nunca habías experimentado en tu vida."

# game/dia2.rpy:2662
translate Spanish doutor_57d77762:

    # doc "You wanted to run off, didn’t you? It’s fine, no one really likes visiting the Doctor."
    doc "Querías escaparte, ¿no? Está bien, a nadie le gusta mucho visitar al Doctor."

# game/dia2.rpy:2665
translate Spanish doutor_1252f5a9:

    # doc "After all, there aren’t any secrets between the Doctor and their patient, right?"
    doc "Después de todo, no hay secretos entre el Doctor y su paciente, ¿verdad?"

# game/dia2.rpy:2667
translate Spanish doutor_07772133:

    # mc "W-wait, what are you doing?"
    mc "E-espera, ¿qué estás haciendo?"

# game/dia2.rpy:2669
translate Spanish doutor_37cb7930:

    # doc "It's part of the procedure. I don’t want you to freak out and run off."
    doc "Es parte del procedimiento. No quiero que te asustes y salgas corriendo."

# game/dia2.rpy:2670
translate Spanish doutor_600ccbce:

    # doc "You could hurt yourself, you know?"
    doc "Podrías hacerte daño, ¿lo sabías?"

# game/dia2.rpy:2671
translate Spanish doutor_3280d0ce:

    # doc "There are dangerous instruments in an office."
    doc "Hay instrumentos peligrosos en una oficina."

# game/dia2.rpy:2676
translate Spanish doutor_ae7c3666:

    # doc "On your file, it says you’re not feeling unwell, you’re just, curious about the attraction, right?"
    doc "En tu expediente dice que no te sientes mal, solo sientes curiosidad por la atracción, ¿verdad?"

# game/dia2.rpy:2681
translate Spanish doutor_29a96724:

    # doc "So, you came here to see me, to test whether the fear of being my guinea pig is worth it."
    doc "Entonces viniste aquí a verme, a probar si el miedo a ser mi conejillo de indias vale la pena."

# game/dia2.rpy:2683
translate Spanish doutor_fcecba7a:

    # mc "Guinea... pig?"
    mc "¿Conejillo de Indias?"

# game/dia2.rpy:2685
translate Spanish doutor_7ca7a247:

    # doc "It’s okay, I’m your Doctor, and I’m going to examine every fiber of your being, [mc_nome]."
    doc "Está bien, soy tu Doctor y voy a examinar cada fibra de tu ser, [mc_nome]."

# game/dia2.rpy:2688
translate Spanish doutor_38e80b8f:

    # doc "You’re cold… is your blood pressure dropping?"
    doc "Tienes frío... ¿te está bajando la presión arterial?"

# game/dia2.rpy:2690
translate Spanish doutor_c6e35787:

    # narrator "He holds your wrist firmly, checking your pulse."
    narrator "Te sujeta la muñeca con firmeza y comprueba tu pulso."

# game/dia2.rpy:2699
translate Spanish doutor_b60309ae:

    # doc "Oh, what a firm pulse you have, beating with so much life. If you’ll let me…"
    doc "Ay, qué pulso tan firme tienes, palpitando de tanta vida. Si me dejas..."

# game/dia2.rpy:2704
translate Spanish doutor_f70a1c53:

    # narrator "You feel the sharp tips pressing against your skin."
    narrator "Sientes las puntas afiladas presionando contra tu piel."

# game/dia2.rpy:2706
translate Spanish doutor_d45792ac:

    # mc "Shouldn’t you be using a stethoscope?"
    mc "¿No deberías usar un estetoscopio?"

# game/dia2.rpy:2708
translate Spanish doutor_93812fac:

    # doc "You’re not really sick,{w=0.3} I don’t need it.{w=0.3} {i}I can feel it."
    doc "No estás realmente enferm[letra],{w=0.3} no lo necesito.{w=0.3} {i}Puedo sentirlo."

# game/dia2.rpy:2712
translate Spanish doutor_e33a3a0b:

    # doc "Ah… your heart… it sounds like a drum."
    doc "Ah… tu corazón… suena como un tambor."

# game/dia2.rpy:2715
translate Spanish doutor_d375c8d4:

    # doc "{cps=20}{b}Like it’s asking me to open your chest and take a closer look."
    doc "{cps=20}{b}Como si me pidiera que abriera tu pecho y mirara más de cerca."

# game/dia2.rpy:2717
translate Spanish doutor_9fb7f094:

    # mcp "(What?)"
    mcp "(¿Qué?)"

# game/dia2.rpy:2718
translate Spanish doutor_68862a11:

    # doc "You’re breathing too heavily too."
    doc "Tú también estás respirando demasiado fuerte."

# game/dia2.rpy:2725
translate Spanish doutor_25cb63d2:

    # doc "And your pupils are wide dear patient, unnaturally wide. Hold still."
    doc "Y tus pupilas están muy dilatadas, querid[letra] paciente, anormalmente dilatadas. Quédate quiet[letra]."

# game/dia2.rpy:2726
translate Spanish doutor_af7caa7c:

    # doc "{cps=25}Don’t move."
    doc "{cps=25}No te muevas."

# game/dia2.rpy:2728
translate Spanish doutor_f8ba84e1:

    # narrator "You feel something sharp press into your skin as his hands draw closer."
    narrator "Sientes que algo afilado presiona tu piel mientras sus manos se acercan."

# game/dia2.rpy:2736
translate Spanish doutor_73b4505d:

    # narrator "You recoil when his claws scrape across your flesh."
    narrator "Retrocedes cuando sus garras raspan tu carne."

# game/dia2.rpy:2738
translate Spanish doutor_01a050a9:

    # mc "S-sorry, I…"
    mc "Lo siento, yo..."

# game/dia2.rpy:2739
translate Spanish doutor_3dc6beb0:

    # mc "Did... did you just scratch me?"
    mc "¿Acabas de arañarme?"

# game/dia2.rpy:2740
translate Spanish doutor_556f995c:

    # mcp "(There’s something cold at my neck, but it doesn’t hurt.)"
    mcp "(Hay algo frío en mi cuello, pero no duele)."

# game/dia2.rpy:2747
translate Spanish doutor_2261e533:

    # mc "Doctor...?"
    mc "¿Doctor...?"

# game/dia2.rpy:2751
translate Spanish doutor_3b6aa023:

    # doc "{cps=20}…Look…{w=0.3} what you’ve done…"
    doc "{cps=20}…Mira…{w=0.3} lo que has hecho…"

# game/dia2.rpy:2752
translate Spanish doutor_3a317cf7:

    # doc "it’s dripping…{w=0.3} leaking like a broken faucet…"
    doc "está goteando…{w=0.3} goteando como un grifo roto…"

# game/dia2.rpy:2753
translate Spanish doutor_6ea05608:

    # doc "{b}Ahh, this is good!!"
    doc "{b}¡¡Ahh, esto es bueno!!"

# game/dia2.rpy:2754
translate Spanish doutor_ce08070c:

    # doc "{b}{sc=3}{color=#e74c3c}HHAHAH...."
    doc "{b}{sc=3}{color=#e74c3c}HAHAHA...."

# game/dia2.rpy:2755
translate Spanish doutor_f42c29d2:

    # doc "{b}{sc=3}{color=#e74c3c}HHHAAAHAHHHAHAHAHA!!!"
    doc "{b}{sc=3}{color=#e74c3c}HHHAAAHAHHHAHAHAHA!!!"

# game/dia2.rpy:2756
translate Spanish doutor_a85d8277:

    # doc "{sc=2}{color=#e74c3c}Good method..."
    doc "{sc=2}{color=#e74c3c}Buen método..."

# game/dia2.rpy:2757
translate Spanish doutor_e68a8bd1:

    # doc "{sc=2}{color=#e74c3c}Did you know bloodletting, can have calming effects?"
    doc "{sc=2}{color=#e74c3c}¿Sabías que la sangría puede tener efectos calmantes?"

# game/dia2.rpy:2758
translate Spanish doutor_a6cff2d4:

    # doc "{cps=20}{b}For me, of course!"
    doc "{cps=20}{b}¡Para mí, por supuesto!"

# game/dia2.rpy:2764
translate Spanish doutor_9a212b71:

    # doc "{b}HAHAHHAHA What a beautiful shade of red!!!"
    doc "{b}HAHAHHAHA ¡¡¡Qué hermoso tono de rojo!!!"

# game/dia2.rpy:2766
translate Spanish doutor_aeca06f2:

    # mc "Am I… bleeding?"
    mc "¿Estoy... sangrando?"

# game/dia2.rpy:2768
translate Spanish doutor_e9e9ffdd:

    # doc "{b}{sc=1}{color=#e74c3c}I could… split you wide open…"
    doc "{b}{sc=1}{color=#e74c3c}Podría… abrirte en canal…"


# game/dia2.rpy:2769
translate Spanish doutor_65acb1b0:

    # doc "{b}{sc=1}{color=#e74c3c}Just to watch the show… your heart, thrashing…"
    doc "{b}{sc=1}{color=#e74c3c}Solo para ver el espectáculo… tu corazón, latiendo…"

# game/dia2.rpy:2770
translate Spanish doutor_c92724ad:

    # doc "{b}{sc=1}{color=#e74c3c}Desperate to survive!!"
    doc "{b}{sc=1}{color=#e74c3c}¡¡Desesperado por sobrevivir!!"

# game/dia2.rpy:2771
translate Spanish doutor_1ca1a262:

    # doc "{b}The taste…"
    doc "{b}El sabor…"

# game/dia2.rpy:2772
translate Spanish doutor_de414507:

    # doc "{b}Yes!! The taste!!"
    doc "{b}¡¡Sí!! ¡¡El sabor!!"

# game/dia2.rpy:2773
translate Spanish doutor_a1e6cc62:

    # doc "{b}With all that spice of adrenaline, it must be--{nw=1.5}"
    doc "{b}Con todo ese sabor de adrenalina, debe ser--{nw=1.5}"

# game/dia2.rpy:2776
translate Spanish doutor_5ffd0c51:

    # mc "DOCTOR!!" with hpunch
    mc "¡¡DOCTOR!!" with hpunch

# game/dia2.rpy:2782
translate Spanish doutor_631541e9:

    # doc "{size=45}{b}{cps=25}..."
    doc "{size=45}{b}{cps=25}..."

# game/dia2.rpy:2786
translate Spanish doutor_79ce1aa8:

    # doc "Your eyes say a lot. Just like every involuntary reaction of your body."
    doc "Tus ojos dicen mucho. Como cada reacción involuntaria de tu cuerpo."

# game/dia2.rpy:2787
translate Spanish doutor_8df91a74:

    # doc "I noticed the moment you walked in, you were hesitant, curious, and your expectations..."
    doc "Noté que en el momento en que entraste estabas indecis[letra], curios[letra] y tus expectativas..."

# game/dia2.rpy:2788
translate Spanish doutor_d038d7ea:

    # doc "Were different from the others."
    doc "Eran diferentes a los demás."

# game/dia2.rpy:2790
translate Spanish doutor_721d4483:

    # mc "What do you mean by that?"
    mc "¿Qué quieres decir con eso?"

# game/dia2.rpy:2792
translate Spanish doutor_b00c3869:

    # doc "A normal person would be impressed by this place. But you?"
    doc "Una persona normal quedaría impresionada con este lugar. ¿Pero tú?"

# game/dia2.rpy:2793
translate Spanish doutor_9d274fa1:

    # doc "You locked your eyes directly on me. I wonder why."
    doc "Fijaste tus ojos directamente en mí. Me pregunto por qué."

# game/dia2.rpy:2795
translate Spanish doutor_2b35b6fe:

    # mc "..."
    mc "..."

# game/dia2.rpy:2797
translate Spanish doutor_237ee08d:

    # doc "Tension, trembling fingers… interesting. Are you nervous?"
    doc "Tensión, dedos temblorosos… interesante. ¿Estás nervios[letra]?"

# game/dia2.rpy:2799
translate Spanish doutor_cffb4f38:

    # mcp "(This guy, is he gonna notice every little thing I do?)"
    mcp "(Este tipo, ¿se dará cuenta de cada pequeña cosa que hago?)"

# game/dia2.rpy:2801
translate Spanish doutor_7a2f915c:

    # doc "That expression, you’re actually enjoying this, aren’t you? You really are a fascinating test subject."
    doc "Esa expresión, realmente estás disfrutando esto, ¿no? Realmente eres un sujeto de prueba fascinante."

# game/dia2.rpy:2803
translate Spanish doutor_a9dd2eb8:

    # mcp "(He’s close… I can smell so many things...)"
    mcp "(Está cerca… puedo oler tantas cosas…)"

# game/dia2.rpy:2804
translate Spanish doutor_7c08e341:

    # mcp "(Incense,{w=0.2} herbs,{w=0.2} something metallic and…{w=0.2} coffee?)"
    mcp "(Incienso,{w=0.2} hierbas,{w=0.2} algo metálico y…{w=0.2} ¿café?)"

# game/dia2.rpy:2806
translate Spanish doutor_195e6470:

    # doc "Your body keeps leaning toward me. I’d say you like danger, don’t you? Hmhm."
    doc "Tu cuerpo sigue inclinándose hacia mí. Yo diría que te gusta el peligro, ¿no? Mmm."

# game/dia2.rpy:2811
translate Spanish doutor_e827cc6f:

    # doc "Ahem. I’ve already got your diagnosis."
    doc "Ejem. Ya tengo tu diagnóstico."

# game/dia2.rpy:2813
translate Spanish doutor_2e855c3c:

    # mc "Are you actually examining me?"
    mc "¿De verdad me estás examinando?"

# game/dia2.rpy:2815
translate Spanish doutor_063b401f:

    # doc "Of course I am. I’m your Doctor, my tasty patient."
    doc "Por supuesto que sí. Soy tu Doctor, mi sabros[letra] paciente."

# game/dia2.rpy:2816
translate Spanish doutor_3ecbdf8b:

    # doc "And I can see your heart racing, your skin’s cold, and your eyes…"
    doc "Y puedo ver tu corazón acelerado, tu piel fría y tus ojos..."

# game/dia2.rpy:2821
translate Spanish doutor_a78cb121:

    # doc "Your pupils are blown wide like they’re begging for the light to pierce them."
    doc "Tus pupilas se abren como si estuvieran rogando que la luz las atraviese."

# game/dia2.rpy:2822
translate Spanish doutor_4fca1597:

    # doc "You’re scared, and you’re enjoying it, but I’m not here to judge."
    doc "Estás asustad[letra] y lo estás disfrutando, pero no estoy aquí para juzgar."

# game/dia2.rpy:2825
translate Spanish doutor_7ffc8f17:

    # doc "I love hearing the blood quicken under your skin."
    doc "Me encanta escuchar la sangre acelerarse bajo tu piel."

# game/dia2.rpy:2830
translate Spanish doutor_f1bad8c9:

    # doc "An injection could fix that. You’ll relax."
    doc "Una inyección podría solucionarlo. Te relajarás."

# game/dia2.rpy:2831
translate Spanish doutor_67511d60:

    # doc "Don’t worry you don’t have to hold your voice back."
    doc "No te preocupes, no tienes que contener la voz."

# game/dia2.rpy:2832
translate Spanish doutor_625c7110:

    # doc "This is the place to scream if you want."
    doc "Este es el lugar donde puedes gritar si quieres."

# game/dia2.rpy:2834
translate Spanish doutor_9d066593:

    # mc "N-no… thanks, I think this is getting a bit far..."
    mc "N-no… gracias, creo que esto está llegando un poco lejos…"

# game/dia2.rpy:2836
translate Spanish doutor_ad0b370e:

    # doc "I promise you’ll feel a lot better."
    doc "Te prometo que te sentirás mucho mejor."

# game/dia2.rpy:2840
translate Spanish doutor_7000054c:

    # mc "If the doctor says so."
    mc "Si el médico lo dice."

# game/dia2.rpy:2841
translate Spanish doutor_1538eb5e:

    # doc "Huhuhum."
    doc "Huhuhum."

# game/dia2.rpy:2843
translate Spanish doutor_cbfb4848:

    # doc "I was joking. This is the part where patients usually struggle."
    doc "Estaba bromeando. Esta es la parte en la que los pacientes suelen forcejear."

# game/dia2.rpy:2847
translate Spanish doutor_e4ce53b6:

    # doc "No? That’s fine, patient."
    doc "¿No? Está bien, paciente."

# game/dia2.rpy:2848
translate Spanish doutor_21c237ea:

    # doc "Or maybe I already gave you the injection and you didn’t even notice."
    doc "O tal vez ya te puse la inyección y ni siquiera te diste cuenta."

# game/dia2.rpy:2852
translate Spanish doutor_150e518e:

    # doc "So tell me, patient are you feeling more relaxed?"
    doc "Entonces dime, paciente, ¿te sientes más relajad[letra]?"

# game/dia2.rpy:2856
translate Spanish doutor_f13d4a01:

    # doc "Perfect! And you behaved so well."
    doc "¡Perfecto! Y te portaste muy bien."

# game/dia2.rpy:2859
translate Spanish doutor_13706331:

    # doc "Most patients scream and struggle when I show the needle, Huhum."
    doc "La mayoría de los pacientes gritan y luchan cuando les muestro la aguja, Huhum."

# game/dia2.rpy:2861
translate Spanish doutor_1362a113:

    # mc "So, am I free, doctor?"
    mc "Entonces, ¿estoy libre, doctor?"

# game/dia2.rpy:2862
translate Spanish doutor_bf7ab2ae:

    # mcp "(Being tied like this is still kinda uncomfortable.)"
    mcp "(Estar atad[letra] así todavía es un poco incómodo)."

# game/dia2.rpy:2867
translate Spanish doutor_6a2ae948:

    # doc "{i}{cps=20}I’m still deciding.{/i}{w=1.0} {/cps}I could keep you here, and listen to your heart wear itself out until exhaustion..."
    doc "{i}{cps=20}Todavía estoy decidiendo.{/i}{w=1.0}{/cps}Podría tenerte aquí y escuchar cómo tu corazón se desgasta hasta el agotamiento..."

# game/dia2.rpy:2868
translate Spanish doutor_a6b1bbdb:

    # doc "Or until your adrenaline just runs dry..."
    doc "O hasta que se te acabe la adrenalina..."

# game/dia2.rpy:2870
translate Spanish doutor_2447c87a:

    # mc "Excuse me?"
    mc "¿Cómo dices?"

# game/dia2.rpy:2873
translate Spanish doutor_ee7c0dc2:

    # doc "Huhuhum. Don’t worry, just a little medical humor."
    doc "Huhuhum. No te preocupes, sólo un poco de humor médico."

# game/dia2.rpy:2874
translate Spanish doutor_3f636488:

    # doc "I’ll let you go now, but before that..."
    doc "Te dejaré ir ahora, pero antes de eso..."

# game/dia2.rpy:2878
translate Spanish doutor_a2c58252:

    # doc "Know that I adore this fake faith of yours."
    doc "Que sepas que adoro esta falsa fe tuya."

# game/dia2.rpy:2879
translate Spanish doutor_9d10104f:

    # doc "{cps=35}You lie, and I pretend to believe.{w=0.5} I lie, and you pretend to {/cps}{cps=10}swallow every word."
    doc "{cps=35}Mientes y yo finjo creer.{w=0.5} Miento y tú finges {/cps}{cps=10}tragarte cada palabra."

# game/dia2.rpy:2884
translate Spanish doutor_e5ff8f36:

    # doc "What a fun game."
    doc "Qué juego tan divertido."

# game/dia2.rpy:2885
translate Spanish doutor_46823481:

    # doc "But I see something different in you, your eyes don’t lie the way they should."
    doc "Pero veo algo diferente en ti, tus ojos no mienten como deberían."

# game/dia2.rpy:2887
translate Spanish doutor_f9b4639f:

    # mc "Well, I just like to question things, you know?"
    mc "Bueno, simplemente me gusta cuestionar cosas, ¿sabes?"

# game/dia2.rpy:2890
translate Spanish doutor_20303290:

    # doc "Interesting..."
    doc "Interesante..."

# game/dia2.rpy:2892
translate Spanish doutor_f578db15:

    # mc "So, uhn, could you--"
    mc "Entonces, eh, ¿podrías...?"

# game/dia2.rpy:2894
translate Spanish doutor_774e9d5a:

    # doc "Are you hungry? You’ve behaved so well, you deserve a treat. May I see your ticket?"
    doc "¿Tienes hambre? Te has portado tan bien que mereces un regalo. ¿Puedo ver tu boleto?"

# game/dia2.rpy:2896
translate Spanish doutor_a9019201:

    # mc "Sure, if you let me go I--{nw=1.5}"
    mc "Claro, si me dejas ir yo--{nw=1.5}"

# game/dia2.rpy:2900
translate Spanish doutor_2a18a37c:

    # narrator "He leans in and takes the ticket from your pocket."
    narrator "Se inclina y saca el boleto de tu bolsillo."

# game/dia2.rpy:2902
translate Spanish doutor_042aad5f:

    # doc "Oh, actually..."
    doc "Ah, en realidad..."

# game/dia2.rpy:2905
translate Spanish doutor_8c035dc3:

    # doc "Seems I’ve run out of sweets. I’ll owe you one."
    doc "Parece que me he quedado sin dulces. Te debo una."

# game/dia2.rpy:2907
translate Spanish doutor_e2bfd597:

    # mc "Hun?"
    mc "¿Eh?"

# game/dia2.rpy:2911
translate Spanish doutor_7389a0fa:

    # narrator "He returns your ticket and starts untying your hands."
    narrator "Te devuelve el boleto y empieza a desatar tus manos."

# game/dia2.rpy:2913
translate Spanish doutor_c8f574b7:

    # mcp "(That was weird, he looked kinda hesitant after seeing Pierrot’s ticket.)"
    mcp "(Eso fue extraño, parecía un poco indeciso después de ver el boleto de Pierrot)."

# game/dia2.rpy:2915
translate Spanish doutor_82711b58:

    # mc "See ya, doc."
    mc "Nos vemos, doctor."

# game/dia2.rpy:2919
translate Spanish doutor_566dc8c8:

    # voice "audio/dublagem/doutor.mp3"
    # doc "Remember,{w=1.0} make regular visits to your doctor."
    voice "audio/dublagem/doutor.mp3"
    doc "Recuerda,{w=1.0} haz visitas periódicas a tu médico."

# game/dia2.rpy:2921
translate Spanish doutor_2384fc09:

    # doc "There’s too much adrenaline in your blood…{cps=15} I like that."
    doc "Hay demasiada adrenalina en tu sangre…{cps=15} Eso me gusta."

# game/dia2.rpy:2922
translate Spanish doutor_6e3206cd:

    # doc "Enjoy your walk, [mc_nome]."
    doc "Disfruta tu paseo, [mc_nome]."

# game/dia2.rpy:2929
translate Spanish foradatenda_385065aa:

    # mcp "(That was weird… like everything in this circus. For a second, I really thought I’d be stuck in that tent.)"
    mcp "(Eso fue extraño... como todo en este circo. Por un segundo, realmente pensé que estaría atrapad[letra] en esa carpa)."

# game/dia2.rpy:2933
translate Spanish foradatenda_c992f6b5:

    # narrator "You run your hand over your neck and feel a bandage."
    narrator "Pasas tu mano por tu cuello y sientes el vendaje."

# game/dia2.rpy:2935
translate Spanish foradatenda_94701b80:

    # mcp "(He actually scratched me, but I didn’t even feel it. I didn’t even see him put this bandage on.)"
    mcp "(De hecho, me arañó, pero ni siquiera lo sentí. Ni siquiera lo vi ponerme el vendaje)."

# game/dia2.rpy:2937
translate Spanish foradatenda_0cbd2df7:

    # mcp "(Still, I want to look around a bit more. Pierrot said I’d be safe, didn’t he?)"
    mcp "(Aun así, quiero mirar un poco más a mi alrededor. Pierrot dijo que estaría a salvo, ¿no?)"

# game/dia2.rpy:2945
translate Spanish tenda_roxa_77aa0254:

    # mcp "(This tent has a stage, maybe something theatrical?)"
    mcp "(Esta carpa tiene un escenario, ¿tal vez algo teatral?)"

# game/dia2.rpy:2951
translate Spanish tenda_roxa_10acc45e:

    # d "{color=#961ee6}Welcome, welcome! My precious monsters of the day!"
    d "{color=#961ee6}¡Bienvenidos, bienvenidos! ¡Mis preciosos monstruos del día!"

# game/dia2.rpy:2952
translate Spanish tenda_roxa_7f1ad71b:

    # d "{color=#961ee6}Did you come thirsty for blood? {i}Hungry for terror?"
    d "{color=#961ee6}¿Vinieron sedientos de sangre? {i}¿Hambrientos de terror?"

# game/dia2.rpy:2957
translate Spanish tenda_roxa_6b74fa67:

    # d "{color=#961ee6}You know, my dear monsters, this dark garden is the window to the kind of fear you’ve been craving."
    d "{color=#961ee6}Saben, mis queridos monstruos, este jardín oscuro es la ventana al tipo de miedo que han estado anhelando."

# game/dia2.rpy:2959
translate Spanish tenda_roxa_f3b4cad2:

    # j "And I, as your noble Jester, couldn’t possibly deny shivers to my starving little monsters, could I?"
    j "Y yo, como su noble Bufón, no podría negarles los escalofríos a mis pequeños monstruos hambrientos, ¿verdad?"

# game/dia2.rpy:2962
translate Spanish tenda_roxa_9c8ea873:

    # j "Tonight, I’ll tell you a story. Hold your gasps it’s just..."
    j "Esta noche les contaré una historia. Contengan los gritos ahogados, es solo..."

# game/dia2.rpy:2966
translate Spanish tenda_roxa_90865c92:

    # j "A harmless story, about... {cps=30}{i}Forbidden love."
    j "Una historia inofensiva, sobre... {cps=30}{i}Amor prohibido."

# game/dia2.rpy:2970
translate Spanish tenda_roxa_270d40e9:

    # j "{cps=50}In a forgotten valley,{w=0.2} where the moonlight seemed to hesitate before touching the ground,{w=0.2} the {i}nameless{/i} ones lived."
    j "{cps=50}En un valle olvidado,{w=0.2} donde la luz de la luna parecía dudar antes de tocar el suelo,{w=0.2} vivían los {i}sin nombre{/i}."

# game/dia2.rpy:2973
translate Spanish tenda_roxa_6e43b079:

    # j "{cps=50}Creatures of hidden shapes,{w=0.2} hungry eyes,{w=0.2} and hearts."
    j "{cps=50}Criaturas de formas ocultas,{w=0.2} ojos hambrientos,{w=0.2} y corazones."

# game/dia2.rpy:2974
translate Spanish tenda_roxa_97eaece2:

    # j "{cps=50}That had long forgotten how to beat for anything beyond {b}hunger."
    j "{cps=50}Que hacía tiempo habían olvidado cómo latir por algo más allá del {b}hambre."

# game/dia2.rpy:2978
translate Spanish tenda_roxa_8585eca8:

    # j "{cps=50}But among them,{w=0.2} there she was,{w=0.2} a sweet little flower in a garden of black thorns."
    j "{cps=50}Pero entre ellos,{w=0.2} allí estaba ella,{w=0.2} una dulce florecita en un jardín de espinas negras."

# game/dia2.rpy:2980
translate Spanish tenda_roxa_1bc7d7cd:

    # j "{cps=50}Shaped like a gift from the heavens!{w=0.2} {/cps}{cps=10}{b}Columbina{/b}."
    j "{cps=50}¡Con la forma de un regalo del cielo!{w=0.2}{/cps}{cps=10}{b}Columbina{/b}."

# game/dia2.rpy:2987
translate Spanish tenda_roxa_92e98e1c:

    # j "Delicate, with no claws, almost no fangs."
    j "Delicada, sin garras, casi sin colmillos."

# game/dia2.rpy:2988
translate Spanish tenda_roxa_35009e66:

    # j "Just a gentle presence among the shadows, smiling warmly at monsters."
    j "Sólo una presencia gentil entre las sombras, sonriendo cálidamente a los monstruos."

# game/dia2.rpy:2989
translate Spanish tenda_roxa_05adcfea:

    # j "A smile that even lit up the darkness."
    j "Una sonrisa que incluso iluminó la oscuridad."

# game/dia2.rpy:2992
translate Spanish tenda_roxa_82f443c0:

    # j "And it was for that tender warmth that He, the silent monster, lost himself."
    j "Y fue por ese tierno calor que Él, el monstruo silencioso, se perdió."

# game/dia2.rpy:2993
translate Spanish tenda_roxa_1bca0075:

    # j "Every day he watched her, her light steps, her kind words."
    j "Todos los días la observaba, sus pasos ligeros, sus amables palabras."

# game/dia2.rpy:2994
translate Spanish tenda_roxa_8ffbd191:

    # j "And the more kindness she gave, the closer he came."
    j "Y cuanto más amabilidad ella le daba, más se acercaba él."

# game/dia2.rpy:2995
translate Spanish tenda_roxa_1009859c:

    # j "He sighed for her."
    j "Él suspiró por ella."

# game/dia2.rpy:2996
translate Spanish tenda_roxa_291eb388:

    # j "Kept for her the broken flowers of the valley."
    j "Guardó para ella las flores rotas del valle."

# game/dia2.rpy:2997
translate Spanish tenda_roxa_c538be01:

    # j "And tried to hide his claws so she would not wound herself upon his skin."
    j "Y trató de esconder sus garras para que ella no se hiriera con su piel."

# game/dia2.rpy:3002
translate Spanish tenda_roxa_2d66b33c:

    # j "But there was the Other."
    j "Pero estaba el Otro."

# game/dia2.rpy:3007
translate Spanish tenda_roxa_84250256:

    # j "A monster with venom in his voice and in his hands."
    j "Un monstruo con veneno en su voz y en sus manos."

# game/dia2.rpy:3012
translate Spanish tenda_roxa_1a3c544f:

    # j "Who hid within the shadows of lover's meetings."
    j "Quien se escondió entre las sombras de las reuniones de amantes."

# game/dia2.rpy:3013
translate Spanish tenda_roxa_a268b536:

    # j "Who saw the light in the lover’s eyes and felt envy gnawing him from within."
    j "Que vio la luz en los ojos del enamorado y sintió que la envidia lo carcomía por dentro."

# game/dia2.rpy:3018
translate Spanish tenda_roxa_a6924289:

    # v "Why are your eyes never on me? Why can’t it be… me?"
    v "¿Por qué tus ojos nunca están puestos en mí? ¿Por qué no puedo ser... yo?"

# game/dia2.rpy:3021
translate Spanish tenda_roxa_dc814c35:

    # j "The venomous monster clenched his claws when she slipped away from his attempts at seduction."
    j "El monstruo venenoso apretó sus garras cuando ella se escapó de sus intentos de seducción."

# game/dia2.rpy:3022
translate Spanish tenda_roxa_57230f08:

    # j "His teeth ground together whenever she pulled back in his presence."
    j "Sus dientes rechinaban cada vez que ella retrocedía en su presencia."

# game/dia2.rpy:3027
translate Spanish tenda_roxa_2010df9f:

    # j "And every refusal was like a crack splitting his very being."
    j "Y cada negativa era como una grieta que partía su propio ser."

# game/dia2.rpy:3029
translate Spanish tenda_roxa_2a242124:

    # co "You make me sigh too… you make my heart race."
    co "Tú también me haces suspirar… haces que mi corazón se acelere."

# game/dia2.rpy:3033
translate Spanish tenda_roxa_b1e34ac3:

    # j "She was just as kind to him, and even though she sighed in his presence."
    j "Ella era igual de amable con él, y aunque suspiraba en su presencia."

# game/dia2.rpy:3034
translate Spanish tenda_roxa_c1dd8ae3:

    # j "Her heart beat in a different way."
    j "Su corazón latía de otra manera."

# game/dia2.rpy:3035
translate Spanish tenda_roxa_7e8d862a:

    # j "Until one day, the Other grew tired of the game."
    j "Hasta que un día el Otro se cansó del juego."

# game/dia2.rpy:3036
translate Spanish tenda_roxa_6302c13e:

    # j "Tired of the glances that weren’t meant for him."
    j "Cansado de las miradas que no eran para él."

# game/dia2.rpy:3037
translate Spanish tenda_roxa_db0208d7:

    # j "Tired of the sound of the lovesick monster’s footsteps drawing near."
    j "Cansado del sonido de los pasos del monstruo enamorado acercándose."

# game/dia2.rpy:3040
translate Spanish tenda_roxa_00a8cc95:

    # v "You know, my sweet flower…"
    v "Ya sabes, mi dulce flor..."

# game/dia2.rpy:3043
translate Spanish tenda_roxa_d2c910a0:

    # v "Maybe it’s not you that I love."
    v "Quizás no sea a ti a quien amo."

# game/dia2.rpy:3044
translate Spanish tenda_roxa_581d6255:

    # v "Maybe this feeling is something else. My heart beats fast for another reason."
    v "Quizás este sentimiento sea otra cosa. Mi corazón late rápido por otra razón."

# game/dia2.rpy:3050
translate Spanish tenda_roxa_a6998b80:

    # v "Or maybe… I just want what I can’t have. If I do this, maybe then…"
    v "O tal vez… sólo quiero lo que no puedo tener. Si hago esto, tal vez entonces..."

# game/dia2.rpy:3054
translate Spanish tenda_roxa_ad1fc2bd:

    # v "{sc=2}{color=#b2ffd2}I can love you the right way… only my way.{cps=10} Mine."
    v "{sc=2}{color=#b2ffd2}Puedo amarte de la manera correcta... sólo a mi manera.{cps=10}Mía."

# game/dia2.rpy:3065
translate Spanish tenda_roxa_42cc559c:

    # j "And when the lovestruck one arrived, on that starless night, all he found was the poison."
    j "Y cuando llegó el enamorado, en aquella noche sin estrellas, lo único que encontró fue el veneno."

# game/dia2.rpy:3067
translate Spanish tenda_roxa_af1d2890:

    # j "Found the Other standing there, blood still warm on his hands, a crooked, stained smile on his face."
    j "Encontró al Otro de pie allí, con la sangre aún caliente en las manos y una sonrisa torcida y manchada en el rostro."

# game/dia2.rpy:3072
translate Spanish tenda_roxa_b756f2e8:

    # j "Behind him, delicacy lay on the ground like a crushed flower, eyes still open in surprise."
    j "Detrás de él, la delicadeza yacía en el suelo como una flor aplastada, con los ojos aún abiertos por la sorpresa."

# game/dia2.rpy:3079
translate Spanish tenda_roxa_ec895c65:

    # v "Are your eyes on me? Uhg."
    v "¿Tus ojos están puestos en mí? Uhg."

# game/dia2.rpy:3082
translate Spanish tenda_roxa_a48115ea:

    # v "{sc=5}{color=#b2ffd2}Hah..haahHAHHAhhA!!!"
    v "{sc=5}{color=#b2ffd2}Ja..jaahHAHHAhhA!!!"

# game/dia2.rpy:3083
translate Spanish tenda_roxa_9efe9307:

    # v "{sc=1}{color=#b2ffd2}Oh... Rage... Pain!! I love it...{/sc}{sc=5}{color=#b2ffd2}{b} I LOVE IT!"
    v "{sc=1}{color=#b2ffd2}Oh... Rabia... ¡¡Dolor!! Me encanta...{/sc}{sc=5}{color=#b2ffd2}{b} ¡ME ENCANTA!"

# game/dia2.rpy:3095
translate Spanish tenda_roxa_604cbb6d:

    # j "And the valley filled with the cry of the lovestruck monster, a cry not of hunger, but of pain."
    j "Y el valle se llenó del grito del monstruo enamorado, un grito no de hambre, sino de dolor."

# game/dia2.rpy:3107
translate Spanish tenda_roxa_2d47f999:

    # j "A scream that would echo through the centuries, haunting every shadow."
    j "Un grito que resonaría a través de los siglos, atormentando cada sombra."

# game/dia2.rpy:3109
translate Spanish tenda_roxa_fc18ec99:

    # j "Every night, every breath of those who dared to love there."
    j "Cada noche, cada aliento de quienes se atrevieron a amar allí."

# game/dia2.rpy:3110
translate Spanish tenda_roxa_9474f788:

    # j "Because in the valley of monsters, love is just another way to devour each other."
    j "Porque en el valle de los monstruos, el amor es sólo otra forma de devorarse unos a otros."

# game/dia2.rpy:3116
translate Spanish tenda_roxa_afcdf209:

    # j "And that day, the nameless shadows grew stronger in the dark."
    j "Y ese día, las sombras sin nombre se hicieron más fuertes en la oscuridad."

# game/dia2.rpy:3122
translate Spanish tenda_roxa_f09cdeff:

    # j "The poison? It found that hatred tastes far sweeter than love."
    j "¿El veneno? Descubrió que el odio tiene un sabor mucho más dulce que el amor."

# game/dia2.rpy:3129
translate Spanish tenda_roxa_9aaaee5c:

    # mcp "(Once again, another performance that turns my stomach… why does the blood look so real? Why did the scream sound so real??)"
    mcp "(Una vez más, otra actuación que me revuelve el estómago… ¿por qué la sangre parece tan real? ¿Por qué el grito sonó tan real?)"

# game/dia2.rpy:3130
translate Spanish tenda_roxa_f6cab66c:

    # mcp "(I’ll wait for the crowd to clear out before getting up.)"
    mcp "(Esperaré a que la multitud se vaya antes de levantarme)."

# game/dia2.rpy:3132
translate Spanish tenda_roxa_c9ece516:

    # d "I always love this show."
    d "Siempre me encanta este espectáculo."

# game/dia2.rpy:3133
translate Spanish tenda_roxa_27c927fb:

    # d2 "Right? I love the bloody, macabre acts."
    d2 "¿Verdad? Me encantan los actos sangrientos y macabros."

# game/dia2.rpy:3134
translate Spanish tenda_roxa_99441485:

    # d "The blood looks so fake, but oh well."
    d "La sangre parece tan falsa, pero bueno."

# game/dia2.rpy:3136
translate Spanish tenda_roxa_5c852506:

    # mcp "(People seem excited. Guess I can leave now.)"
    mcp "(La gente parece emocionada. Supongo que puedo irme ahora)."

# game/dia2.rpy:3140
translate Spanish tenda_roxa_83ae3cee:

    # j "{cps=40}Hello,{w=0.2} visitor."
    j "{cps=40}Hola,{w=0.2} visitante."

# game/dia2.rpy:3151
translate Spanish tenda_roxa_72550ab3:

    # j "You look paler than the others. Did my tent get to you… or is something else bothering you?"
    j "Te ves más pálid[letra] que los demás. ¿Mi carpa te afectó... o hay algo más que te molesta?"

# game/dia2.rpy:3153
translate Spanish tenda_roxa_9bb8acb5:

    # mc "Y-Yeah! Yeah, I’m fine. I was just leaving."
    mc "¡Sí! Sí, estoy bien. Me estaba yendo."

# game/dia2.rpy:3158
translate Spanish tenda_roxa_31d4cc0a:

    # j "I noticed, you know."
    j "Me di cuenta, ya sabes."

# game/dia2.rpy:3160
translate Spanish tenda_roxa_c0469fe2:

    # mc "Noticed... what?"
    mc "¿Notaste... qué?"

# game/dia2.rpy:3162
translate Spanish tenda_roxa_cf576b4d:

    # j "A huge shadow hanging over you in this circus. A shadow with {i}golden eyes."
    j "Una enorme sombra se cierne sobre ti en este circo. Una sombra con {i}ojos dorados."

# game/dia2.rpy:3164
translate Spanish tenda_roxa_0a128826:

    # mc "I don’t…{w=0.2} know what you’re talking about."
    mc "No…{w=0.2} sé de qué estás hablando."

# game/dia2.rpy:3167
translate Spanish tenda_roxa_46a61dae:

    # j "May I see your ticket?"
    j "¿Puedo ver tu boleto?"

# game/dia2.rpy:3169
translate Spanish tenda_roxa_e4ebff7f:

    # mcp "(Here we go again… why do I always get chills when someone asks me that?)"
    mcp "(Aquí vamos de nuevo… ¿por qué siempre me da escalofríos cuando alguien me pregunta eso?)"

# game/dia2.rpy:3188
translate Spanish tenda_roxa_e4352675:

    # j "Red, just as I thought. I’ve never seen that ticket in anyone’s hands before."
    j "Rojo, tal como pensaba. Nunca antes había visto ese boleto en manos de nadie."

# game/dia2.rpy:3190
translate Spanish tenda_roxa_6421399c:

    # mcp "(I don’t know what he’s after, but I don’t like where this is going.)"
    mcp "(No sé qué busca, pero no me gusta hacia dónde va esto)."

# game/dia2.rpy:3191
translate Spanish tenda_roxa_002315b9:

    # mc "I'm goin--{nw=0.3}"
    mc "Me voy--{nw=0.3}"

# game/dia2.rpy:3198
translate Spanish tenda_roxa_7fea9831:

    # j "{glitch=1}{b}{color=#961ee6}Stay."
    j "{glitch=1}{b}{color=#961ee6}Quédate."

# game/dia2.rpy:3207
translate Spanish tenda_roxa_ffcd09d9:

    # j "You know,{w=0.2}{cps=30} dear thing..."
    j "Ya sabes, {w=0.2}{cps=30} querid[letra]..."

# game/dia2.rpy:3208
translate Spanish tenda_roxa_673e1909:

    # j "Eyes say a lot about what goes on in the soul. And yours…{w=0.3} {cps=9}{i}they scream."
    j "Los ojos dicen mucho de lo que pasa en el alma. Y los tuyos…{w=0.3}{cps=9}{i}gritan."

# game/dia2.rpy:3209
translate Spanish tenda_roxa_370ad94d:

    # j "Did you come here because you {b}wanted{/b} to, or because {b}someone{/b} sent you?"
    j "¿Viniste aquí porque {b}querías{/b} o porque {b}alguien{/b} te envió?"

# game/dia2.rpy:3217
translate Spanish tenda_roxa_54f0e313:

    # j "Did you know people’s eyes betray them when they lie? A slight movement to the side."
    j "¿Sabías que los ojos de las personas los delatan cuando mienten? Un ligero movimiento hacia un lado."

# game/dia2.rpy:3218
translate Spanish tenda_roxa_61278c01:

    # j "{i}Huhu,{/i} I’m kidding. Or am I?"
    j "{i}Huhu,{/i} estoy bromeando. ¿O no?"

# game/dia2.rpy:3219
translate Spanish tenda_roxa_67525149:

    # j "People lie with their mouths. Their eyes never bother."
    j "La gente miente con la boca. Pero sus ojos nunca lo hacen."

# game/dia2.rpy:3225
translate Spanish tenda_roxa_88724f22:

    # j "Honesty, such an admirable quality."
    j "Honestidad, una cualidad tan admirable."

# game/dia2.rpy:3226
translate Spanish tenda_roxa_b84618f4:

    # j "I like that."
    j "Me gusta eso."

# game/dia2.rpy:3235
translate Spanish tenda_roxa_99fb512e:

    # narrator "You take a step back."
    narrator "Das un paso atrás."

# game/dia2.rpy:3238
translate Spanish tenda_roxa_ad180a18:

    # j "{i}Huhum ♪"
    j "{i}Humm ♪"

# game/dia2.rpy:3242
translate Spanish tenda_roxa_44dd9ae8:

    # j "{cps=50}Fear is curious, isn’t it? {i}It makes us see monsters where there are only shadows."
    j "{cps=50}El miedo es curioso, ¿no? {i}Nos hace ver monstruos donde solo hay sombras."

# game/dia2.rpy:3244
translate Spanish tenda_roxa_c88861ec:

    # j "You know, visitor, there are many kinds of fear."
    j "Ya sabes, visitante, hay muchos tipos de miedo."

# game/dia2.rpy:3246
translate Spanish tenda_roxa_b33f1378:

    # j "The fool’s fear, the kind that makes you run when the monster draws near."
    j "El miedo del tonto, de esos que te hacen correr cuando el monstruo se acerca."

# game/dia2.rpy:3249
translate Spanish tenda_roxa_47384ea6:

    # j "The wise fear, the kind that knows it’s too late to run..."
    j "El miedo sabio, el que sabe que es demasiado tarde para huir..."

# game/dia2.rpy:3252
translate Spanish tenda_roxa_9fc58b28:

    # j "And there’s the fear that’s born when you realize you saw something you shouldn’t have."
    j "Y está el miedo que nace cuando te das cuenta de que viste algo que no deberías haber visto."

# game/dia2.rpy:3256
translate Spanish tenda_roxa_b3dbe092:

    # j "Do you know which one yours is? Your eyes are telling me right now."
    j "¿Sabes cuál es el tuyo? Tus ojos me lo dicen ahora mismo."

# game/dia2.rpy:3258
translate Spanish tenda_roxa_3fc5aaa6:

    # j "Enjoy the rest of the night, sweet visitor. I have a feeling we’ll meet again in this circus."
    j "Disfruta el resto de la noche, dulce visitante. Tengo el presentimiento de que nos volveremos a encontrar en este circo."

# game/dia2.rpy:3261
translate Spanish tenda_roxa_010aecab:

    # j "Ah!{w=0.2}{cps=20} One last thing."
    j "¡Ah!{w=0.2}{cps=20} Una última cosa."

# game/dia2.rpy:3265
translate Spanish tenda_roxa_9daa7159:

    # voice "audio/dublagem/jester.mp3"
    # j "Don’t go far, [mc_nome]. I’ll know {i}how to find you{/i} if you try."
    voice "audio/dublagem/jester.mp3"
    j "No vayas muy lejos, [mc_nome]. Sabré {i}cómo encontrarte{/i} si lo intentas."

# game/dia2.rpy:3274
translate Spanish tendaazul_4b84e066:

    # narrator "Tent of Mirrors: Don’t trust what your eyes see."
    narrator "Carpa de los Espejos: No confíes en lo que ven tus ojos."

# game/dia2.rpy:3276
translate Spanish tendaazul_eb79a5e9:

    # mcp "(Nice marketing. Let’s see what we’ve got here.)"
    mcp "(Buen marketing. Veamos qué tenemos aquí)."

# game/dia2.rpy:3283
translate Spanish tendaazul_6205d678:

    # mcp "(Just one of those mirror houses? Doesn’t really seem like a scary attraction.)"
    mcp "(¿Solo una de esas casas de espejos? Realmente no parece una atracción aterradora)."

# game/dia2.rpy:3287
translate Spanish tendaazul_109fa1ce:

    # mc "Wha--"
    mc "¿Qué--"

# game/dia2.rpy:3291
translate Spanish tendaazul_a2952f8a:

    # mcp "(Where did everyone go?)"
    mcp "(¿A dónde fueron todos?)"

# game/dia2.rpy:3295
translate Spanish tendaazul_a5cf2ede:

    # b "Hm? My tent doesn’t usually attract that many curious souls, {i}especially{/i} ones who seem so eager to run away."
    b "¿Mmm? Mi carpa no suele atraer a tantas almas curiosas, {i}especialmente{/i} aquellas que parecen tan ansiosas por huir."

# game/dia2.rpy:3297
translate Spanish tendaazul_9b98193a:

    # mc "How… did you do that? Where did you take them?"
    mc "¿Cómo… hiciste eso? ¿A dónde los llevaste?"

# game/dia2.rpy:3299
translate Spanish tendaazul_591e31b6:

    # b "Me?{w=0.2} Perhaps, it’s you who only thought you saw others in here."
    b "¿Yo? {w=0.2} Quizás eres tú quien solo pensó que veía a otros aquí."

# game/dia2.rpy:3300
translate Spanish tendaazul_795b727a:

    # b "You might’ve been alone from the very start, just you and me.{cps=15} Red ticket guest."
    b "Es posible que hayas estado sol[letra] desde el principio, solo tú y yo.{cps=15} Invitad[letra] del boleto rojo."

# game/dia2.rpy:3311
translate Spanish tendaazul_68115e40:

    # b "In here, dear guest, you’ll see things you might not want to, whispers from your heart, or maybe warnings from beyond."
    b "Aquí, querid[letra] invitad[letra], verás cosas que quizás no quieras ver, susurros de tu corazón o tal vez advertencias del más allá."

# game/dia2.rpy:3315
translate Spanish tendaazul_ba973723:

    # b "{i}\"Don’t trust what your eyes see.\"{/i}{w=0.3} Enjoy!"
    b "{i}\"No confíes en lo que ven tus ojos.\"{/i}{w=0.3} ¡Disfruta!"

# game/dia2.rpy:3319
translate Spanish tendaazul_1717ec05:

    # mc "But what do I--"
    mc "Pero ¿qué debo--"

# game/dia2.rpy:3321
translate Spanish tendaazul_2100c225:

    # b "Just keep moving forward, guest."
    b "Sigue adelante, invitad[letra]."

# game/dia2.rpy:3322
translate Spanish tendaazul_aa13a51d:

    # b "You’ll find the exit eventually. Though I’d recommend not stopping for too long..."
    b "Al final encontrarás la salida. Aunque recomiendo no parar por mucho tiempo..."

# game/dia2.rpy:3324
translate Spanish tendaazul_cddbcac1:

    # b "I’ve heard monsters live in the dark. And mirrors, sometimes show more than they should."
    b "He oído que los monstruos viven en la oscuridad. Y los espejos, a veces, muestran más de lo que deberían."

# game/dia2.rpy:3350
translate Spanish tendaazul_b333d3ab:

    # mcp "(It’s cold in here. And I can barely see anything beyond the reflections.)"
    mcp "(Hace frío aquí. Y apenas puedo ver nada más allá de los reflejos)."

# game/dia2.rpy:3351
translate Spanish tendaazul_71c47bea:

    # mcp "(He tells me not to stop, but you can’t walk fast in this dark without smashing your face on a mirror.)"
    mcp "(Me dice que no me detenga, pero no se puede caminar rápido en esta oscuridad sin estrellarse la cara contra un espejo)."

# game/dia2.rpy:3364
translate Spanish espelhop_31242941:

    # mc "What a creepy trick."
    mc "Qué truco tan espeluznante."

# game/dia2.rpy:3366
translate Spanish espelhop_73f48569:

    # mcp "(There’s nothing behind me, but I can almost feel something warm right next to me. Like the mirror shows.)"
    mcp "(No hay nada detrás de mí, pero casi puedo sentir algo cálido justo a mi lado. Como muestra el espejo)."

# game/dia2.rpy:3368
translate Spanish espelhop_38e29497:

    # narrator "{cps=30}{color=#ffaf54}Ahh.. [titulo_pierrot]."
    narrator "{cps=30}{color=#ffaf54}Ahh.. [titulo_pierrot!t]."

# game/dia2.rpy:3372
translate Spanish espelhop_52d399cd:

    # mc "Pierrot?"
    mc "¿Pierrot?"

# game/dia2.rpy:3374
translate Spanish espelhop_76065314:

    # narrator "{sc=2}{cps=30}{color=#ffaf54}Can we be together forever!!"
    narrator "{sc=2}{cps=30}{color=#ffaf54}¡¿Podemos estar juntos para siempre?!"

# game/dia2.rpy:3378
translate Spanish espelhop_7d16380b:

    # narrator "{sc=3}{cps=30}{color=#ffaf54}Wouldn't you want that? Just you and me, {b}together."
    narrator "{sc=3}{cps=30}{color=#ffaf54}¿No te gustaría eso? Sólo tú y yo, {b}juntos."

# game/dia2.rpy:3379
translate Spanish espelhop_d0db44ff:

    # narrator "{sc=3}{cps=30}{color=#ffaf54}Please say yes."
    narrator "{sc=3}{cps=30}{color=#ffaf54}Por favor, di que sí."

# game/dia2.rpy:3380
translate Spanish espelhop_f2c29ae5:

    # narrator "{sc=3}{cps=30}{color=#ffaf54}Please let me hear your sweet voice say it."
    narrator "{sc=3}{cps=30}{color=#ffaf54}Por favor, déjame escuchar tu dulce voz decirlo."

# game/dia2.rpy:3381
translate Spanish espelhop_8e25d477:

    # narrator "{sc=3}{cps=30}{color=#ffaf54}Stay with me."
    narrator "{sc=3}{cps=30}{color=#ffaf54}Quédate conmigo."

# game/dia2.rpy:3382
translate Spanish espelhop_534a272f:

    # narrator "{sc=3}{cps=30}{color=#ffaf54}Please [titulo_pierrot]."
    narrator "{sc=3}{cps=30}{color=#ffaf54}Por favor, [titulo_pierrot!t]."

# game/dia2.rpy:3389
translate Spanish espelhop_e232d0b3:

    # mc "!!!"
    mc "!!!"

# game/dia2.rpy:3390
translate Spanish espelhop_6e0e90a0:

    # mc "I recognize that knife."
    mc "Reconozco ese cuchillo."

# game/dia2.rpy:3395
translate Spanish espelhop_cf16a7ac:

    # mc "I can’t stop."
    mc "No puedo parar."

# game/dia2.rpy:3408
translate Spanish espelhoa_439e417f:

    # mcp "(What a cold shiver.)"
    mcp "(Qué escalofrío.)"

# game/dia2.rpy:3413
translate Spanish espelhoa_14076c83:

    # mc "I know those eyes."
    mc "Conozco esos ojos."

# game/dia2.rpy:3416
translate Spanish espelhoa_7285db0c:

    # narrator "{color=#41d623}You, are you really going to let me come close?"
    narrator "{color=#41d623}Tú, ¿realmente vas a dejarme acercarme?"

# game/dia2.rpy:3420
translate Spanish espelhoa_77131473:

    # narrator "{color=#41d623}Do you like my warmth? I can see it in your eyes, what you think of me."
    narrator "{color=#41d623}¿Te gusta mi calidez? Puedo verlo en tus ojos, lo que piensas de mí."

# game/dia2.rpy:3424
translate Spanish espelhoa_aa431f69:

    # narrator "{color=#41d623}{size=40}{cps=40}...{nw=0.5}"
    narrator "{color=#41d623}{size=40}{cps=40}...{nw=0.5}"

# game/dia2.rpy:3425
translate Spanish espelhoa_2e0c184a:

    # narrator "{color=#41d623}Why are you looking at me like that?"
    narrator "{color=#41d623}¿Por qué me miras así?"

# game/dia2.rpy:3436
translate Spanish espelhoa_cf8b7990:

    # mc "{cps=15}..."
    mc "{cps=15}..."

# game/dia2.rpy:3440
translate Spanish espelhoa_ddf3984f:

    # mc "This place gives me the creeps."
    mc "Este lugar me da escalofríos."

# game/dia2.rpy:3453
translate Spanish espelhoj_6fb5e91f:

    # narrator "{color=#961ee6}A pet? Why would he want a creature this troublesome? Tsk."
    narrator "{color=#961ee6}¿Una mascota? ¿Por qué querría una criatura tan problemática? Tsk."

# game/dia2.rpy:3454
translate Spanish espelhoj_38eda6b6:

    # narrator "{color=#961ee6}Look at you, so {b}weak{/b} on your own."
    narrator "{color=#961ee6}Mírate, tan {b}débil{/b} por tu cuenta."

# game/dia2.rpy:3455
translate Spanish espelhoj_768b3703:

    # narrator "{color=#961ee6}You’ve been lucky so far."
    narrator "{color=#961ee6}Has tenido suerte hasta ahora."

# game/dia2.rpy:3456
translate Spanish espelhoj_8a99f12d:

    # narrator "{color=#961ee6}But luck is a fickle thing. It always runs out, eventually."
    narrator "{color=#961ee6}Pero la suerte es algo voluble. Al final siempre se acaba."

# game/dia2.rpy:3459
translate Spanish espelhoj_b9d6dcbb:

    # narrator "{color=#961ee6}And when that day comes, huhum... I’ll have my {i}fun."
    narrator "{color=#961ee6}Y cuando llegue ese día, huhum... tendré mi {i}diversión."

# game/dia2.rpy:3470
translate Spanish espelhod_a0b599af:

    # narrator "{color=#e74c3c}I’d love to examine this specimen."
    narrator "{color=#e74c3c}Me encantaría examinar este espécimen."

# game/dia2.rpy:3471
translate Spanish espelhod_f4a8f749:

    # narrator "{color=#e74c3c}I wonder how much this one can endure."
    narrator "{color=#e74c3c}Me pregunto cuánto puede soportar este."

# game/dia2.rpy:3473
translate Spanish espelhod_064c30e4:

    # narrator "{color=#e74c3c}You walked into my tent with such boldness."
    narrator "{color=#e74c3c}Entraste en mi carpa con tanta valentía."

# game/dia2.rpy:3478
translate Spanish espelhod_ddee5eac:

    # narrator "{color=#e74c3c}I bet you can handle high doses of adrenaline."
    narrator "{color=#e74c3c}Apuesto a que puedes soportar altas dosis de adrenalina."

# game/dia2.rpy:3479
translate Spanish espelhod_cace6ee0:

    # narrator "{color=#e74c3c}Let me run a few tests. It’ll be… entertaining."
    narrator "{color=#e74c3c}Déjame realizar algunas pruebas. Será… entretenido."

# game/dia2.rpy:3480
translate Spanish espelhod_42901e3a:

    # narrator "{color=#e74c3c}How far can I push before you finally beg?"
    narrator "{color=#e74c3c}¿Hasta dónde puedo presionar antes de que finalmente me supliques?"

# game/dia2.rpy:3483
translate Spanish espelhod_7d80814f:

    # narrator "{color=#e74c3c}Or perhaps your heart will give out first, like the other {b}dolls."
    narrator "{color=#e74c3c}O tal vez tu corazón se rinda primero, como las otras {b}muñecas."

# game/dia2.rpy:3485
translate Spanish espelhod_3a549877:

    # mc "Dolls..."
    mc "Muñecas..."

# game/dia2.rpy:3493
translate Spanish espelhoh_47e768c2:

    # mcp "This one’s broken, kind of melted and it reflects words that aren’t written anywhere in the tent."
    mcp "Éste está roto, como derretido y refleja palabras que no están escritas en ninguna parte de la carpa."

# game/dia2.rpy:3503
translate Spanish espelhoh_33b9981d:

    # mcp "(Where is that... noise coming from?)"
    mcp "(¿De dónde viene ese... ruido?)"

# game/dia2.rpy:3504
translate Spanish espelhoh_adb7d7b6:

    # mcp "(It smells like something’s burning, really strong.)"
    mcp "(Huele como si algo se estuviera quemando, muy fuerte)."

# game/dia2.rpy:3509
translate Spanish espelhoh_60fef2df:

    # mcp "(I need to get out of here.)"
    mcp "(Necesito salir de aquí.)"

# game/dia2.rpy:3522
translate Spanish insistente_47eb6ba9:

    # b "Why do you keep coming back to this broken mirror?"
    b "¿Por qué sigues volviendo a este espejo roto?"

# game/dia2.rpy:3523
translate Spanish insistente_5c030349:

    # b "Rather... sadistic of you, isn’t it?"
    b "Más bien... sádico de tu parte, ¿no?"

# game/dia2.rpy:3524
translate Spanish insistente_6cb7c6f3:

    # b "Do you enjoy the smell of burning flesh?"
    b "¿Te gusta el olor a carne quemada?"

# game/dia2.rpy:3525
translate Spanish insistente_cad0fb47:

    # b "{cps=20}I’m getting closer, guest."
    b "{cps=20}Me estoy acercando, invitad[letra]."

# game/dia2.rpy:3527
translate Spanish insistente_092ef9f5:

    # b "Closer..."
    b "Más cerca..."

# game/dia2.rpy:3539
translate Spanish espelhob_5cb4fb58:

    # b "{cps=50}You’re an interesting guest.{w=0.2} I told you not to stop,{w=0.2} yet you wanted to look at every mirror."
    b "{cps=50}Eres [arti_2] invitad[letra] interesante.{w=0.2} Te dije que no te detuvieras,{w=0.2} pero querías mirar todos los espejos."

# game/dia2.rpy:3542
translate Spanish espelhob_f6ad1ccf:

    # b "So... the monster caught up to you."
    b "Entonces... el monstruo te alcanzó."

# game/dia2.rpy:3549
translate Spanish espelhob_3abf0434:

    # narrator "You feel warm breath against your neck."
    narrator "Sientes un aliento cálido contra tu cuello."

# game/dia2.rpy:3550
translate Spanish espelhob_5ec4feed:

    # b "{b}Don’t."
    b "{b}No lo hagas."

# game/dia2.rpy:3555
translate Spanish espelhob_5ee3c76c:

    # b "Don’t look back,{w=0.2} {i}trust me."
    b "No mires atrás,{w=0.2}{i}confía en mí."

# game/dia2.rpy:3565
translate Spanish espelhob_45e30642:

    # b "Perfect. I like that you’re obedient, you know your place here."
    b "Perfecto. Me gusta que seas obediente, sabes cuál es tu lugar aquí."

# game/dia2.rpy:3566
translate Spanish espelhob_b5eecb1a:

    # b "You’ll be just fine."
    b "Estarás bien."

# game/dia2.rpy:3577
translate Spanish espelhob_877030e1:

    # narrator "You feel something enormous grab your head, forcing it forward. {color=#c90c0c}You can’t move." with hpunch
    narrator "Sientes que algo enorme te agarra la cabeza y la obliga a avanzar. {color=#c90c0c}No puedes moverte." with hpunch

# game/dia2.rpy:3579
translate Spanish espelhob_b9549b62:

    # b "I despise{cps=40} the disobedient.{w=0.2} You’re lucky I can’t hurt you."
    b "Desprecio{cps=40} a los desobedientes.{w=0.2} Tienes suerte de que no pueda hacerte daño."

# game/dia2.rpy:3585
translate Spanish espelhob_e1dd04ba:

    # b "{cps=99}Stop right there."
    b "{cps=99}Detente ahí."

# game/dia2.rpy:3586
translate Spanish espelhob_46561b29:

    # b "{cps=65}I’m watching you. Step back,{w=0.2} we’re only talking. It depends on you.{w=0.2}"
    b "{cps=65}Te estoy vigilando. Da un paso atrás,{w=0.2} solo estamos hablando. Depende de ti.{w=0.2}"

# game/dia2.rpy:3587
translate Spanish espelhob_d6d9b784:

    # b "Don’t you trust me?"
    b "¿No confías en mí?"

# game/dia2.rpy:3589
translate Spanish espelhob_282e5851:

    # mc "What...?"
    mc "¿Qué...?"

# game/dia2.rpy:3595
translate Spanish espelhob_66c019d2:

    # b "Quiet. I’m not speaking to you."
    b "Silencio. No te estoy hablando."

# game/dia2.rpy:3600
translate Spanish espelhob_6b3e6f36:

    # b "Very good."
    b "Muy bien."

# game/dia2.rpy:3601
translate Spanish espelhob_8d2289d0:

    # b "{cps=50}Now, where were we?{w=0.3}{cps=10} Ah, yes."
    b "{cps=50}Ahora, ¿dónde estábamos?{w=0.3}{cps=10} Ah, sí."

# game/dia2.rpy:3608
translate Spanish espelhob_d2be79c5:

    # b "Be polite and keep your eyes on me.{w=0.2} We’re having a conversation."
    b "Sé cortés y mantén tus ojos en mí. {w=0.2} Estamos teniendo una conversación."

# game/dia2.rpy:3609
translate Spanish espelhob_50e8dd61:

    # narrator "You feel your head released."
    narrator "Sientes tu cabeza liberada."

# game/dia2.rpy:3620
translate Spanish espelhob_95d7c5f3:

    # narrator "Heavy claws pressing down on your shoulder."
    narrator "Garras pesadas presionando tu hombro."

# game/dia2.rpy:3622
translate Spanish espelhob_c048bc0d:

    # mc "{sc=1}What is touching me?"
    mc "{sc=1}¿Qué me está tocando?"

# game/dia2.rpy:3624
translate Spanish espelhob_fc5cdaec:

    # b "An illusion."
    b "Una ilusión."

# game/dia2.rpy:3626
translate Spanish espelhob_78641705:

    # mc "{size=50}{cps=15}..."
    mc "{size=50}{cps=15}..."

# game/dia2.rpy:3632
translate Spanish espelhob_c85200a7:

    # b "This is the part where the other visitors usually say, {i}“What an impressive trick.”"
    b "Esta es la parte en la que los demás visitantes suelen decir: {i}“Qué truco tan impresionante”."

# game/dia2.rpy:3633
translate Spanish espelhob_ae0409ff:

    # b "But not you, right, guest? Your eyes, doubt."
    b "Pero tú no, ¿verdad, invitad[letra]? Tus ojos dudan."

# game/dia2.rpy:3637
translate Spanish espelhob_b578e562:

    # b "Hah, I suppose by now that doesn’t work on you anymore, does it? That’s fine."
    b "Ja, supongo que a estas alturas eso ya no funciona contigo, ¿verdad? Está bien."

# game/dia2.rpy:3642
translate Spanish espelhob_be7db01a:

    # b "It’s me,{w=0.5} guest. I just want to see you a little closer."
    b "Soy yo, invitad[letra].{w=0.5} Solo quiero verte un poco más de cerca."

# game/dia2.rpy:3643
translate Spanish espelhob_549f516c:

    # b "After all, not everyone makes it this far. But there’s no need to tremble, {i}I don’t bite."
    b "Después de todo, no todo el mundo llega tan lejos. Pero no hay que temblar, {i}yo no muerdo."

# game/dia2.rpy:3645
translate Spanish espelhob_b5fe7110:

    # mcp "(His voice, it sounds like it’s coming from behind me.)"
    mcp "(Su voz suena como si viniera detrás de mí.)"

# game/dia2.rpy:3649
translate Spanish espelhob_dcd99227:

    # b "I think I’ll keep an eye on you as well."
    b "Creo que también te estaré vigilando."

# game/dia2.rpy:3650
translate Spanish espelhob_76a6174d:

    # b "You can keep going, the mirror at the end of the hall is my personal favorite."
    b "Puedes continuar, el espejo al final del pasillo es mi favorito personal."

# game/dia2.rpy:3651
translate Spanish espelhob_bafc051c:

    # b "It’s intense."
    b "Es intenso."

# game/dia2.rpy:3671
translate Spanish espelhoc_00910677:

    # mcp "(Is this... really a mirror? It’s freezing in front of it.)"
    mcp "(¿Es esto... realmente un espejo? Hace mucho frío frente a él.)"

# game/dia2.rpy:3672
translate Spanish espelhoc_e96ea995:

    # mcp "(And those eyes, they look like they’re following me.)"
    mcp "(Y esos ojos parecen estar siguiéndome)."

# game/dia2.rpy:3674
translate Spanish espelhoc_4e85cb4d:

    # mc "Hello?"
    mc "¿Hola?"

# game/dia2.rpy:3675
translate Spanish espelhoc_6e0a6941:

    # mc "Can I leave now? Ticket guy?"
    mc "¿Puedo irme ahora? ¿Chico de los boletos?"

# game/dia2.rpy:3678
translate Spanish espelhoc_708b22e8:

    # narrator "{sc=2}{color=#e61ee6}{cps=10}{size=45}Come closer.{w}{cps=0} Come closer. Come closer. Come closer. \nCome closer. Come closer. Come closer. Come closer.{nw=0.5}"
    narrator "{sc=2}{color=#e61ee6}{cps=10}{size=45}Acércate.{w}{cps=0} Acércate. Acércate. Acércate. \nAcércate. Acércate. Acércate. Acércate.{nw=0.5}"

# game/dia2.rpy:3706
translate Spanish espelhoc_35b6feab:

    # mc "What--"
    mc "¿Qué...?"

# game/dia2.rpy:3738
translate Spanish cenaoculta2_e0ded725:

    # des "{b}She’s pretty, even though she’s one of them."
    des "{b}Ella es bonita, a pesar de ser de los suyos."

# game/dia2.rpy:3739
translate Spanish cenaoculta2_c0b70060:

    # des "{b}You’re right."
    des "{b}Tienes razón."

# game/dia2.rpy:3740
translate Spanish cenaoculta2_330ccd63:

    # des "{i}And if..."
    des "{i}Y si..."

# game/dia2.rpy:3752
translate Spanish cenaoculta2_8f87870a:

    # des "That one’s a problem."
    des "Ése es un problema."

# game/dia2.rpy:3756
translate Spanish cenaoculta2_ed9fa247:

    # des "{b}{size=35}Well, teach him some manners."
    des "{b}{size=35}Bueno, enséñale algunos modales."

# game/dia2.rpy:3771
translate Spanish cenaoculta2_f178f80c:

    # narrator "{color=#961ee6}Maybe he’ll be the first to fall."
    narrator "{color=#961ee6}Tal vez sea el primero en caer."

# game/dia2.rpy:3772
translate Spanish cenaoculta2_f8c9e5e8:

    # narrator "{color=#961ee6}And then one by one we’ll wither away in this pit {glitch=2}{sc=80}{color=#41d623}A.Q.RLE{/glitch}"
    narrator "{color=#961ee6}Y luego, uno por uno, nos marchitaremos en este pozo {glitch=2}{sc=80}{color=#41d623}A.Q.RLE{/glitch}"

# game/dia2.rpy:3773
translate Spanish cenaoculta2_98812f46:

    # narrator "{color=#961ee6}I will, feed him."
    narrator "{color=#961ee6}Lo haré, le daré de comer."

# game/dia2.rpy:3774
translate Spanish cenaoculta2_c7719702:

    # narrator "{color=#41d623}... Wait."
    narrator "{color=#41d623}... Espera."

# game/dia2.rpy:3780
translate Spanish cenaoculta2_920b312f:

    # des "One more."
    des "Uno más."

# game/dia2.rpy:3784
translate Spanish cenaoculta2_a41decb3:

    # narrator "{color=#e61ee6}I’m scared. If they try to touch me again..."
    narrator "{color=#e61ee6}Tengo miedo. Si intentan tocarme otra vez..."

# game/dia2.rpy:3785
translate Spanish cenaoculta2_1bbb22d8:

    # narrator "{color=#e61ee6}Will you save me?"
    narrator "{color=#e61ee6}¿Me salvarás?"

# game/dia2.rpy:3786
translate Spanish cenaoculta2_6700ab21:

    # narrator "{color=#41d623}Save...?"
    narrator "{color=#41d623}¿Salvar...?"

# game/dia2.rpy:3788
translate Spanish cenaoculta2_2e650376:

    # des "Tomorrow, we’ll {i}relocate{/i} her. The others, we’ll let them starve."
    des "Mañana la {i}reubicaremos{/i}. A los demás los dejaremos morir de hambre."

# game/dia2.rpy:3789
translate Spanish cenaoculta2_ac33a784:

    # des "They’re too dangerous to keep."
    des "Son demasiado peligrosos para conservarlos."

# game/dia2.rpy:3790
translate Spanish cenaoculta2_9b5c587e:

    # des "You’re right, we won’t risk it. She’ll be useful for something."
    des "Tienes razón, no nos arriesgaremos. Ella será útil para algo."

# game/dia2.rpy:3794
translate Spanish cenaoculta2_df945671:

    # narrator "{color=#4153f7}Moonless night."
    narrator "{color=#4153f7}Noche sin luna."

# game/dia2.rpy:3795
translate Spanish cenaoculta2_a2615d78:

    # narrator "{color=#e74c3c}Maybe this will be our last one."
    narrator "{color=#e74c3c}Quizás esta sea la última."

# game/dia2.rpy:3796
translate Spanish cenaoculta2_62a2d3b8:

    # narrator "{color=#e74c3c}I'm so hungry."
    narrator "{color=#e74c3c}Tengo tanta hambre."

# game/dia2.rpy:3797
translate Spanish cenaoculta2_17104f25:

    # narrator "{color=#4153f7}Me too... how long has it been... since we last ate?"
    narrator "{color=#4153f7}Yo también... ¿cuánto tiempo ha pasado... desde la última vez que comimos?"

# game/dia2.rpy:3799
translate Spanish cenaoculta2_e8630812:

    # narrator "{color=#961ee6}I can’t move.{glitch=2}{sc=70}{color=#ffaf54}/P.TOR{/glitch}{/sc}{color=#961ee6} is alive...?"
    narrator "{color=#961ee6}No puedo moverme. ¿{glitch=2}{sc=70}{color=#ffaf54}/P.TOR{/glitch}{/sc}{color=#961ee6} está vivo...?"

# game/dia2.rpy:3800
translate Spanish cenaoculta2_587aac47:

    # narrator "{sc=1}{cps=15}{size=35}{b}{color=#ffaf54}......"
    narrator "{sc=1}{cps=15}{size=35}{b}{color=#ffaf54}......"

# game/dia2.rpy:3803
translate Spanish cenaoculta2_b433e0dd:

    # narrator "{sc=1}{color=#e61ee6}I’m scared."
    narrator "{sc=1}{color=#e61ee6}Tengo miedo."

# game/dia2.rpy:3804
translate Spanish cenaoculta2_fc1a1882:

    # narrator "{color=#41d623}You’re the weakest one."
    narrator "{color=#41d623}Eres la más débil."

# game/dia2.rpy:3805
translate Spanish cenaoculta2_3c3ad777:

    # narrator "{sc=2}{color=#e61ee6}Thank you."
    narrator "{sc=2}{color=#e61ee6}Gracias."

# game/dia2.rpy:3815
translate Spanish cenaoculta2_1e69b2b9:

    # narrator "{sc=1}{color=#4153f7}Why... did you do that?"
    narrator "{sc=1}{color=#4153f7}¿Por qué... hiciste eso?"

# game/dia2.rpy:3816
translate Spanish cenaoculta2_337ba031:

    # narrator "{color=#961ee6}There’s no turning back now."
    narrator "{color=#961ee6}Ya no hay vuelta atrás."

# game/dia2.rpy:3817
translate Spanish cenaoculta2_a6ff0d3a:

    # narrator "{sc=1}{color=#ffaf54}No... {sc=3}{color=#ffaf54}no... {sc=5}{color=#ffaf54}no..."
    narrator "{sc=1}{color=#ffaf54}No... {sc=3}{color=#ffaf54}no... {sc=5}{color=#ffaf54}no..."

# game/dia2.rpy:3825
translate Spanish cenaoculta2_71d0b49d:

    # narrator "{color=#41d623}{b}{size=45}EAT!"
    narrator "{color=#41d623}{b}{size=45}¡COME!"

# game/dia2.rpy:3826
translate Spanish cenaoculta2_0fc46b4f:

    # narrator "{sc=1}{color=#ffaf54}Why... are you smiling?"
    narrator "{sc=1}{color=#ffaf54}¿Por qué... estás sonriendo?"

# game/dia2.rpy:3827
translate Spanish cenaoculta2_8c9f48aa:

    # narrator "{color=#e61ee6}No."
    narrator "{color=#e61ee6}No."

# game/dia2.rpy:3828
translate Spanish cenaoculta2_56a93129:

    # narrator "{sc=5}{color=#41d623}Hah...{w}HaHahhhahahahha!"
    narrator "{sc=5}{color=#41d623}Hah...{w}¡JaHahahhhahahahha!"

# game/dia2.rpy:3829
translate Spanish cenaoculta2_bf0a5fa1:

    # narrator "{sc=8}{color=#41d623}{b}HAHAHHAHAHHAHAHAHHHHAAAHHH!"
    narrator "{sc=8}{color=#41d623}{b}¡HAHAHHAHAHHAHAHAHHHHAAAHHH!"

# game/dia2.rpy:3830
translate Spanish cenaoculta2_69a260ff:

    # narrator "{color=#961ee6}Sorry... {glitch=2}{sc=80}{color=#41d623}A.Q.RLE."
    narrator "{color=#961ee6}Lo siento... {glitch=2}{sc=80}{color=#41d623}A.Q.RLE."

# game/dia2.rpy:3833
translate Spanish cenaoculta2_3d38ee30:

    # narrator "{color=#e61ee6}He wasn’t..."
    narrator "{color=#e61ee6}Él no era..."

# game/dia2.rpy:3851
translate Spanish cenaoculta2_7e1a86c0:

    # narrator "Your eyes burn, like you haven’t blinked in a long time."
    narrator "Te arden los ojos, como si no hubieras parpadeado en mucho tiempo."

# game/dia2.rpy:3852
translate Spanish cenaoculta2_313aa57c:

    # narrator "{color=#e61ee6}Thank you."
    narrator "{color=#e61ee6}Gracias."

# game/dia2.rpy:3853
translate Spanish cenaoculta2_0c17a187:

    # narrator "{color=#e61ee6}It’s been so long."
    narrator "{color=#e61ee6}Ha pasado tanto tiempo."

# game/dia2.rpy:3854
translate Spanish cenaoculta2_602927b8:

    # narrator "{color=#e61ee6}Each one of them crafted their own shield, when remembering that day."
    narrator "{color=#e61ee6}Cada uno de ellos elaboró su propio escudo, al recordar aquel día."

# game/dia2.rpy:3855
translate Spanish cenaoculta2_c1620cea:

    # narrator "{color=#e61ee6}To protect themselves, each in their own distorted way."
    narrator "{color=#e61ee6}Para protegerse, cada uno a su manera distorsionada."

# game/dia2.rpy:3857
translate Spanish cenaoculta2_88365040:

    # narrator "{color=#e61ee6}I just wanted to tell someone."
    narrator "{color=#e61ee6}Solo quería decírselo a alguien."

# game/dia2.rpy:3865
translate Spanish cenaoculta2_9bf3d38d:

    # mc "{sc=2}My god..."
    mc "{sc=2}Dios mío..."

# game/dia2.rpy:3868
translate Spanish cenaoculta2_c10cdaaa:

    # mc "{sc=1}what does that even mean?"
    mc "{sc=1}¿Qué significa eso?"

# game/dia2.rpy:3888
translate Spanish semcoragem_paraoespelho_04da123d:

    # mc "The exit!!"
    mc "¡¡La salida!!"

# game/dia2.rpy:3901
translate Spanish semcoragem_paraoespelho_09498d56:

    # mc "{sc=1}What was all that?..."
    mc "{sc=1}¿Qué fue todo eso?..."

# game/dia2.rpy:3905
translate Spanish semcoragem_paraoespelho_c14b805d:

    # b "Congratulations, you made it, guest. You reached the end of my tent."
    b "Felicitaciones, lo lograste, invitad[letra]. Llegaste al final de mi carpa."

# game/dia2.rpy:3907
translate Spanish semcoragem_paraoespelho_1e4a35f8:

    # mc "{b}You!!{/b}{w=0.3} You were in there, weren’t you!?"
    mc "{b}¡¡Tú!!{/b}{w=0.3} Estabas ahí, ¿no?"

# game/dia2.rpy:3912
translate Spanish semcoragem_paraoespelho_10177ab1:

    # b "Hahaha..."
    b "Jajaja..."

# game/dia2.rpy:3913
translate Spanish semcoragem_paraoespelho_015a42f1:

    # b "{i} \"Don’t trust your eyes.\" "
    b "{i}\"No confíes en tus ojos.\" "

# game/dia2.rpy:3915
translate Spanish semcoragem_paraoespelho_260e682c:

    # mc "It felt too real to be an illusion!" with hpunch
    mc "¡Se sentía demasiado real para ser una ilusión!" with hpunch

# game/dia2.rpy:3919
translate Spanish semcoragem_paraoespelho_85f36bdf:

    # b "Thank you for entertaining me."
    b "Gracias por entretenerme."

# game/dia2.rpy:3920
translate Spanish semcoragem_paraoespelho_011709d8:

    # b "{cps=15}Red ticket guest."
    b "{cps=15}Invitad[letra] del boleto rojo."

# game/dia2.rpy:3924
translate Spanish semcoragem_paraoespelho_8941c739:

    # mc "And he’s gone."
    mc "Y se ha ido."

# game/dia2.rpy:3926
translate Spanish semcoragem_paraoespelho_549cebeb:

    # narrator "You take a deep breath, trying to calm yourself down."
    narrator "Respiras profundamente, intentando calmarte."

# game/dia2.rpy:3938
translate Spanish tenda_preta_bed49ae9:

    # mcp "(Maybe it’s something VIP, there’s a short line, and they all have black tickets, I think?)"
    mcp "(Tal vez sea algo VIP, hay una fila corta y todos tienen boletos negros, ¿creo?)"

# game/dia2.rpy:3939
translate Spanish tenda_preta_385fb344:

    # mcp "(But wow, even the shortest ones there are still taller than me.)"
    mcp "(Pero vaya, incluso los más bajos siguen siendo más altos que yo)."

# game/dia2.rpy:3941
translate Spanish tenda_preta_7d71d0a5:

    # des "{size=35}Damn, look at those weirdos!" with vpunch
    des "{size=35}¡Maldita sea, mira esos bichos raros!" with vpunch

# game/dia2.rpy:3942
translate Spanish tenda_preta_42ad5611:

    # des "You think the circus is hiring more freaks?"
    des "¿Crees que el circo está contratando más monstruos?"

# game/dia2.rpy:3943
translate Spanish tenda_preta_d6f40072:

    # des "HHAH!"
    des "¡HAA!"

# game/dia2.rpy:3948
translate Spanish tenda_preta_f4c9dac4:

    # b "Hello there, guest with the red ticket. I’m sorry, but as I’ve said before."
    b "Hola, invitad[letra] del boleto rojo. Lo siento, pero como dije antes."

# game/dia2.rpy:3953
translate Spanish tenda_preta_f53f769b:

    # b "Your ticket doesn’t allow entry into this area."
    b "Tu boleto no permite la entrada a esta zona."

# game/dia2.rpy:3955
translate Spanish tenda_preta_1fee746b:

    # mc "Right, right. I’m leaving."
    mc "Bien, bien. Me voy."

# game/dia2.rpy:3959
translate Spanish tenda_preta_950b42c5:

    # mcp "(He didn’t take his eyes off me until I actually walked away.)"
    mcp "(No me quitó los ojos de encima hasta que me alejé.)"

# game/dia2.rpy:3971
translate Spanish tenda_preta_79a71cd9:

    # b "You... heard what I said before, right?"
    b "Tú... escuchaste lo que dije antes, ¿verdad?"

# game/dia2.rpy:3972
translate Spanish tenda_preta_49740d67:

    # b "{b}{cps=20}Your ticket doesn’t allow entry into this tent."
    b "{b}{cps=20}Tu boleto no permite la entrada a esta carpa."

# game/dia2.rpy:3974
translate Spanish tenda_preta_34fcb8bd:

    # mc "Ah! right, got it, got it. I was just... uh."
    mc "¡Ah! Claro, entendido, entendido. Yo solo estaba... eh."

# game/dia2.rpy:3975
translate Spanish tenda_preta_5f98152b:

    # mc "How can I get that kind of ticket?"
    mc "¿Cómo puedo conseguir ese tipo de boleto?"

# game/dia2.rpy:3976
translate Spanish tenda_preta_ddb7441f:

    # b "They’re already sold out. Please, return to the common area."
    b "Ya están agotados. Por favor, regresa al área común."

# game/dia2.rpy:3978
translate Spanish tenda_preta_75b90578:

    # mc "Right, sorry."
    mc "Bien, lo siento."

# game/dia2.rpy:3990
translate Spanish tenda_preta_83cb89a2:

    # b "Sorry, I couldn’t get rid of the bag in time."
    b "Lo siento, no pude deshacerme de la bolsa a tiempo."

# game/dia2.rpy:3991
translate Spanish tenda_preta_5daa49f1:

    # j "I noticed, believe me."
    j "Me di cuenta, créeme."

# game/dia2.rpy:3992
translate Spanish tenda_preta_9871df38:

    # j "But don’t worry, old friend, we always find a way."
    j "Pero no te preocupes, viejo amigo, siempre encontramos la manera."

# game/dia2.rpy:3993
translate Spanish tenda_preta_d332a732:

    # j "You did a great job with what you could. Now keep your eyes open..."
    j "Hiciste un gran trabajo con lo que pudiste. Ahora mantén los ojos abiertos..."

# game/dia2.rpy:4002
translate Spanish tenda_preta_05cc685d:

    # j "Especially{cps=10} for little curious mice..."
    j "Especialmente{cps=10} para los ratoncitos curiosos..."

# game/dia2.rpy:4004
translate Spanish tenda_preta_e232d0b3:

    # mc "!!!"
    mc "!!!"

# game/dia2.rpy:4009
translate Spanish tenda_preta_31742ed3:

    # mcp "(It looks empty now.)"
    mcp "(Parece vacío ahora)."

# game/dia2.rpy:4017
translate Spanish sobrevivente_1599dc83:

    # mcp "(What was all that? I felt such an intense sense of threat… just like Pierrot said.)"
    mcp "(¿Qué fue todo eso? Sentí una sensación de amenaza tan intensa... tal como dijo Pierrot)."

# game/dia2.rpy:4018
translate Spanish sobrevivente_5481bf9c:

    # mcp "(Maybe if I knew a bit more, I… I feel like I wouldn’t have walked out of any of those circus tents… I should just leave.)"
    mcp "(Tal vez si supiera un poco más, yo… siento que no habría salido de ninguna de esas carpas de circo… simplemente debería irme.)"

# game/dia2.rpy:4024
translate Spanish sobrevivente_4a5e5694:

    # mc "???"
    mc "???"

# game/dia2.rpy:4031
translate Spanish sobrevivente_b1954807:

    # p "My apologies, [titulo_pierrot]. I didn’t mean for you to scream."
    p "Mis disculpas, [titulo_pierrot!t]. No quise que gritaras."

# game/dia2.rpy:4035
translate Spanish sobrevivente_8b43c390:

    # mc "Pierrot..."
    mc "Pierrot..."

# game/dia2.rpy:4039
translate Spanish sobrevivente_78109a99:

    # p "I’m sorry, [mc_nome], for dragging you into all of this. I never meant to involve you but..."
    p "Lo siento, [mc_nome], por arrastrarte a todo esto. Nunca quise involucrarte pero..."

# game/dia2.rpy:4044
translate Spanish sobrevivente_f2c792df:

    # p "I’m incapable of staying away from you. Even if it’s to protect you, I simply can’t."
    p "Soy incapaz de alejarme de ti. Incluso si es para protegerte, simplemente no puedo."

# game/dia2.rpy:4045
translate Spanish sobrevivente_ccc865f3:

    # p "But I promise you, if you stay with me, I won’t let anything bad happen to you."
    p "Pero te prometo que si te quedas conmigo no dejaré que te pase nada malo."

# game/dia2.rpy:4047
translate Spanish sobrevivente_2485f494:

    # mc "I..."
    mc "Yo..."

# game/dia2.rpy:4051
translate Spanish sobrevivente_12433fc9:

    # p "It’s alright, [titulo_pierrot]. You don’t need to answer me now."
    p "Está bien, [titulo_pierrot!t]. No necesitas responderme ahora."

# game/dia2.rpy:4052
translate Spanish sobrevivente_f7d80f55:

    # p "You’re scared I can wait."
    p "Tienes miedo. Puedo esperar."

# game/dia2.rpy:4055
translate Spanish sobrevivente_e0caa00c:

    # p "Ohh... Your scent... it’s exquisite."
    p "Ohh... Tu aroma... es exquisito."

# game/dia2.rpy:4057
translate Spanish sobrevivente_139f288e:

    # mc "Uh... hah!"
    mc "¡Eh... ja!"

# game/dia2.rpy:4061
translate Spanish sobrevivente_b4f5f260:

    # p "F-forgive me!"
    p "¡P-perdóname!"

# game/dia2.rpy:4063
translate Spanish sobrevivente_5dac696d:

    # mc "Pierrot, aren’t you mistaking me for someone else? We just met..."
    mc "Pierrot, ¿no me estás confundiendo con otra persona? Nos acabamos de conocer..."

# game/dia2.rpy:4066
translate Spanish sobrevivente_a8d202c3:

    # p "No, [titulo_pierrot], you’re something new in my life, you made my heart beat differently."
    p "No, [titulo_pierrot!t], eres algo nuevo en mi vida, hiciste que mi corazón latiera diferente."

# game/dia2.rpy:4067
translate Spanish sobrevivente_fc47be82:

    # p "I know who you are, and I want to know... more."
    p "Sé quién eres y quiero saber... más."

# game/dia2.rpy:4068
translate Spanish sobrevivente_cd69f7a4:

    # p "Even if we belong to different worlds... I can’t help but love you."
    p "Incluso si pertenecemos a mundos diferentes... no puedo evitar amarte."

# game/dia2.rpy:4072
translate Spanish sobrevivente_2876efd9:

    # mc "Why?"
    mc "¿Por qué?"

# game/dia2.rpy:4074
translate Spanish sobrevivente_fe401b1e:

    # p "Because you, are {b}you."
    p "Porque tú eres {b}tú."

# game/dia2.rpy:4075
translate Spanish sobrevivente_e7da457f:

    # p "I can feel it, and nothing in this world could be more real than that."
    p "Puedo sentirlo y nada en este mundo podría ser más real que eso."

# game/dia2.rpy:4076
translate Spanish sobrevivente_7229c768:

    # p "{cps=50}You are my destiny."
    p "{cps=50}Tú eres mi destino."

# game/dia2.rpy:4078
translate Spanish sobrevivente_2b35b6fe:

    # mc "..."
    mc "..."

# game/dia2.rpy:4080
translate Spanish sobrevivente_49b8c6b2:

    # p "I’ll let you return home, [titulo_pierrot]. Please, go safely."
    p "Te dejaré volver a casa, [titulo_pierrot!t]. Por favor, ve con cuidado."

# game/dia2.rpy:4081
translate Spanish sobrevivente_486fdccc:

    # p "I must stay behind to make sure everything is under control."
    p "Debo quedarme atrás para asegurarme de que todo esté bajo control."

# game/dia2.rpy:4085
translate Spanish sobrevivente_b76d1929:

    # mc "You really are intense all the time, huh?"
    mc "Realmente eres intenso todo el tiempo, ¿eh?"

# game/dia2.rpy:4087
translate Spanish sobrevivente_980a3fa7:

    # p "Until tomorrow, [titulo_pierrot]."
    p "Hasta mañana, [titulo_pierrot!t]."

# game/dia2.rpy:4089
translate Spanish sobrevivente_d5f2cfaa:

    # mc "Good night, Pierrot."
    mc "Buenas noches, Pierrot."

# game/dia2.rpy:4091
translate Spanish sobrevivente_78906409:

    # p "Good night, [mc_nome]."
    p "Buenas noches, [mc_nome]."

# game/dia2.rpy:4096
translate Spanish sobrevivente_1c4c7f60:

    # narrator "You take your way home, reflecting on the exhausting day."
    narrator "Regresas a casa, reflexionando sobre el día agotador."

# game/dia2.rpy:4100
translate Spanish sobrevivente_97d34034:

    # mcp "(This time, it wasn’t a question, he just said he’d come tomorrow.)"
    mcp "(Esta vez no fue una pregunta, solo dijo que vendría mañana)."

# game/dia2.rpy:4101
translate Spanish sobrevivente_80fefdb1:

    # mcp "(Which means, no matter what I said at this point, he’d come to me anyway.)"
    mcp "(Lo que significa que, no importa lo que dijera en este momento, él vendría a verme de todos modos)."

# game/dia2.rpy:4102
translate Spanish sobrevivente_f852494a:

    # mcp "(And… I think I like that.)"
    mcp "(Y... creo que eso me gusta)."

# game/dia2.rpy:4109
translate Spanish sobrevivente_e232d0b3:

    # mc "!!!"
    mc "!!!"

# game/dia2.rpy:4110
translate Spanish sobrevivente_d9d300ad:

    # mc "Damn..."
    mc "Maldita sea..."

# game/dia2.rpy:4112
translate Spanish sobrevivente_d425e867:

    # mcp "(I’d better hurry...)"
    mcp "(Será mejor que me dé prisa...)"

# game/dia2.rpy:4116
translate Spanish sobrevivente_d10b515c:

    # narrator "You feel something heavy as you walk, though you’re not sure if it’s the eerie atmosphere of the circus..."
    narrator "Sientes algo pesado mientras caminas, aunque no estás segur[letra] de si es la atmósfera espeluznante del circo..."

# game/dia2.rpy:4118
translate Spanish sobrevivente_7b7f44b1:

    # narrator "Or the weight of new eyes watching you in the dark."
    narrator "O el peso de nuevos ojos que te miran en la oscuridad."

# game/dia2.rpy:4139
translate Spanish cenaoculta1_1d15d6c7:

    # j "Bil."
    j "Bil."

# game/dia2.rpy:4145
translate Spanish cenaoculta1_74563156:

    # b "Yes?"
    b "¿Sí?"

# game/dia2.rpy:4147
translate Spanish cenaoculta1_f665bd15:

    # j "Keep an eye on our visitor, will you?"
    j "Vigila a nuestro visitante, ¿quieres?"

# game/dia2.rpy:4154
translate Spanish cenaoculta1_0bd58576:

    # b "With pleasure, Jester."
    b "Con mucho gusto, Bufón."

# game/dia2.rpy:4156
translate Spanish cenaoculta1_9b8d6cd4:

    # j "Harlequin."
    j "Arlequín."

# game/dia2.rpy:4165
translate Spanish cenaoculta1_f0b4a189:

    # a "Oh? No nicknames for me?"
    a "¿Oh? ¿No hay apodos para mí?"

# game/dia2.rpy:4173
translate Spanish cenaoculta1_46f06489:

    # j "I know where your eyes are. Don’t make me remind you, {b}don’t{/b} break the rules."
    j "Sé dónde tienes puesta la mirada. No me obligues a recordarte que {b}no{/b} debes romper las reglas."

# game/dia2.rpy:4175
translate Spanish cenaoculta1_ac99af0a:

    # a "What do you take me for?"
    a "¿Por quién me tomas?"

# game/dia2.rpy:4177
translate Spanish cenaoculta1_8f0cd59b:

    # j "Too deceitful for me to trust your words."
    j "Eres demasiado engañoso como para que confíe en tus palabras."

# game/dia2.rpy:4183
translate Spanish cenaoculta1_03def996:

    # a "Such hypocrisy, Jester ♪"
    a "Qué hipocresía, Bufón ♪"

# game/dia2.rpy:4187
translate Spanish cenaoculta1_e878a0fb:

    # a "You think I don’t see that crooked smile behind your mask?"
    a "¿Crees que no veo esa sonrisa torcida detrás de tu máscara?"

# game/dia2.rpy:4189
translate Spanish cenaoculta1_2d9031a7:

    # j "That little thing might be useful. Who knows."
    j "Esa cosita podría resultar útil. Quién sabe."

# game/dia2.rpy:4194
translate Spanish cenaoculta1_9bce166f:

    # doc "I agree. If we need to take extreme measures in the end, I want this one."
    doc "Estoy de acuerdo. Si al final necesitamos tomar medidas extremas, me quedo con [persistent.p_sujeito!t]."

# game/dia2.rpy:4197
translate Spanish cenaoculta1_adb760f9:

    # a "Hah, [persistent.p_sujeito]'ve got hungry eyes, curious about everything this circus breathes. So, if [persistent.p_sujeito] keep coming back to your tent."
    a "Ja, [persistent.p_sujeito!t] tiene ojos hambrientos, curiosos por todo lo que respira este circo. Así que, si [persistent.p_sujeito!t] sigue volviendo a tu carpa."

# game/dia2.rpy:4199
translate Spanish cenaoculta1_ae810deb:

    # a "Hah, [persistent.p_sujeito]'s got hungry eyes, curious about everything this circus breathes. So, if [persistent.p_sujeito] keeps coming back to your tent."
    a "Ja, [persistent.p_sujeito!t] tiene ojos hambrientos, curiosos por todo lo que respira este circo. Así que, si [persistent.p_sujeito!t] sigue volviendo a tu carpa."

# game/dia2.rpy:4202
translate Spanish cenaoculta1_e5cc9149:

    # a "You’ll keep your claws off [persistent.p_objeto], won’t you?"
    a "Mantendrás tus garras lejos de [persistent.p_sujeito!t], ¿verdad?"

# game/dia2.rpy:4204
translate Spanish cenaoculta1_e5cc9149_1:

    # a "You’ll keep your claws off [persistent.p_objeto], won’t you?"
    a "Mantendrás tus garras lejos de [persistent.p_sujeito!t], ¿verdad?"

# game/dia2.rpy:4206
translate Spanish cenaoculta1_e01a14a5:

    # j "You’ve already forgotten that night, haven’t you, Harlequin? Need me to remind you that Pierrot’s claws are sharper?"
    j "Ya has olvidado esa noche, ¿no, Arlequín? ¿Necesitas que te recuerde que las garras de Pierrot son más afiladas?"

# game/dia2.rpy:4207
translate Spanish cenaoculta1_a07ddadf:

    # j "He was tamed once, and you know it won’t happen again. Your poison isn’t stronger than him."
    j "Una vez lograron dominarlo, y sabes que no volverá a pasar. Tu veneno no puede con él."

# game/dia2.rpy:4209
translate Spanish cenaoculta1_d81aeaca:

    # a "Isn’t it? I’d love to find out."
    a "¿No es así? Me encantaría saberlo."

# game/dia2.rpy:4212
translate Spanish cenaoculta1_2f1bb4aa:

    # doc "Good luck, Harlequin."
    doc "Buena suerte, Arlequín."

# game/dia2.rpy:4223
translate Spanish cenaoculta1_6dc43d40:

    # b "{i}Sighs."
    b "{i}Suspiros."

# game/dia2.rpy:4226
translate Spanish cenaoculta1_b5f72d4c:

    # j "Those two are a real headache."
    j "Esos dos son un verdadero dolor de cabeza."

translate Spanish strings:

    # game/dia2.rpy:7
    old "Doctor"
    new "Doctor"

    # game/dia2.rpy:9
    old "The Poison"
    new "El Veneno"

    # game/dia2.rpy:10
    old "Columbina"
    new "Columbina"

    # game/dia2.rpy:11
    old "Unknown 2"
    new "Desconocido 2"

    # game/dia2.rpy:235
    old "Yeah, I ate"
    new "Sí, comí"

    # game/dia2.rpy:246
    old "No, I didn’t eat"
    new "No, no comí"

    # game/dia2.rpy:258
    old "Yeah, I did"
    new "Sí, lo hice"

    # game/dia2.rpy:268
    old "Actually, no"
    new "En realidad, no"

    # game/dia2.rpy:568
    old "Step back"
    new "Dar un paso atrás"

    # game/dia2.rpy:572
    old "Allow him"
    new "Permitírselo"

    # game/dia2.rpy:724
    old "Scream"
    new "Gritar"

    # game/dia2.rpy:741
    old "Keep quiet"
    new "Guardar silencio"

    # game/dia2.rpy:809
    old "Please go away"
    new "Por favor, vete"

    # game/dia2.rpy:832
    old "Hold his hand"
    new "Tomarle la mano"

    # game/dia2.rpy:1038
    old "{sc=1.5}I think I got lost"
    new "{sc=1.5}Creo que me perdí"

    # game/dia2.rpy:1046
    old "{sc=1.5}I was just passing by"
    new "{sc=1.5}Estaba de paso"

    # game/dia2.rpy:1366
    old "Ask about the fools"
    new "Preguntar por los tontos"

    # game/dia2.rpy:1377
    old "Drop it"
    new "Dejarlo"

    # game/dia2.rpy:1511
    old "Move away"
    new "Alejarse"

    # game/dia2.rpy:1530
    old "Follow him"
    new "Seguirlo"

    # game/dia2.rpy:1716
    old "Hit him"
    new "Golpearlo"

    # game/dia2.rpy:1744
    old "Allow"
    new "Permitir"

    # game/dia2.rpy:1913
    old "Stand still"
    new "Quedarse quiet[letra]"

    # game/dia2.rpy:1934
    old "Try to run"
    new "Intentar huir"

    # game/dia2.rpy:2052
    old "Yes, I need some space."
    new "Sí, necesito algo de espacio."

    # game/dia2.rpy:2086
    old "No, you can stay."
    new "No, puedes quedarte."

    # game/dia2.rpy:2102
    old "Stay like this"
    new "Quedarse así"

    # game/dia2.rpy:2105
    old "Pet him"
    new "Acariciarlo"

    # game/dia2.rpy:2196
    old "Agree"
    new "Estar de acuerdo"

    # game/dia2.rpy:2221
    old "Deny"
    new "Negar"

    # game/dia2.rpy:2298
    old "Apologize"
    new "Disculparse"

    # game/dia2.rpy:2335
    old "Hug"
    new "Abrazar"

    # game/dia2.rpy:2456
    old "So...?"
    new "¿Entonces...?"

    # game/dia2.rpy:2467
    old "No, thanks"
    new "No, gracias"

    # game/dia2.rpy:2535
    old "Of course! I said I’d come back!"
    new "¡Por supuesto! ¡Dije que volvería!"

    # game/dia2.rpy:2537
    old "Yes! That’s me! I just can’t stay away from this place."
    new "¡Sí! ¡Soy yo! Simplemente no puedo alejarme de este lugar."

    # game/dia2.rpy:2569
    old "Blue Tent"
    new "Carpa azul"

    # game/dia2.rpy:2572
    old "{color=#2b2b2b}Blue Tent{/color}"
    new "{color=#2b2b2b}Carpa azul{/color}"

    # game/dia2.rpy:2575
    old "Cyan Tent"
    new "Carpa cian"

    # game/dia2.rpy:2578
    old "{color=#2b2b2b}Cyan Tent{/color}"
    new "{color=#2b2b2b}Carpa cian{/color}"

    # game/dia2.rpy:2581
    old "Purple Tent"
    new "Carpa morada"

    # game/dia2.rpy:2590
    old "Black Tent"
    new "Carpa negra"

    # game/dia2.rpy:2731
    old "React"
    new "Reaccionar"

    # game/dia2.rpy:2784
    old "Still"
    new "Aun así"

    # game/dia2.rpy:2839
    old "Accept"
    new "Aceptar"

    # game/dia2.rpy:2983
    old "{glitch=20}{b}{color=#e61ee6}PlEASE, NO!{/glitch}"
    new "{glitch=20}{b}{color=#e61ee6}¡POR FAVOR, NO!{/glitch}"

    # game/dia2.rpy:3030
    old "{glitch=30}{b}{color=#e61ee6}But something inside you scares me.{/glitch}"
    new "{glitch=30}{b}{color=#e61ee6}Pero algo dentro de ti me asusta.{/glitch}"

    # game/dia2.rpy:3056
    old "{glitch=20}{b}{color=#e61ee6}P-please… don’t {sc=80}{color=#41d623}A.Q.RLE {/glitch}"
    new "{glitch=20}{b}{color=#e61ee6}P-por favor… no {sc=80}{color=#41d623}A.Q.RLE {/glitch}"

    # game/dia2.rpy:3075
    old "{glitch=20}{b}{color=#4153f7}Why… did you do that?{/glitch}"
    new "{glitch=20}{b}{color=#4153f7}¿Por qué… hiciste eso?{/glitch}"

    # game/dia2.rpy:3080
    old "{glitch=20}{b}{color=#41d623}Is your {b}hate{/b} on me?{/glitch}"
    new "{glitch=20}{b}{color=#41d623}¿Tu {b}odio{/b} va dirigido a mí?{/glitch}"

    # game/dia2.rpy:3085
    old "{glitch=20}{b}{color=#41d623}Someone had to do it…{w=0.2} obviously.{/glitch}"
    new "{glitch=20}{b}{color=#41d623}Alguien tenía que hacerlo…{w=0.2} obviamente.{/glitch}"

    # game/dia2.rpy:3087
    old "{glitch=20}{b}{color=#961ee6}There’s no turning back now.{/glitch}"
    new "{glitch=20}{b}{color=#961ee6}Ya no hay vuelta atrás.{/glitch}"

    # game/dia2.rpy:3091
    old "{glitch=20}{b}{color=#ffaf54}No... no no no...{/glitch}"
    new "{glitch=20}{b}{color=#ffaf54}No... no no no...{/glitch}"

    # game/dia2.rpy:3093
    old "{glitch=20}{b}{color=#41d623}{size=50}EAT{/glitch}"
    new "{glitch=20}{b}{color=#41d623}{size=50}COME{/glitch}"

    # game/dia2.rpy:3097
    old "{glitch=20}{b}{color=#ffaf54}I’ll find a way… we’ll be together forever.{/glitch}"
    new "{glitch=20}{b}{color=#ffaf54}Encontraré una manera... estaremos juntos para siempre.{/glitch}"

    # game/dia2.rpy:3212
    old "I chose to come."
    new "Elegí venir."

    # game/dia2.rpy:3220
    old "Someone asked me to come."
    new "Alguien me pidió que viniera."

    # game/dia2.rpy:3263
    old "Hidden scene unlocked 🔓"
    new "Escena oculta desbloqueada 🔓"

    # game/dia2.rpy:3559
    old "Obey."
    new "Obedecer."

    # game/dia2.rpy:3567
    old "Turn around."
    new "Darse la vuelta."

    # game/dia2.rpy:3682
    old "{color=#e61ee6}Run away."
    new "{color=#e61ee6}Huir."

    # game/dia2.rpy:3689
    old "{color=#e61ee6}Come closer."
    new "{color=#e61ee6}Acércate."

    # game/dia2.rpy:4125
    old "{size=80}{font=Freakshow.ttf}End of Chapter 1"
    new "{size=80}{font=Freakshow.ttf}Fin del Capítulo 1"

    # game/dia2.rpy:4127
    old "{size=40}Stay tuned for upcoming updates on the official website:\n{a=https://garula.itch.io/the-freak-circus}https://garula.itch.io/the-freak-circus{/a}"
    new "{size=40}Estén atentos a las próximas actualizaciones en el sitio web oficial:\n{a=https://garula.itch.io/the-freak-circus}https://garula.itch.io/the-freak-circus{/a}"

    # game/dia2.rpy:4258
    old "Thank you for the support!"
    new "¡Gracias por el apoyo!"

    # game/dia2.rpy:4259
    old "{size=30}{i}Max tier Patreon Pierrot's Love"
    new "{size=30}{i}Nivel máximo de Patreon: Pierrot's Love"

    # game/dia2.rpy:4260
    old "{color=#d31507}Lovestruck:"
    new "{color=#d31507}Enamorado:"

    # game/dia2.rpy:4330
    old "{color=#f10a0a}⭐ Thank you for the support! ⭐"
    new "{color=#f10a0a}⭐ ¡Gracias por el apoyo! ⭐"

    # game/dia2.rpy:4331
    old "{size=30}{i}Patreon Supporters"
    new "{size=30}{i}Mecenas de Patreon"

