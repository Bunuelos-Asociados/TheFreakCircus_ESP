# TODO: Translation updated at 2026-10-03 14:34

translate Spanish strings:

    # game/screens.rpy:342
    old "{font=Freakshow.ttf}Start"
    new "{font=Freakshow.ttf}Inicio"

    # game/screens.rpy:343
    old "{font=Freakshow.ttf}Day 2"
    new "{font=Freakshow.ttf}Día 2"

    # game/screens.rpy:350
    old "{font=Freakshow.ttf}Official Site"
    new "{font=Freakshow.ttf}Sitio oficial"

    # game/screens.rpy:351
    old "{font=Freakshow.ttf}History"
    new "{font=Freakshow.ttf}Historia"

    # game/screens.rpy:353
    old "{font=Freakshow.ttf}Save"
    new "{font=Freakshow.ttf}Guardar"

    # game/screens.rpy:355
    old "{font=Freakshow.ttf}Load"
    new "{font=Freakshow.ttf}Cargar"

    # game/screens.rpy:357
    old "{font=Freakshow.ttf}Hidden scenes"
    new "{font=Freakshow.ttf}Escenas ocultas"

    # game/screens.rpy:361
    old "{font=Freakshow.ttf}Preferences"
    new "{font=Freakshow.ttf}Preferencias"

    # game/screens.rpy:365
    old "End Replay"
    new "Finalizar repetición"

    # game/screens.rpy:372
    old "{font=Freakshow.ttf}Main Menu"
    new "{font=Freakshow.ttf}Menú principal"

    # game/screens.rpy:375
    old "{font=Freakshow.ttf}About"
    new "{font=Freakshow.ttf}Acerca de"

    # game/screens.rpy:386
    old "{font=Freakshow.ttf}Quit"
    new "{font=Freakshow.ttf}Salir"

    # game/screens.rpy:558
    old "{font=Freakshow.ttf}Return"
    new "{font=Freakshow.ttf}Regresar"

    # game/screens.rpy:635
    old "About"
    new "Acerca de"

    # game/screens.rpy:650
    old "{b}by Neko Bueno{/b}\n\nThe freak circus of horrors has rolled into town. After your small act of kindness, Pierrot fell for you\nobsessively. And with him, Harlequin’s interest sparked too. Now you’ve caught the attention of every mysterious soul in that circus.\n\n\n{size=30}{b}Official Channels{/b}{/size}\n{a=https://ko-fi.com/nekoobueno}Ko-fi{/a} • {a=https://patreon.com/NekooBueno}Patreon{/a} • {a=https://www.tumblr.com/nekoboydreams}Tumblr{/a} • {a=https://bsky.app/profile/nekoblackcat.bsky.social}Bluesky{/a} • {a=https://garula.itch.io/}Itch.io{/a} \n\n{size=30}{b}Voice acting{/b}{/size}\n{a=https://www.tumblr.com/darthsuki}Darthsuki{/a}\n\n{size=30}{b}Translators{/b}{/size}\nChinese: copiklaGrogu\n\n{size=30}{b}Final Testers{/b}{/size}\nDarthsuki\n{a=https://yussuna.itch.io/}Yuçuna{/a}\n\n{size=30}{b}Sound Effects{/b}{/size}\nFreesound.org\nPixabay.com\n\n{size=30}{b}Musics{/b}{/size}\nPixabay.com\nYouTube Audio Library\n\n\n{b}Thanks for playing!{/b}\n\nMade with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n[renpy.license!t]"
    new "{b}por Neko Bueno{/b}\n\nEl extraño circo de los horrores ha llegado a la ciudad. Después de tu pequeño acto de bondad, Pierrot se enamoró de ti\nobsesivamente. Y con él, también se despertó el interés de Harlequin. Ahora has captado la atención de todas las almas misteriosas de ese circo.\n\n\n{size=30}{b}Canales oficiales{/b}{/size}\n{a=https://ko-fi.com/nekoobueno}Ko-fi{/a} • {a=https://patreon.com/NekooBueno}Patreon{/a} • {a=https://www.tumblr.com/nekoboydreams}Tumblr{/a} • {a=https://bsky.app/profile/nekoblackcat.bsky.social}Bluesky{/a} • {a=https://garula.itch.io/}Itch.io{/a}\n\n{size=30}{b}Actuación de voz{/b}{/size}\n{a=https://www.tumblr.com/darthsuki}Darthsuki{/a}\n\n{size=30}{b}Traductores{/b}{/size}\nChino: copiklaGrogu\n\n{size=30}{b}Final Probadores{/b}{/size}\nDarthsuki\n{a=https://yussuna.itch.io/}Yuçuna{/a}\n\n{size=30}{b}Efectos de sonido{/b}{/size}\nFreesound.org\nPixabay.com\n\n{size=30}{b}Música{/b}{/size}\nPixabay.com\nYouTube Biblioteca de audio\n\n\n{b}¡Gracias por jugar!{/b}\n\nHecho con {a=https://www.renpy.org/}Ren'Py{/a}[renpy.version_only].\n[renpy.license!t]"

    # game/screens.rpy:698
    old "Save"
    new "Guardar"

    # game/screens.rpy:705
    old "Load"
    new "Cargar"

    # game/screens.rpy:752
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:752
    old "empty slot"
    new "ranura vacía"

    # game/screens.rpy:772
    old "<"
    new "<"

    # game/screens.rpy:776
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:779
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:785
    old ">"
    new ">"

    # game/screens.rpy:790
    old "Upload Sync"
    new "Subir sincronización"

    # game/screens.rpy:794
    old "Download Sync"
    new "Descargar sincronización"

    # game/screens.rpy:842
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:853
    old "Display"
    new "Mostrar"

    # game/screens.rpy:854
    old "Window"
    new "Ventana"

    # game/screens.rpy:855
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:859
    old "Skip"
    new "Saltar"

    # game/screens.rpy:860
    old "Unseen Text"
    new "Texto invisible"

    # game/screens.rpy:861
    old "After Choices"
    new "Después de opciones"

    # game/screens.rpy:862
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:870
    old "Languages"
    new "Idiomas"

    # game/screens.rpy:873
    old "简体中文"
    new "简体中文"

    # game/screens.rpy:884
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:888
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:895
    old "Music Volume"
    new "Volumen de música"

    # game/screens.rpy:902
    old "Sound Volume"
    new "Volumen de sonido"

    # game/screens.rpy:908
    old "Test"
    new "Prueba"

    # game/screens.rpy:923
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:1014
    old "History"
    new "Historia"

    # game/screens.rpy:1042
    old "The dialogue history is empty."
    new "El historial de diálogo está vacío."

    # game/screens.rpy:1101
    old "Help"
    new "Ayuda"

    # game/screens.rpy:1110
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1111
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1127
    old "Enter"
    new "Entrar"

    # game/screens.rpy:1128
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1131
    old "Space"
    new "Espacio"

    # game/screens.rpy:1132
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1135
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:1136
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:1139
    old "Escape"
    new "Escape"

    # game/screens.rpy:1140
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:1143
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1144
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionado."

    # game/screens.rpy:1147
    old "Tab"
    new "Pestaña"

    # game/screens.rpy:1148
    old "Toggles dialogue skipping."
    new "Alterna la omisión de diálogos."

    # game/screens.rpy:1151
    old "Page Up"
    new "Página arriba"

    # game/screens.rpy:1152
    old "Rolls back to earlier dialogue."
    new "Vuelve al diálogo anterior."

    # game/screens.rpy:1155
    old "Page Down"
    new "Página abajo"

    # game/screens.rpy:1156
    old "Rolls forward to later dialogue."
    new "Avanza al diálogo posterior."

    # game/screens.rpy:1160
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1164
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1168
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Alterna la {a=https://www.renpy.org/l/voicing}autovoz de asistencia{/a}."

    # game/screens.rpy:1172
    old "Opens the accessibility menu."
    new "Abra el menú de accesibilidad."

    # game/screens.rpy:1178
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1182
    old "Middle Click"
    new "Clic medio"

    # game/screens.rpy:1186
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1190
    old "Mouse Wheel Up"
    new "Rueda del ratón hacia arriba"

    # game/screens.rpy:1194
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1201
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1205
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nHombro izquierdo"

    # game/screens.rpy:1209
    old "Right Shoulder"
    new "Hombro derecho"

    # game/screens.rpy:1213
    old "D-Pad, Sticks"
    new "Pad direccional, baquetas"

    # game/screens.rpy:1217
    old "Start, Guide, B/Right Button"
    new "Inicio, Guía, Botón B/Derecha"

    # game/screens.rpy:1221
    old "Y/Top Button"
    new "Botón Y/arriba"

    # game/screens.rpy:1336
    old "Skipping"
    new "saltando"

    # game/screens.rpy:1647
    old "Auto"
    new "Auto"
    
    old "Back"
    new "Volver"

    # game/screens.rpy:1648
    old "Menu"
    new "Menú"

    # game/screens.rpy:1735
    old "Hidden scenes"
    new "Escenas ocultas"

    # game/screens.rpy:1741
    old "Unlocked Scenes"
    new "Escenas desbloqueadas"

