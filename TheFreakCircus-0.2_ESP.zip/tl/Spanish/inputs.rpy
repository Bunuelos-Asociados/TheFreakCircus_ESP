# TODO: Translation updated at 2026-10-03 14:34

translate Spanish strings:

    # game/inputs.rpy:64
    old "Hey, looks like we share the same name. Well, I guess that’s kind of common... anyway, good luck!"
    new "Oye, parece que compartimos el mismo nombre. Bueno, supongo que eso es algo común... de todos modos, ¡buena suerte!"

    # game/inputs.rpy:64
    old "You want to use my name, [titulo_pierrot]? But I like yours much more. Please, let me call you by your sweet name."
    new "¿Quieres usar mi nombre, [titulo_pierrot!t]? Pero me gusta mucho más el tuyo. Por favor, déjame llamarte por ese dulce nombre."

    # game/inputs.rpy:64
    old "Are you in love with me? That’s why you want to use my name? Heh, better stick to yours."
    new "¿Me amas? ¿Por eso quieres usar mi nombre? Je, mejor quédate con el tuyo."
    # game/inputs.rpy:64
    old "You and I both know that’s not your name. Follow the rules, do it properly."
    new "Tú y yo sabemos que ese no es tu nombre. Sigue las reglas, hazlo correctamente."

    # game/inputs.rpy:64
    old "You and I both know that’s not your name. Follow the rules, do it properly... and write it correctly."
    new "Tú y yo sabemos que ese no es tu nombre. Sigue las reglas, hazlo correctamente... y escríbelo correctamente."

    # game/inputs.rpy:64
    old "There’s only one Jester. We’re not having this conversation again, right? Good."
    new "Solo hay un Bufón. No volveremos a tener esta conversación, ¿verdad? Bien."

    # game/inputs.rpy:64
    old "Hah, that was a good one, but it won’t work. Use your own name sweetie."
    new "Ja, esa estuvo buena, pero no funcionará. Usa tu propio nombre, cariño."

    # game/inputs.rpy:752
    old "{size=30}{color=#000000}{b}Contract{/b}"
    new "{size=30}{color=#000000}{b}Contrato{/b}"

    # game/inputs.rpy:757
    old "{size=21}{color=#000000}{b}Individual consultation."
    new "{size=21}{color=#000000}{b}Consulta individual."

    # game/inputs.rpy:760
    old "{size=19}{color=#000000}Feeling sick? Hallucinating things that don’t exist? Hearing\nvoices calling from the circus’s dark tents?\nMaybe it’s time you visit the Doctor.\n"
    new "{size=19}{color=#000000}¿Te sientes enfermo? ¿Alucinas cosas que no existen? ¿Escuchas\nvoces que te llaman desde las oscuras carpas del circo?\nTal vez sea hora de que visites al Doctor.\n"

    # game/inputs.rpy:767
    old "{size=18}{color=#000000}• Entering the tent is entirely your responsibility.\n• Once inside, only the Doctor decides when the consultation ends.\n• We aren’t liable for any injuries during this attraction.\n{/size}"
    new "{size=18}{color=#000000}• Entrar a la carpa es totalmente tu responsabilidad.\n• Una vez dentro, solo el Doctor decide cuándo termina la consulta.\n• No nos hacemos responsables de ninguna lesión sufrida durante esta atracción.\n{/size}"

    # game/inputs.rpy:776
    old "{b}{color=#000000}Obey the Doctor and you’ll be fine.{/b}"
    new "{b}{color=#000000}Obedece al Doctor y estarás bien.{/b}"

    # game/inputs.rpy:1033
    old "Freaks"
    new "Fenómenos"

    # game/inputs.rpy:1033
    old "Abominations"
    new "Abominaciones"

    # game/inputs.rpy:1033
    old "GET OUT"
    new "SALIR"

    # game/inputs.rpy:1033
    old "MONSTERS"
    new "MONSTRUOS"

    # game/inputs.rpy:1033
    old "They’re too tall"
    new "Son demasiado altos."

    # game/inputs.rpy:1033
    old "HAHAHAHAHA"
    new "JAJAJAJAJAJA"

    # game/inputs.rpy:1033
    old "Those eyes aren’t normal"
    new "Esos ojos no son normales"

    # game/inputs.rpy:1033
    old "That smile isn’t normal"
    new "Esa sonrisa no es normal"

    # game/inputs.rpy:1033
    old "Disgusting"
    new "Asqueroso"

    # game/inputs.rpy:1033
    old "Horrible"
    new "Horrible"

    # game/inputs.rpy:1033
    old "Get out of our town"
    new "Sal de nuestra ciudad"

    # game/inputs.rpy:1033
    old "FREAKS"
    new "FENÓMENOS"

    # game/inputs.rpy:1289
    old "{glitch=50}{size=100}{b}{color=#e61ee6}We’re not the same"
    new "{glitch=50}{size=100}{b}{color=#e61ee6}No somos iguales"

    # game/inputs.rpy:1292
    old "{glitch=20}{size=100}{b}{color=#e61ee6}You and I"
    new "{glitch=20}{size=100}{b}{color=#e61ee6}Tú y yo"

    # game/inputs.rpy:1296
    old "{glitch=20}{size=100}{b}{color=#e61ee6}I didn’t want to"
    new "{glitch=20}{size=100}{b}{color=#e61ee6}No quería"

    # game/inputs.rpy:1301
    old "{glitch=20}{size=100}{b}{color=#e61ee6}But our fate was cursed"
    new "{glitch=20}{size=100}{b}{color=#e61ee6}Pero nuestro destino estaba maldito"

    # game/inputs.rpy:1310
    old "{glitch=20}{size=100}{b}{color=#e61ee6}I should have listened to him"
    new "{glitch=20}{size=100}{b}{color=#e61ee6}Debí haberlo escuchado"

    # game/inputs.rpy:1318
    old "{glitch=20}{size=100}{b}{color=#e61ee6}It was my fault"
    new "{glitch=20}{size=100}{b}{color=#e61ee6}Fue mi culpa"

    # game/inputs.rpy:1321
    old "{glitch=20}{size=100}{b}{color=#e61ee6}Now they are broken"
    new "{glitch=20}{size=100}{b}{color=#e61ee6}Ahora están rotos"

    # game/inputs.rpy:1426
    old "Support the Official Release"
    new "Apoya el lanzamiento oficial"

    # game/inputs.rpy:1427
    old "This game is available only through its official website:"
    new "Este juego solo está disponible a través de su sitio web oficial:"

    # game/inputs.rpy:1429
    old "If you found it elsewhere, it was shared {b}without permission."
    new "Si lo encontraste en otro lugar, fue compartido {b}sin permiso."

    # game/inputs.rpy:1430
    old "Please support the official release so future updates,\n stories, and events can keep coming to life."
    new "Apoya el lanzamiento oficial para que futuras actualizaciones,\n historias y eventos puedan seguir cobrando vida."

    # game/inputs.rpy:1431
    old "{b}Thank you for respecting the work behind The Freak Circus."
    new "{b}Gracias por respetar el trabajo que hay detrás de The Freak Circus."

